// Made with Blockbench 3.9.2
// Exported for Minecraft version 1.15 - 1.16 with MCP mappings
// Paste this class into your mod and generate all required imports


public class chibi_demon extends EntityModel<Entity> {
	private final ModelRenderer head;
	private final ModelRenderer brow2_r1;
	private final ModelRenderer brow_r1;
	private final ModelRenderer horn_l_r1;
	private final ModelRenderer horn_r_r1;
	private final ModelRenderer body;
	private final ModelRenderer legs;
	private final ModelRenderer arms;
	private final ModelRenderer arm_l_r1;
	private final ModelRenderer arm_r_r1;
	private final ModelRenderer wings;
	private final ModelRenderer wing_r;
	private final ModelRenderer wing_l;

	public chibi_demon() {
		textureWidth = 32;
		textureHeight = 32;

		head = new ModelRenderer(this);
		head.setRotationPoint(0.0F, 15.2F, -0.98F);
		head.setTextureOffset(0, 1).addBox(-3.0F, -1.2F, -1.02F, 6.0F, 6.0F, 5.0F, 0.0F, false);

		brow2_r1 = new ModelRenderer(this);
		brow2_r1.setRotationPoint(-1.0F, 0.8F, -0.72F);
		head.addChild(brow2_r1);
		setRotationAngle(brow2_r1, 0.0F, 0.0F, 0.3491F);
		brow2_r1.setTextureOffset(0, 4).addBox(-1.2F, -0.5F, -0.5F, 2.0F, 1.0F, 0.0F, 0.0F, false);

		brow_r1 = new ModelRenderer(this);
		brow_r1.setRotationPoint(1.0F, 0.5F, -0.72F);
		head.addChild(brow_r1);
		setRotationAngle(brow_r1, 0.0F, 0.0F, -0.3491F);
		brow_r1.setTextureOffset(0, 4).addBox(-0.8F, -0.2F, -0.5F, 2.0F, 1.0F, 0.0F, 0.0F, false);

		horn_l_r1 = new ModelRenderer(this);
		horn_l_r1.setRotationPoint(-1.5F, -1.2F, 0.48F);
		head.addChild(horn_l_r1);
		setRotationAngle(horn_l_r1, -0.1745F, 0.2618F, -0.4363F);
		horn_l_r1.setTextureOffset(0, 12).addBox(-0.5F, -2.0F, -0.5F, 1.0F, 3.0F, 1.0F, 0.0F, false);

		horn_r_r1 = new ModelRenderer(this);
		horn_r_r1.setRotationPoint(1.5F, -1.2F, 0.48F);
		head.addChild(horn_r_r1);
		setRotationAngle(horn_r_r1, -0.1745F, -0.2618F, 0.4363F);
		horn_r_r1.setTextureOffset(0, 12).addBox(-0.5F, -2.0F, -0.5F, 1.0F, 3.0F, 1.0F, 0.0F, true);

		body = new ModelRenderer(this);
		body.setRotationPoint(0.0F, 24.0F, 0.0F);
		body.setTextureOffset(16, 12).addBox(-2.0F, -4.0F, -1.0F, 4.0F, 3.0F, 4.0F, 0.0F, false);

		legs = new ModelRenderer(this);
		legs.setRotationPoint(0.0F, -6.0F, 0.5F);
		body.addChild(legs);
		legs.setTextureOffset(0, 3).addBox(1.0F, 5.0F, -0.5F, 1.0F, 1.0F, 1.0F, 0.0F, false);
		legs.setTextureOffset(0, 3).addBox(-2.0F, 5.0F, -0.5F, 1.0F, 1.0F, 1.0F, 0.0F, false);

		arms = new ModelRenderer(this);
		arms.setRotationPoint(-0.5F, -8.5F, 0.0F);
		body.addChild(arms);
		

		arm_l_r1 = new ModelRenderer(this);
		arm_l_r1.setRotationPoint(-1.5F, 5.0F, 0.5F);
		arms.addChild(arm_l_r1);
		setRotationAngle(arm_l_r1, 0.0F, 0.0F, -1.0472F);
		arm_l_r1.setTextureOffset(17, 4).addBox(-2.0F, -0.5F, -0.5F, 2.0F, 1.0F, 1.0F, 0.0F, false);

		arm_r_r1 = new ModelRenderer(this);
		arm_r_r1.setRotationPoint(2.5F, 5.0F, 0.5F);
		arms.addChild(arm_r_r1);
		setRotationAngle(arm_r_r1, 0.0F, 0.0F, 1.0472F);
		arm_r_r1.setTextureOffset(17, 1).addBox(0.0F, -0.5F, -0.5F, 2.0F, 1.0F, 1.0F, 0.0F, false);

		wings = new ModelRenderer(this);
		wings.setRotationPoint(0.0F, 18.0F, 3.0F);
		

		wing_r = new ModelRenderer(this);
		wing_r.setRotationPoint(1.0F, -3.5F, 0.5F);
		wings.addChild(wing_r);
		setRotationAngle(wing_r, 0.0F, -0.3491F, 0.0F);
		wing_r.setTextureOffset(0, 18).addBox(0.0F, 1.5F, -0.5F, 7.0F, 4.0F, 1.0F, 0.0F, false);
		wing_r.setTextureOffset(1, 22).addBox(0.0F, 5.5F, -0.5F, 5.0F, 2.0F, 1.0F, 0.0F, false);

		wing_l = new ModelRenderer(this);
		wing_l.setRotationPoint(-1.0F, -3.5F, 0.5F);
		wings.addChild(wing_l);
		setRotationAngle(wing_l, 0.0F, 0.3491F, 0.0F);
		wing_l.setTextureOffset(0, 18).addBox(-7.0F, 1.5F, -0.5F, 7.0F, 4.0F, 1.0F, 0.0F, false);
		wing_l.setTextureOffset(1, 22).addBox(-5.0F, 5.5F, -0.5F, 5.0F, 2.0F, 1.0F, 0.0F, false);
	}

	@Override
	public void setRotationAngles(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch){
		//previously the render function, render code was moved to a method below
	}

	@Override
	public void render(MatrixStack matrixStack, IVertexBuilder buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha){
		head.render(matrixStack, buffer, packedLight, packedOverlay);
		body.render(matrixStack, buffer, packedLight, packedOverlay);
		wings.render(matrixStack, buffer, packedLight, packedOverlay);
	}

	public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
		modelRenderer.rotateAngleX = x;
		modelRenderer.rotateAngleY = y;
		modelRenderer.rotateAngleZ = z;
	}
}