// Made with Blockbench 3.9.2
// Exported for Minecraft version 1.15 - 1.16 with MCP mappings
// Paste this class into your mod and generate all required imports


public class intricraft.sloth extends EntityModel<Entity> {
	private final ModelRenderer root;
	private final ModelRenderer body;
	private final ModelRenderer head;
	private final ModelRenderer head_tuft;
	private final ModelRenderer head_tuft2_r1;
	private final ModelRenderer head_tuft1_r1;
	private final ModelRenderer legs;
	private final ModelRenderer leg_fr;
	private final ModelRenderer leg_fl;
	private final ModelRenderer leg_bl;
	private final ModelRenderer leg_br;

	public intricraft.sloth() {
		textureWidth = 64;
		textureHeight = 64;

		root = new ModelRenderer(this);
		root.setRotationPoint(0.0F, 24.0F, 0.0F);
		

		body = new ModelRenderer(this);
		body.setRotationPoint(0.0F, -4.0F, -2.0F);
		root.addChild(body);
		body.setTextureOffset(0, 0).addBox(-3.0F, -5.0F, -3.0F, 6.0F, 4.0F, 11.0F, 0.0F, false);
		body.setTextureOffset(19, 18).addBox(-2.0F, -1.0F, 0.0F, 4.0F, 1.0F, 7.0F, 0.0F, false);
		body.setTextureOffset(14, 26).addBox(-3.0F, -5.0F, -4.0F, 6.0F, 4.0F, 1.0F, 0.0F, false);
		body.setTextureOffset(0, 25).addBox(-3.0F, -5.0F, 8.0F, 6.0F, 4.0F, 1.0F, 0.0F, false);
		body.setTextureOffset(0, 8).addBox(-2.0F, -4.0F, 9.0F, 4.0F, 2.0F, 1.0F, 0.0F, false);
		body.setTextureOffset(21, 15).addBox(-1.0F, -4.0F, 10.0F, 2.0F, 2.0F, 1.0F, 0.0F, false);

		head = new ModelRenderer(this);
		head.setRotationPoint(0.0F, -8.0F, -7.0F);
		root.addChild(head);
		head.setTextureOffset(0, 15).addBox(-4.0F, -4.0F, -4.0F, 8.0F, 5.0F, 5.0F, 0.0F, false);
		head.setTextureOffset(23, 0).addBox(-2.0F, -2.0F, -1.0F, 4.0F, 2.0F, 5.0F, 0.0F, false);

		head_tuft = new ModelRenderer(this);
		head_tuft.setRotationPoint(0.0F, -6.0F, -1.0F);
		head.addChild(head_tuft);
		setRotationAngle(head_tuft, -0.0873F, -0.2182F, 0.0F);
		head_tuft.setTextureOffset(0, 15).addBox(-1.0F, 1.0F, -1.0F, 1.0F, 1.0F, 1.0F, 0.0F, false);

		head_tuft2_r1 = new ModelRenderer(this);
		head_tuft2_r1.setRotationPoint(-3.0F, -2.0F, 0.0F);
		head_tuft.addChild(head_tuft2_r1);
		setRotationAngle(head_tuft2_r1, 0.0F, 0.0F, 0.1745F);
		head_tuft2_r1.setTextureOffset(6, 0).addBox(3.0F, 2.0F, 0.0F, 1.0F, 1.0F, 1.0F, 0.0F, false);

		head_tuft1_r1 = new ModelRenderer(this);
		head_tuft1_r1.setRotationPoint(-1.0F, 0.0F, 0.0F);
		head_tuft.addChild(head_tuft1_r1);
		setRotationAngle(head_tuft1_r1, 0.3054F, 0.0F, 0.0F);
		head_tuft1_r1.setTextureOffset(0, 18).addBox(-1.0F, 0.0F, -2.0F, 1.0F, 1.0F, 1.0F, 0.0F, false);

		legs = new ModelRenderer(this);
		legs.setRotationPoint(-4.0F, -6.0F, -4.0F);
		root.addChild(legs);
		

		leg_fr = new ModelRenderer(this);
		leg_fr.setRotationPoint(0.0F, 0.0F, 0.0F);
		legs.addChild(leg_fr);
		leg_fr.setTextureOffset(8, 30).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 7.0F, 2.0F, 0.0F, false);

		leg_fl = new ModelRenderer(this);
		leg_fl.setRotationPoint(8.0F, 0.0F, 0.0F);
		legs.addChild(leg_fl);
		leg_fl.setTextureOffset(0, 30).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 7.0F, 2.0F, 0.0F, false);

		leg_bl = new ModelRenderer(this);
		leg_bl.setRotationPoint(8.0F, 0.0F, 10.0F);
		legs.addChild(leg_bl);
		leg_bl.setTextureOffset(28, 26).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 7.0F, 2.0F, 0.0F, false);

		leg_br = new ModelRenderer(this);
		leg_br.setRotationPoint(0.0F, 0.0F, 10.0F);
		legs.addChild(leg_br);
		leg_br.setTextureOffset(0, 0).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 7.0F, 2.0F, 0.0F, false);
	}

	@Override
	public void setRotationAngles(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch){
		//previously the render function, render code was moved to a method below
	}

	@Override
	public void render(MatrixStack matrixStack, IVertexBuilder buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha){
		root.render(matrixStack, buffer, packedLight, packedOverlay);
	}

	public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
		modelRenderer.rotateAngleX = x;
		modelRenderer.rotateAngleY = y;
		modelRenderer.rotateAngleZ = z;
	}
}