package com.capnsloth.intricraft.blocks;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.FluidBlock;
import net.minecraft.fluid.FlowableFluid;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;

public class TestFluidBlock extends FluidBlock {

    public static IntProperty SPEED = IntProperty.of("speed", 0, 10);


    public TestFluidBlock(FlowableFluid fluid, Settings settings) {
        super(fluid, settings);
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        //super.appendProperties(builder);
        builder.add(SPEED);
        builder.add(LEVEL);
    }

    /*
    @Override
    public FluidState getFluidState(BlockState state) {
        int i = (Integer)state.get(LEVEL);
        return (FluidState)this.statesByLevel.get(Math.min(i, 15));
    }

     */
}
