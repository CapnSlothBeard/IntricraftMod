package com.capnsloth.intricraft.blocks;

import com.capnsloth.intricraft.registry.ModBlocks;
import com.capnsloth.intricraft.registry.ModItems;
import net.minecraft.block.BlockState;
import net.minecraft.fluid.FlowableFluid;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.Item;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;

public class TestFluid extends FlowableFluid {

    public static IntProperty SPEED = IntProperty.of("speed", 0, 10);

    @Override
    public Fluid getFlowing() {
        return ModBlocks.TEST_FLOWING_FLOWING;
    }

    @Override
    public Fluid getStill() {
        return ModBlocks.TEST_FLUID_STILL;
    }

    @Override
    protected boolean isInfinite() {
        return true;
    }

    @Override
    protected void beforeBreakingBlock(WorldAccess world, BlockPos pos, BlockState state) {

    }

    @Override
    protected int getFlowSpeed(WorldView world) {
        return 3;
    }

    @Override
    protected FluidState getUpdatedState(WorldView world, BlockPos pos, BlockState state) {
        return super.getUpdatedState(world, pos, state);
    }

    @Override
    protected int getLevelDecreasePerBlock(WorldView world) {
        return 1;
    }

    @Override
    public Item getBucketItem() {
        return ModItems.TEST_FLUID_BUCKET;
    }

    @Override
    protected boolean canBeReplacedWith(FluidState state, BlockView world, BlockPos pos, Fluid fluid, Direction direction) {
        return false;
    }

    @Override
    public int getTickRate(WorldView world) {
        return 5;
    }

    @Override
    protected float getBlastResistance() {
        return 1;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Fluid, FluidState> builder) {
        super.appendProperties(builder);
        builder.add(SPEED);
        builder.add(LEVEL);
    }

    @Override
    protected BlockState toBlockState(FluidState state) {
        return ModBlocks.TEST_FLUID_BLOCK.getDefaultState().with(Properties.LEVEL_15, state.get(LEVEL)).with(SPEED, state.get(SPEED));
    }


    @Override
    public boolean isStill(FluidState state) {
        return false;
    }

    @Override
    public int getLevel(FluidState state) {
        return 8;
    }

    public static class Flowing extends TestFluid
    {
        @Override
        protected void appendProperties(StateManager.Builder<Fluid, FluidState> builder)
        {
            super.appendProperties(builder);
        }

        @Override
        public int getLevel(FluidState fluidState)
        {
            return fluidState.get(LEVEL);
        }

        @Override
        public boolean isStill(FluidState fluidState)
        {
            return false;
        }
    }

    public static class Still extends TestFluid
    {
        @Override
        public int getLevel(FluidState fluidState)
        {
            return 8;
        }

        @Override
        public boolean isStill(FluidState fluidState)
        {
            return true;
        }
    }
}
