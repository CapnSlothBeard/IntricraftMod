package com.capnsloth.intricraft.network;

import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

public class BlockEntityFacingPacket {
    public static Packet<?> create(Identifier packetID, BlockEntity e, Vec3i facing){
        return ServerPlayNetworking.createS2CPacket(packetID, createBuffer(e, facing));
    }
    public static PacketByteBuf createBuffer(BlockEntity e, Vec3i facing){

        PacketByteBuf byteBuf = new PacketByteBuf(Unpooled.buffer());

        // Write block pos.
        PacketUtil.writeVec3d(byteBuf, new Vec3d(e.getPos().getX(), e.getPos().getY(), e.getPos().getZ()));

        // Write facing direction as vector.
        PacketUtil.writeVec3d(byteBuf, new Vec3d(facing.getX(), facing.getY(), facing.getZ()));

        return byteBuf;
    }

    public static PacketByteBuf createBuffer(BlockEntity e, Vec3d facing){

        PacketByteBuf byteBuf = new PacketByteBuf(Unpooled.buffer());

        // Write block pos.
        PacketUtil.writeVec3d(byteBuf, new Vec3d(e.getPos().getX(), e.getPos().getY(), e.getPos().getZ()));

        // Write facing direction as vector.
        PacketUtil.writeVec3d(byteBuf, facing);

        return byteBuf;
    }
}
