package com.capnsloth.intricraft.network;

import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

public class PosAndVelocityPacket {
    public static Packet<?> create(Identifier packetID, Vec3d pos, Vec3d vel){
        return ServerPlayNetworking.createS2CPacket(packetID, createBuffer(pos, vel));
    }
    public static PacketByteBuf createBuffer(Vec3d pos, Vec3d vel){

        PacketByteBuf byteBuf = new PacketByteBuf(Unpooled.buffer());

        // Write pos and velocity.
        PacketUtil.writeVec3d(byteBuf, pos);
        PacketUtil.writeVec3d(byteBuf, vel);


        return byteBuf;
    }
}
