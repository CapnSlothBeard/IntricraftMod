package com.capnsloth.intricraft.network;

import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class EntityIntPacket {
    public static Packet<?> create(Identifier packetID, Entity e, int number){
        return ServerPlayNetworking.createS2CPacket(packetID, createBuffer(e, number));
    }
    public static PacketByteBuf createBuffer(Entity e, int number){
        if (e.world.isClient) throw new IllegalStateException("SpawnPacketUtil.create called on the logical client!");

        PacketByteBuf byteBuf = new PacketByteBuf(Unpooled.buffer());

        // Write entity identification data.
        byteBuf.writeVarInt(e.getEntityId());

        // Write int
        byteBuf.writeVarInt(number);

        return byteBuf;
    }
}
