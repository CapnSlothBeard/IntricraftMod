package com.capnsloth.intricraft.network;

import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class EntityBoolPacket {
    public static Packet<?> create(Identifier packetID, Entity e, boolean bool){
        return ServerPlayNetworking.createS2CPacket(packetID, createBuffer(e, bool));
    }
    public static PacketByteBuf createBuffer(Entity e, boolean bool){
        if (e.world.isClient) throw new IllegalStateException("SpawnPacketUtil.create called on the logical client!");

        PacketByteBuf byteBuf = new PacketByteBuf(Unpooled.buffer());

        // Write entity identification data.
        byteBuf.writeVarInt(e.getEntityId());

        // Write bool
        byteBuf.writeBoolean(bool);

        return byteBuf;
    }

    /*public static boolean send(Identifier packetID, Entity entity, boolean bool){
        //ClientPlayNetworking.send(packetID, create(entity, packetID, bool));
    }

    public static boolean read(Packet<?> packet){

    }*/
}
