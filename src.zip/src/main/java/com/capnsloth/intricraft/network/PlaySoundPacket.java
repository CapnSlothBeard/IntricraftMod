package com.capnsloth.intricraft.network;

import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

public class PlaySoundPacket {
    public static Packet<?> create(Identifier packetID, String soundIdString, Vec3d pos, float volume, float pitch){
        return ServerPlayNetworking.createS2CPacket(packetID, createBuffer(soundIdString, pos, volume, pitch));
    }
    public static PacketByteBuf createBuffer(String soundIdString, Vec3d pos, float volume, float pitch){

        PacketByteBuf byteBuf = new PacketByteBuf(Unpooled.buffer());

        // Write entity identification data.
        byteBuf.writeString(soundIdString);

        // Write pos
        PacketUtil.writeVec3d(byteBuf, pos);

        // Write Volume and Pitch
        byteBuf.writeFloat(volume);
        byteBuf.writeFloat(pitch);

        return byteBuf;
    }
}
