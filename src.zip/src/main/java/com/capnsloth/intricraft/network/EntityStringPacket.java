package com.capnsloth.intricraft.network;

import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

public class EntityStringPacket {
    public static Packet<?> create(Identifier packetID, Entity e, String s){
        return ServerPlayNetworking.createS2CPacket(packetID, createBuffer(e, s));
    }
    public static PacketByteBuf createBuffer(Entity e, String s){
        if (e.world.isClient) throw new IllegalStateException("SpawnPacketUtil.create called on the logical client!");

        PacketByteBuf byteBuf = new PacketByteBuf(Unpooled.buffer());

        // Write entity identification data.
        byteBuf.writeVarInt(e.getEntityId());

        // Write String
        byteBuf.writeString(s);

        return byteBuf;
    }
}
