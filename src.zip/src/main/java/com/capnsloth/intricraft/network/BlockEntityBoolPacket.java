package com.capnsloth.intricraft.network;

import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

public class BlockEntityBoolPacket {
    public static Packet<?> create(Identifier packetID, BlockEntity e, boolean bool){
        return ServerPlayNetworking.createS2CPacket(packetID, createBuffer(e, bool));
    }
    public static PacketByteBuf createBuffer(BlockEntity e, boolean bool){

        PacketByteBuf byteBuf = new PacketByteBuf(Unpooled.buffer());

        // Write block pos.
        PacketUtil.writeVec3d(byteBuf, new Vec3d(e.getPos().getX(), e.getPos().getY(), e.getPos().getZ()));

        // Write bool
        byteBuf.writeBoolean(bool);

        return byteBuf;
    }
}
