package com.capnsloth.intricraft.network;

import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

public class EntityVectorPacket {
    public static Packet<?> create(Identifier packetID, Entity e, Vec3d vec){
        return ServerPlayNetworking.createS2CPacket(packetID, createBuffer(e, vec));
    }
    public static PacketByteBuf createBuffer(Entity e, Vec3d vec){
        if (e.world.isClient) throw new IllegalStateException("SpawnPacketUtil.create called on the logical client!");

        PacketByteBuf byteBuf = new PacketByteBuf(Unpooled.buffer());

        // Write entity identification data.
        byteBuf.writeVarInt(e.getEntityId());

        // Write Vector
        PacketUtil.writeVec3d(byteBuf, vec);

        return byteBuf;
    }
}
