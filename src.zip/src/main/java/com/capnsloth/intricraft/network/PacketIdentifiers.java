package com.capnsloth.intricraft.network;

import com.capnsloth.intricraft.IntricraftMain;
import net.minecraft.util.Identifier;

public class PacketIdentifiers {
    // Network packet identifiers.
    public static final Identifier JETPACK_CONSUME_FUEL = new Identifier(IntricraftMain.modID, "netid_jetpack");
    public static final Identifier SPAWN_LASER_PROJECTILE = new Identifier(IntricraftMain.modID, "netid_spawn_laser");
    public static final Identifier SET_SITTING = new Identifier(IntricraftMain.modID, "netid_set_sitting");
    public static final Identifier SPAWN_CRUSHER_PARTICLE = new Identifier(IntricraftMain.modID, "netid_spawn_crusher_particle");
    public static final Identifier SPAWN_PLACER_PARTICLE = new Identifier(IntricraftMain.modID, "netid_spawn_placer_particle");
    public static final Identifier PLAY_SOUND = new Identifier(IntricraftMain.modID, "netid_play_sound");
    public static final Identifier SPAWN_FAST_MINECART = new Identifier(IntricraftMain.modID, "netid_spawn_fast_minecart");
    public static final Identifier SET_ENTITY_VELOCITY = new Identifier(IntricraftMain.modID, "netid_set_entity_velocity");
    public static final Identifier SPAWN_MOB = new Identifier(IntricraftMain.modID, "netid_spawn_mob");
    public static final Identifier STEAM_UPDATE = new Identifier(IntricraftMain.modID, "netid_steam_update");
}
