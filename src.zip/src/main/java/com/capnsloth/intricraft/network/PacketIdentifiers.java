package com.capnsloth.intricraft.network;

import com.capnsloth.intricraft.IntricraftMain;
import net.minecraft.util.Identifier;

public class PacketIdentifiers {
    // Network packet identifiers.
    public static final Identifier JETPACK_CONSUME_FUEL = new Identifier(IntricraftMain.modID, "netid_jetpack");
    public static final Identifier SPAWN_LASER_PROJECTILE = new Identifier(IntricraftMain.modID, "netid_spawn_laser");
    public static final Identifier SET_SITTING = new Identifier(IntricraftMain.modID, "netid_set_sitting");
    public static final Identifier CRUSHER_ACTIVATED = new Identifier(IntricraftMain.modID, "netid_crusher_activated");
    public static final Identifier BLOCKENTITY_FACING = new Identifier(IntricraftMain.modID, "netid_blockentity_facing");
    public static final Identifier PLAY_SOUND = new Identifier(IntricraftMain.modID, "netid_play_sound");
}
