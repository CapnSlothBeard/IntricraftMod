package com.capnsloth.intricraft.network;

import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.registry.Registry;


// Copied from the FabricMC tutorials.
public class EntitySpawnPacket {
    public static Packet<?> create(Entity e, Identifier packetID) {
        PacketByteBuf byteBuf = createBuffer(e);
        return ServerPlayNetworking.createS2CPacket(packetID, byteBuf);
    }

    public static PacketByteBuf createBuffer(Entity e){
        PacketByteBuf byteBuf = new PacketByteBuf(Unpooled.buffer());
        byteBuf.writeVarInt(Registry.ENTITY_TYPE.getRawId(e.getType()));
        byteBuf.writeUuid(e.getUuid());
        byteBuf.writeVarInt(e.getEntityId());

        PacketUtil.writeVec3d(byteBuf, (Vec3d)e.getPos());
        PacketUtil.writeAngle(byteBuf, e.pitch);
        PacketUtil.writeAngle(byteBuf, e.yaw);
        return byteBuf;
    }
}
