package com.capnsloth.intricraft.network;

import com.capnsloth.intricraft.blockentity.SteamBlockEntity;
import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

public class SteamUpdatePacket {
    public static Packet<?> create(Identifier packetID, SteamBlockEntity e){
        return ServerPlayNetworking.createS2CPacket(packetID, createBuffer(e));
    }
    public static PacketByteBuf createBuffer(SteamBlockEntity e){

        PacketByteBuf byteBuf = new PacketByteBuf(Unpooled.buffer());

        // Write block pos and prevPos.
        PacketUtil.writeVec3d(byteBuf, new Vec3d(e.getPos().getX(), e.getPos().getY(), e.getPos().getZ()));
        if(e.prevPos != null) PacketUtil.writeVec3d(byteBuf, new Vec3d(e.prevPos.getX(), e.prevPos.getY(), e.prevPos.getZ()));
        else PacketUtil.writeVec3d(byteBuf, Vec3d.ZERO);

        // Write speed.
        byteBuf.writeInt(e.speed);

        return byteBuf;
    }
}
