package com.capnsloth.intricraft.network;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.apache.commons.lang3.SerializationUtils;

import java.io.*;

public class PacketUtil {
    public static void writeVec3d(PacketByteBuf byteBuf, Vec3d vec3d) {
        byteBuf.writeDouble(vec3d.x);
        byteBuf.writeDouble(vec3d.y);
        byteBuf.writeDouble(vec3d.z);
    }
    public static Vec3d readVec3d(PacketByteBuf byteBuf) {
        double x = byteBuf.readDouble();
        double y = byteBuf.readDouble();
        double z = byteBuf.readDouble();
        return new Vec3d(x, y, z);
    }

    /*public static void writeObject(PacketByteBuf byteBuf, Object o){
        byte[] data = SerializationUtils.serialize((Serializable)o);
        byteBuf.writeBytes(data);
    }
    public static Object readObject(PacketByteBuf byteBuf){
        return SerializationUtils.deserialize(byteBuf.readByteArray());
    }*/

    public static void SendToAllClients(World world, Identifier netID, PacketByteBuf packetBuffer){
        for (PlayerEntity player:  world.getPlayers()){
            ServerPlayNetworking.send((ServerPlayerEntity) player, netID, packetBuffer);
        }
    }
}
