package com.capnsloth.intricraft.armour;

import com.capnsloth.intricraft.registry.FuelTypes;
import com.capnsloth.intricraft.network.PacketIdentifiers;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.recipe.Ingredient;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;

public class JetpackSolidFuel implements ArmorMaterial {
    private static final int[] BASE_DURABILITY = new int[] {0, 300, 0, 0};
    private static final int[] PROTECTION_VALUES = new int[] {0, 3, 0, 0};
    public static double maxVelocity = 0.3d;
    public static double acceleration = 0.12d;
    public static int usedTicks = 9001;
    public static int ticksPerFuel = 150;

    @Override
    public int getDurability(EquipmentSlot slot) {
        return BASE_DURABILITY[slot.getEntitySlotId()];
    }

    @Override
    public int getProtectionAmount(EquipmentSlot slot) {
        return PROTECTION_VALUES[slot.getEntitySlotId()];
    }

    @Override
    public int getEnchantability() {
        return 0;
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ITEM_ARMOR_EQUIP_LEATHER;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return null;
    }

    @Override
    public String getName() {
        return "jetpack_solid_fuel";
    }

    @Override
    public float getToughness() {
        return 0.0F;
    }

    @Override
    public float getKnockbackResistance() {
        return 0.0F;
    }


    public static void useJetpack(ClientPlayerEntity player){

        // Consume fuel.
        if(usedTicks >= ticksPerFuel){
            if(player.inventory.contains(FuelTypes.fuelType[0].getDefaultStack())) {
                PacketByteBuf buf = PacketByteBufs.create();
                buf.writeInt(0); // Send the fuelTypeArray index of desired fuel.
                ClientPlayNetworking.send(PacketIdentifiers.JETPACK_CONSUME_FUEL,buf);
                usedTicks = 0;
            }
        }

        // Activate Jetpack.
        if(usedTicks <= ticksPerFuel) {
            usedTicks++;

            // Move player.
            Vec3d v = player.getVelocity();
            double newV = v.y + acceleration;
            if (newV <= maxVelocity) {
                player.setVelocity(v.x, newV, v.z);
            } else {
                player.setVelocity(v.x, maxVelocity, v.z);
            }

            //Spawn Particles.
            Vec3d p = player.getPos();
            double r = Math.random() * 1.5;
            double r2 = Math.random() * 1.5;
            for (double i = -1.0d; i < 1.0d; i += 1.0d) {
                for (double j = -1.0d; j < 1.0d; j += 1.0d) {
                    player.world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, p.x + (i / 3), p.y + 1.0d, p.z+ (j / 3) , 0.02d *i *r, -0.01d, 0.02d*j*r2);
                }
            }
            player.world.addParticle(ParticleTypes.FIREWORK, p.x, p.y + 1.0d, p.z, 0.0d, -0.05d, 0.0d);
            player.world.playSound(p.x, p.y, p.z, SoundEvents.ITEM_FIRECHARGE_USE, SoundCategory.PLAYERS, 0.1f, 0.001f, false);
        }
    }

}
