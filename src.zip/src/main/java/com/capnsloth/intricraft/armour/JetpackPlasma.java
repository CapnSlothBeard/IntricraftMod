package com.capnsloth.intricraft.armour;

import com.capnsloth.intricraft.registry.FuelTypes;
import com.capnsloth.intricraft.network.PacketIdentifiers;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.recipe.Ingredient;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;

public class JetpackPlasma implements ArmorMaterial {
    public static double maxVelocity = 0.5d;
    public static double acceleration = 0.2d;
    private static final int[] BASE_DURABILITY = new int[] {0, 300, 0, 0};
    private static final int[] PROTECTION_VALUES = new int[] {0, 3, 0, 0};
    public static int usedTicks = 9001;
    public static int ticksPerFuel = 1000;

    @Override
    public int getDurability(EquipmentSlot slot) {
        return BASE_DURABILITY[slot.getEntitySlotId()];
    }

    @Override
    public int getProtectionAmount(EquipmentSlot slot) {
        return PROTECTION_VALUES[slot.getEntitySlotId()];
    }

    @Override
    public int getEnchantability() {
        return 0;
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ITEM_ARMOR_EQUIP_LEATHER;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return null;
    }

    @Override
    public String getName() {
        return "jetpack_solid_fuel";
    }

    @Override
    public float getToughness() {
        return 0.0F;
    }

    @Override
    public float getKnockbackResistance() {
        return 0.0F;
    }

    public static void useJetpack(ClientPlayerEntity player){
        //System.out.println("derp");
        // Consume fuel.
        if(usedTicks >= ticksPerFuel){
            if(player.inventory.contains(FuelTypes.fuelType[1].getDefaultStack())) {
                PacketByteBuf buf = PacketByteBufs.create();
                buf.writeInt(1); // Send the fuelTypeArray index of desired fuel.
                ClientPlayNetworking.send(PacketIdentifiers.JETPACK_CONSUME_FUEL,buf);
                usedTicks = 0;
            }
        }

        // Activate Jetpack
        if(usedTicks <= ticksPerFuel) {
            usedTicks++;

            // Move player.
            Vec3d v = player.getVelocity();
            double newVy = v.y + acceleration;

            if (newVy <= maxVelocity) {
                player.setVelocity(v.x, newVy, v.z);
            } else {
                player.setVelocity(v.x, maxVelocity, v.z);
            }
            System.out.println(v);

            //Spawn Particles.
            Vec3d p = player.getPos();
            for (double i = -2.0d; i < 2.0d; i += 1.0d) {
                for (double j = -2.0d; j < 2.0d; j += 1.0d) {
                    player.world.addParticle(ParticleTypes.COMPOSTER, p.x + (i / 8), p.y + 1.0d, p.z + (j / 8), 0.15d * i, -0.2d, 0.15d * j);
                }
            }
            player.world.playSound(p.x, p.y, p.z, SoundEvents.ITEM_FIRECHARGE_USE, SoundCategory.PLAYERS, 0.1f, 0.001f, false);
        }
    }
}
