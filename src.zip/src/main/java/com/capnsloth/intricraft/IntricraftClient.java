package com.capnsloth.intricraft;

import com.capnsloth.intricraft.armour.JetpackPlasma;
import com.capnsloth.intricraft.armour.JetpackSolidFuel;
import com.capnsloth.intricraft.blockentity.SteamBlockEntity;
import com.capnsloth.intricraft.entities.mobs.models.ChibiDemonModel;
import com.capnsloth.intricraft.entities.mobs.models.SlothEntityModel;
import com.capnsloth.intricraft.entities.projectiles.MiningLaserProjectile;
import com.capnsloth.intricraft.entities.renderers.*;
import com.capnsloth.intricraft.entities.vehicles.FastMinecart;
import com.capnsloth.intricraft.network.EntitySpawnPacket;
import com.capnsloth.intricraft.network.PacketUtil;
import com.capnsloth.intricraft.registry.ModBlocks;
import com.capnsloth.intricraft.registry.ModEntities;
import com.capnsloth.intricraft.registry.ModItems;
import com.capnsloth.intricraft.network.PacketIdentifiers;
import com.capnsloth.intricraft.registry.ModStructures;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendereregistry.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.event.server.ServerStartCallback;
import net.fabricmc.fabric.api.network.ClientSidePacketRegistry;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.options.KeyBinding;
import net.minecraft.client.particle.ParticleFactory;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.item.Item;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.PacketDeflater;
import net.minecraft.network.encryption.PacketDecryptor;
import net.minecraft.particle.*;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;
import org.lwjgl.glfw.GLFW;

import java.util.UUID;

public class IntricraftClient implements ClientModInitializer {
    // Client Variables & Toggles.
    private boolean jetpackEnabled = true;

    // Keybinds
    private static KeyBinding jetpackToggle;


    @Override
    public void onInitializeClient() {
        ModEntities.RegisterEntityRenderers();
        InitializeKeyBinds();
        RegisterClientSidePacketReceivers();
        ModBlocks.RegisterBlockEntityRenderers();
        ModBlocks.RegisterBlockRenderers();
        ModBlocks.RegisterFluidRenderers();
        ModStructures.RegisterStructures();

    }

    private void InitializeKeyBinds(){

        System.out.println("Initializing keybinds");
        jetpackToggle = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.intricraft.togglejetpack", // The translation key of the keybinding's name
                InputUtil.Type.KEYSYM, // The type of the keybinding, KEYSYM for keyboard, MOUSE for mouse.
                GLFW.GLFW_KEY_G, // The keycode of the key
                "category.intricraft.intricraft" // The translation key of the keybinding's category.
        ));

        //------ Jetpack Control --------------------------------------------------------------------
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Handle jetpack enable on/off.
            if(jetpackToggle.wasPressed()){
                if(jetpackEnabled){ jetpackEnabled = false; }
                else{ jetpackEnabled = true; }
            }

            // Handle jetpack activation.
             if (jetpackEnabled && client.options.keyJump.isPressed()) { // Check if jump key has been pressed.
                // Check if player is wearing jetpack and use appropriate method.
                 Item chestPiece = client.player.inventory.armor.get(2).getItem();
                if(chestPiece == ModItems.JETPACK_SOLID_FUEL) { JetpackSolidFuel.useJetpack(client.player); }
                else if(chestPiece == ModItems.JETPACK_PLASMA){ JetpackPlasma.useJetpack(client.player); }
            }
        });
        //===========================================================================================
    }


    public void RegisterClientSidePacketReceivers() {
        // SPAWN LASER PROJECTILE
        ClientSidePacketRegistry.INSTANCE.register(PacketIdentifiers.SPAWN_LASER_PROJECTILE, (ctx, byteBuf) -> {
            //System.out.println("Client received spawn packet");
            EntityType<?> et = Registry.ENTITY_TYPE.get(byteBuf.readVarInt());
            UUID uuid = byteBuf.readUuid();
            int entityId = byteBuf.readVarInt();
            Vec3d pos = PacketUtil.readVec3d(byteBuf);
            float pitch = PacketUtil.readAngle(byteBuf);
            float yaw = PacketUtil.readAngle(byteBuf);
            int penetration = byteBuf.readInt();
            ctx.getTaskQueue().execute(() -> {
                MiningLaserProjectile projectile = new MiningLaserProjectile(MinecraftClient.getInstance().world, pos.x, pos.y, pos.z);
                projectile.updateTrackedPosition(pos);
                projectile.setPos(pos.x, pos.y, pos.z);
                projectile.pitch = pitch;
                projectile.yaw = yaw;
                projectile.setEntityId(entityId);
                projectile.setUuid(uuid);
                projectile.penetration = penetration;


                MinecraftClient.getInstance().world.addEntity(entityId, projectile);
            });
        });

        // SPAWN FAST MINECART
        ClientSidePacketRegistry.INSTANCE.register(PacketIdentifiers.SPAWN_FAST_MINECART, (ctx, byteBuf) -> {
            //System.out.println("Client received spawn packet");
            EntityType<?> et = Registry.ENTITY_TYPE.get(byteBuf.readVarInt());
            UUID uuid = byteBuf.readUuid();
            int entityId = byteBuf.readVarInt();
            Vec3d pos = PacketUtil.readVec3d(byteBuf);
            float pitch = PacketUtil.readAngle(byteBuf);
            float yaw = PacketUtil.readAngle(byteBuf);
            ctx.getTaskQueue().execute(() -> {
                FastMinecart cart = new FastMinecart(ModEntities.FAST_MINECART,MinecraftClient.getInstance().world, pos.x, pos.y, pos.z);
                cart.updateTrackedPosition(pos);
                cart.setPos(pos.x, pos.y, pos.z);
                cart.pitch = pitch;
                cart.yaw = yaw;
                cart.setEntityId(entityId);
                cart.setUuid(uuid);


                MinecraftClient.getInstance().world.addEntity(entityId, cart);
            });
        });

        // SPAWN MOB
        ClientSidePacketRegistry.INSTANCE.register(PacketIdentifiers.SPAWN_MOB, (ctx, byteBuf) -> {
            //System.out.println("Client received spawn packet");
            EntityType<?> et = Registry.ENTITY_TYPE.get(byteBuf.readVarInt());
            UUID uuid = byteBuf.readUuid();
            int entityId = byteBuf.readVarInt();
            Vec3d pos = PacketUtil.readVec3d(byteBuf);
            float pitch = PacketUtil.readAngle(byteBuf);
            float yaw = PacketUtil.readAngle(byteBuf);
            ctx.getTaskQueue().execute(() -> {
                MobEntity mob = new MobEntity((EntityType<? extends MobEntity>) et, MinecraftClient.getInstance().world) {
                };
                mob.updateTrackedPosition(pos);
                mob.setPos(pos.x, pos.y, pos.z);
                mob.pitch = pitch;
                mob.yaw = yaw;
                mob.setEntityId(entityId);
                mob.setUuid(uuid);


                MinecraftClient.getInstance().world.addEntity(entityId, mob);
            });
        });


        // SYNC ENTITY SITTING
        ClientSidePacketRegistry.INSTANCE.register(PacketIdentifiers.SET_SITTING, (context, buffer) -> {
            //System.out.println("Client received 'set sitting' packet");

            int entityID = buffer.readVarInt();
            boolean sitting = buffer.readBoolean();
            context.getTaskQueue().execute(() -> {
                //System.out.println("Executing order: sity-sit");
                TameableEntity e = (TameableEntity) MinecraftClient.getInstance().world.getEntityById(entityID);
                if(e != null) e.setSitting(sitting);
                //System.out.println("(Packet) Sitting: " + sitting);
            });
        });

        // SET ENTITY VELOCITY
        ClientSidePacketRegistry.INSTANCE.register(PacketIdentifiers.SET_ENTITY_VELOCITY, (context, buffer) -> {
            //System.out.println("Client received 'set sitting' packet");

            int entityID = buffer.readVarInt();
            Vec3d vec = PacketUtil.readVec3d(buffer);
            context.getTaskQueue().execute(() -> {
                //System.out.println("Executing order: sity-sit");
                Entity e = (Entity) MinecraftClient.getInstance().world.getEntityById(entityID);
                if(e != null) e.setVelocity(vec);
                System.out.println("Setting velocity over network");
            });
        });

        // PLAY SOUND
        ClientSidePacketRegistry.INSTANCE.register(PacketIdentifiers.PLAY_SOUND, (context, buffer) -> {
            String idString = buffer.readString();
            Vec3d pos = PacketUtil.readVec3d(buffer);
            int volume = buffer.readInt();
            int pitch = buffer.readInt();
            SoundEvent sound = new SoundEvent(new Identifier(idString));
            MinecraftClient.getInstance().world.playSound(pos.x, pos.y, pos.z, sound, SoundCategory.NEUTRAL, volume, pitch, true);
            System.out.println("Played sound on client");
        });


        // Particles
        ClientSidePacketRegistry.INSTANCE.register(PacketIdentifiers.SPAWN_CRUSHER_PARTICLE, (context, buffer) -> {
            //System.out.println("Client received 'set sitting' packet");
            Vec3d pos = PacketUtil.readVec3d(buffer);
            Vec3d vel = PacketUtil.readVec3d(buffer);
            pos = pos.add(0.5d, 0.5d,0.5d); // Move pos to center of block.
            Vec3d finalPos = pos;
            context.getTaskQueue().execute(() -> {
                for(int x = -1; x<=1; x++){
                    for(int y = -1; y<=1; y++) {
                        for(int z = -1; z<=1; z++) {
                            MinecraftClient.getInstance().world.addParticle(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.STONE.getDefaultState()), finalPos.x + x*0.3f, finalPos.y + y*0.3f, finalPos.z + z*0.3f, x*0.5f, y*0.5f, z*0.5f);
                        }
                    }
                }

            });
        });

        ClientSidePacketRegistry.INSTANCE.register(PacketIdentifiers.SPAWN_PLACER_PARTICLE, (context, buffer) -> {
            System.out.println("Client received 'Spawn Placer Particle' packet");
            Vec3d pos = PacketUtil.readVec3d(buffer);
            Vec3d vel = PacketUtil.readVec3d(buffer);
            context.getTaskQueue().execute(() -> {
                MinecraftClient.getInstance().world.addParticle(ParticleTypes.POOF,  pos.x, pos.y, pos.z, vel.x, vel.y, vel.z);
            });
        });

        // STEAM UPDATE
        ClientSidePacketRegistry.INSTANCE.register(PacketIdentifiers.STEAM_UPDATE, (context, buffer) -> {
            Vec3d pos = PacketUtil.readVec3d(buffer);
            Vec3d prevPos = PacketUtil.readVec3d(buffer);
            int speed = buffer.readInt();
            context.getTaskQueue().execute(() -> {
                SteamBlockEntity steamEntity = (SteamBlockEntity) MinecraftClient.getInstance().world.getBlockEntity(new BlockPos(pos.getX(), pos.getY(), pos.getZ()));
                //System.out.println("Client side SteamBlockEntity: " + steamEntity);
                steamEntity.prevPos = new BlockPos(prevPos);
                steamEntity.speed = speed;
            });
        });

        /*

        ClientSidePacketRegistry.INSTANCE.register(PacketIdentifiers.BLOCKENTITY_FACING, (context, buffer) -> {
            //System.out.println("Client received 'set sitting' packet");

            Vec3d pos = PacketUtil.readVec3d(buffer);
            BlockPos bPos = new BlockPos(pos.x, pos.y, pos.z);
            Vec3d facing = PacketUtil.readVec3d(buffer);
            context.getTaskQueue().execute(() -> {
                CrusherBlockEntity e = (CrusherBlockEntity)MinecraftClient.getInstance().world.getBlockEntity(bPos);
                if(e != null) e.facing = Direction.fromVector((int)facing.x, (int)facing.y, (int)facing.z);
            });
        });
*/

    }
}
