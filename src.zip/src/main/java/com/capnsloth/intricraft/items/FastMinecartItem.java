package com.capnsloth.intricraft.items;

import com.capnsloth.intricraft.entities.vehicles.FastMinecart;
import com.capnsloth.intricraft.registry.ModEntities;
import net.minecraft.block.AbstractRailBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.DispenserBlock;
import net.minecraft.block.dispenser.DispenserBehavior;
import net.minecraft.block.dispenser.ItemDispenserBehavior;
import net.minecraft.block.enums.RailShape;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.entity.vehicle.MinecartEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.MinecartItem;
import net.minecraft.tag.BlockTags;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPointer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

public class FastMinecartItem extends MinecartItem {
    public FastMinecartItem(Settings settings) {
        super(AbstractMinecartEntity.Type.RIDEABLE, settings);
    }

    private static final DispenserBehavior DISPENSER_BEHAVIOR = new ItemDispenserBehavior() {
        private final ItemDispenserBehavior defaultBehavior = new ItemDispenserBehavior();

        @Override
        public ItemStack dispenseSilently(BlockPointer pointer, ItemStack stack) {
            Direction direction = (Direction)pointer.getBlockState().get(DispenserBlock.FACING);
            World world = pointer.getWorld();
            double d = pointer.getX() + (double)direction.getOffsetX() * 1.125D;
            double e = Math.floor(pointer.getY()) + (double)direction.getOffsetY();
            double f = pointer.getZ() + (double)direction.getOffsetZ() * 1.125D;
            BlockPos blockPos = pointer.getBlockPos().offset(direction);
            BlockState blockState = world.getBlockState(blockPos);
            RailShape railShape = blockState.getBlock() instanceof AbstractRailBlock ? (RailShape)blockState.get(((AbstractRailBlock)blockState.getBlock()).getShapeProperty()) : RailShape.NORTH_SOUTH;
            double k;
            if (blockState.isIn(BlockTags.RAILS)) {
                if (railShape.isAscending()) {
                    k = 0.6D;
                } else {
                    k = 0.1D;
                }
            } else {
                if (!blockState.isAir() || !world.getBlockState(blockPos.down()).isIn(BlockTags.RAILS)) {
                    return this.defaultBehavior.dispense(pointer, stack);
                }

                BlockState blockState2 = world.getBlockState(blockPos.down());
                RailShape railShape2 = blockState2.getBlock() instanceof AbstractRailBlock ? (RailShape)blockState2.get(((AbstractRailBlock)blockState2.getBlock()).getShapeProperty()) : RailShape.NORTH_SOUTH;
                if (direction != Direction.DOWN && railShape2.isAscending()) {
                    k = -0.4D;
                } else {
                    k = -0.9D;
                }
            }

            FastMinecart cart = new FastMinecart(ModEntities.FAST_MINECART,world, d, e + k, f);
            if (stack.hasCustomName()) {
                cart.setCustomName(stack.getName());
            }

            System.out.println("Spawned cart dispense method: " + cart);
            world.spawnEntity(cart);
            stack.decrement(1);
            return stack;
        }

        protected void playSound(BlockPointer pointer) {
            pointer.getWorld().syncWorldEvent(1000, pointer.getBlockPos(), 0);
        }
    };

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        BlockPos blockPos = context.getBlockPos();
        BlockState blockState = world.getBlockState(blockPos);
        if (!blockState.isIn(BlockTags.RAILS)) {
            return ActionResult.FAIL;
        } else {
            ItemStack itemStack = context.getStack();
            if (!world.isClient) {
                RailShape railShape = blockState.getBlock() instanceof AbstractRailBlock ? (RailShape)blockState.get(((AbstractRailBlock)blockState.getBlock()).getShapeProperty()) : RailShape.NORTH_SOUTH;
                double d = 0.0D;
                if (railShape.isAscending()) {
                    d = 0.5D;
                }

                FastMinecart cart = new FastMinecart(ModEntities.FAST_MINECART,world, (double)blockPos.getX() + 0.5D, (double)blockPos.getY() + 0.0625D + d, (double)blockPos.getZ() + 0.5D);
                if (itemStack.hasCustomName()) {
                    cart.setCustomName(itemStack.getName());
                }

                System.out.println("Spawned cart: " + cart);
                world.spawnEntity(cart);
            }

            itemStack.decrement(1);
            return ActionResult.success(world.isClient);
        }
    }

}
