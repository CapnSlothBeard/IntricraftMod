package com.capnsloth.intricraft.items.tools;

import com.capnsloth.intricraft.entities.projectiles.MiningLaserProjectile;
import com.capnsloth.intricraft.registry.FuelTypes;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class MiningLaser extends Item {

    public MiningLaser(Settings settings) {
        super(settings);

    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        //System.out.println("Used mining laser");
        ItemStack itemStack = user.getStackInHand(hand); // creates a new ItemStack instance of the user's itemStack in-hand

		//user.getItemCooldownManager().set(this, 5); //Optionally, you can add a cooldown to your item's right-click use, similar to Ender Pearls.


        if (user.inventory.contains(FuelTypes.fuelType[1].getDefaultStack())) {
            user.inventory.removeStack(user.inventory.getSlotWithStack(FuelTypes.fuelType[1].getDefaultStack()), 1);
            MiningLaserProjectile projectile = new MiningLaserProjectile(world, user);
            projectile.penetration = 8;
            projectile.setProperties(user, user.pitch, user.yaw, 0.0F, 1.5F, 0F);
            world.spawnEntity(projectile); // spawns entity
            world.playSound(null, user.getX(), user.getY(), user.getZ(), SoundEvents.ENTITY_FIREWORK_ROCKET_LAUNCH, SoundCategory.NEUTRAL, 0.8F, 2.7F); // plays a globalSoundEvent
        } else if (user.inventory.contains(FuelTypes.fuelType[2].getDefaultStack())) {
            user.inventory.removeStack(user.inventory.getSlotWithStack(FuelTypes.fuelType[2].getDefaultStack()), 1);
            MiningLaserProjectile projectile = new MiningLaserProjectile(world, user);
            projectile.penetration = 1;
            projectile.setProperties(user, user.pitch, user.yaw, 0.0F, 1.5F, 0F);
            world.spawnEntity(projectile); // spawns entity
            world.playSound(null, user.getX(), user.getY(), user.getZ(), SoundEvents.ENTITY_FIREWORK_ROCKET_LAUNCH, SoundCategory.NEUTRAL, 0.5F, 2.3F); // plays a globalSoundEvent
        }


        user.incrementStat(Stats.USED.getOrCreateStat(this));

        return TypedActionResult.success(itemStack, world.isClient());
    }

}
