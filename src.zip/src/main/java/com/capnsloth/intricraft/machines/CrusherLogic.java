package com.capnsloth.intricraft.machines;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.ServerMetadata;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.registry.RegistryKey;
import net.minecraft.world.World;

import java.io.*;
import java.util.*;

public class CrusherLogic {
    public static CrusherLogic INSTANCE;
    public HashMap<Identifier ,List<BlockPos>> workerDeleteQueue;
    public List<CrusherRefresher> refreshers;
    public List<CrusherRefresher> refresherDeleteQueue;
    public HashMap<Identifier,HashMap<BlockPos, CrusherWorker>> crushWorkers; // Maps the crusher workers to block pos and world registry key value.
    private MinecraftServer server;
    //public HashMap<BlockPos, CrusherWorker> crushWorkers;
    public CrusherLogic(MinecraftServer server){
        System.out.println("Crusher Logic Constructed");
        this.server = server;

        INSTANCE = this;
        refreshers = new ArrayList<CrusherRefresher>();
        refresherDeleteQueue = new ArrayList<CrusherRefresher>();

        // Initialize crushWorkers hash map.
        crushWorkers = new HashMap<>();
        for(RegistryKey<World> k : server.getWorldRegistryKeys()){
            crushWorkers.put(k.getValue(), new HashMap<BlockPos, CrusherWorker>());
        }

        // Initialize delete queue.
        workerDeleteQueue = new HashMap<>();
        for(RegistryKey<World> k2 : server.getWorldRegistryKeys()){
            workerDeleteQueue.put(k2.getValue(), new ArrayList<BlockPos>());
        }
    }

    public void serverTick(){

        for(CrusherRefresher rd : refresherDeleteQueue) {
            refreshers.remove(rd);
        }
        refresherDeleteQueue = new ArrayList<CrusherRefresher>(); // Clear list.

        // Do refreshers.
        for(CrusherRefresher r : refreshers){
            r.execute();
        }


        for (RegistryKey<World> worldKey : server.getWorldRegistryKeys()) {
            //System.out.println("Server.getWorldRegistryKeys: " + server.getWorldRegistryKeys());
            // Delete items in delete queue.
            for (BlockPos toDelete : workerDeleteQueue.get(worldKey.getValue())) {
                CrusherWorker debug = crushWorkers.get(worldKey.getValue()).remove(toDelete);
                //System.out.println("Deleted a worker: " + debug);
            }
            workerDeleteQueue.put(worldKey.getValue(), new ArrayList<BlockPos>()); // Clear delete queue for current world.

            // Do tick operations for crushWorkers.
            for (BlockPos p : crushWorkers.get(worldKey.getValue()).keySet()) {
                crushWorkers.get(worldKey.getValue()).get(p).tick();
            }
        }
    }

    public void addRefresher(World world, BlockPos pos){
        refreshers.add(new CrusherRefresher(world, pos));
    }

    public void tryAddWorkerAtLocation(World world, BlockPos pos){
        // If no crush worker exists at location place one.
        if(crushWorkers.get(world.getRegistryKey().getValue()).get(pos) == null){
            crushWorkers.get(world.getRegistryKey().getValue()).put(pos, new CrusherWorker(world, pos));
        }
    }

    public void saveWorkers(MinecraftServer server) throws IOException {

        // Create or overwrite file.
        String filePath =  "./saves/" + server.getSaveProperties().getLevelName() + "/crusher_data.txt";
        System.out.println("Writing crusher data to:  " + filePath);
        File file = new File(filePath);
        if(!file.createNewFile()) file.delete(); // Delete existing file.
        FileWriter fw = new FileWriter(file);

        // Compose file contents.
        for(Identifier id: crushWorkers.keySet()) {
            fw.write("World=");
            fw.write(id.toString());
            fw.write(System.lineSeparator());
            for (BlockPos p : crushWorkers.get(id).keySet()) {
                fw.write(String.valueOf(p.getX()));
                fw.write(",");
                fw.write(String.valueOf(p.getY()));
                fw.write(",");
                fw.write(String.valueOf(p.getZ()));
                fw.write(System.lineSeparator());
            }
        }

        fw.close();
    }

    public void loadWorkers(MinecraftServer server) throws IOException{
        // Read file.
        String filePath =  "./saves/" + server.getSaveProperties().getLevelName() + "/crusher_data.txt";
        File file = new File(filePath);
        Scanner r = new Scanner(file);

        String worldID = "";
        RegistryKey<World> worldRegKey = null;
        while (r.hasNextLine()) {
            String data = r.nextLine();
            //System.out.println("Reading line: " + data);
            if(data.substring(0, 6).equals("World=")){
                worldID = data.substring(6);
                worldRegKey = RegistryKey.of(Registry.DIMENSION, new Identifier(worldID)); // Get the world key from identifier.
                //System.out.println("World id = " + worldID);
                //System.out.println("Set world reg key: " + worldRegKey);
            }
            else{
                // Process coordinates.
                String[] coordsString = data.split(",");
                //System.out.println("Coord string: " + coordsString[0]);
                int[] coords = new int[]{
                        Integer.parseInt(coordsString[0]),
                        Integer.parseInt(coordsString[1]),
                        Integer.parseInt(coordsString[2])
                };

                BlockPos blockPos = new BlockPos(coords[0], coords[1], coords[2]);

                // Add entry to workers map.
                crushWorkers.get(worldRegKey.getValue()).put(blockPos, new CrusherWorker(server.getWorld(worldRegKey), blockPos));
                //System.out.println("Added worker to world " + worldRegKey +" at " +blockPos);
            }
            //System.out.println(data);

            //server.getWorld(RegistryKey.of(Registry.DIMENSION, worldKey.getValue())) // Get the world from identifier.
        }
        r.close();
        
    }

    public class CrusherRefresher{
        public World world;
        public BlockPos[] adjPos = new BlockPos[6];
        public int skippedTicks = 0;
        public CrusherRefresher(World world, BlockPos pos){
            this.world = world;
            adjPos[0] = pos.add(1,0,0);
            adjPos[1] = pos.add(-1,0,0);
            adjPos[2] = pos.add(0,1,0);
            adjPos[3] = pos.add(0,-1,0);
            adjPos[4] = pos.add(0,0,1);
            adjPos[5] = pos.add(0,0,-1);
        }
        public void execute(){
            System.out.println("Executing refreshment.  Tick count: " + skippedTicks);
            if(skippedTicks >= 3) {
                for (BlockPos p : adjPos) {
                    CrusherBlock cb = world.getBlockState(p).getBlock() instanceof CrusherBlock ? (CrusherBlock) world.getBlockState(p).getBlock() : null;
                    //System.out.println("Crusher at " + p + " ? " + cb);
                    if (cb != null) {
                        System.out.println("Refreshing crusher at: " + p);
                        cb.initializeCrusherWorker(world, p, world.getBlockState(p));
                    }
               }
                refresherDeleteQueue.add(this);
            }
            skippedTicks++;
        }
    }
}
