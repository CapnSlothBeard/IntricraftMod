package com.capnsloth.intricraft.machines;

import com.capnsloth.intricraft.network.PacketIdentifiers;
import com.capnsloth.intricraft.network.PacketUtil;
import com.capnsloth.intricraft.network.PosAndVelocityPacket;
import net.minecraft.block.*;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.predicate.entity.EntityPredicates;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class PlacerBlock extends Block {
    public static final BooleanProperty READY_FOR_TRIGGER = BooleanProperty.of("ready_for_trigger");
    public static final DirectionProperty FACING = Properties.FACING;

    public PlacerBlock(Settings settings) {
        super(settings);
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, READY_FOR_TRIGGER);
    }

    public BlockState getPlacementState(ItemPlacementContext ctx) {
        Direction d = ctx.getPlayerLookDirection().getOpposite();
        return getStateManager().getDefaultState().with(FACING, d).with(READY_FOR_TRIGGER, true);
    }

    // Checks for redstone signal. ONLY CALLED ON SERVER SIDE
    public void neighborUpdate(BlockState state, World world, BlockPos pos, Block block, BlockPos fromPos, boolean notify) {
        if (world.isReceivingRedstonePower(pos)) {
            if (state.get(READY_FOR_TRIGGER)) {
                try {
                    placeBlock(state, world, pos);
                } catch (IllegalAccessException e){
                    System.out.println(" Something went wrong placing block :/");
                    e.printStackTrace();
                }
            }
        } else {
            if (!state.get(READY_FOR_TRIGGER))
                world.setBlockState(pos, state.with(READY_FOR_TRIGGER, true));
        }
    }

    @Nullable
    public static Inventory getInventoryAt(World world, double x, double y, double z) {
        Inventory inventory = null;
        BlockPos blockPos = new BlockPos(x, y, z);
        BlockState blockState = world.getBlockState(blockPos);
        Block block = blockState.getBlock();
        if (block instanceof InventoryProvider) {
            inventory = ((InventoryProvider)block).getInventory(blockState, world, blockPos);
        } else if (block.hasBlockEntity()) {
            BlockEntity blockEntity = world.getBlockEntity(blockPos);
            if (blockEntity instanceof Inventory) {
                inventory = (Inventory)blockEntity;
                if (inventory instanceof ChestBlockEntity && block instanceof ChestBlock) {
                    inventory = ChestBlock.getInventory((ChestBlock)block, blockState, world, blockPos, true);
                }
            }
        }

        if (inventory == null) {
            List<Entity> list = world.getOtherEntities((Entity)null, new Box(x - 0.5D, y - 0.5D, z - 0.5D, x + 0.5D, y + 0.5D, z + 0.5D), EntityPredicates.VALID_INVENTORIES);
            if (!list.isEmpty()) {
                inventory = (Inventory)list.get(world.random.nextInt(list.size()));
            }
        }

        return (Inventory)inventory;
    }


    public void placeBlock(BlockState state, World world, BlockPos pos) throws IllegalAccessException {
        System.out.println("Attempting to place a block with placer.");
        BlockPos targetPos = pos.add(state.get(FACING).getVector());
        BlockPos behind = pos.subtract(state.get(FACING).getVector());

        // If target space in front is empty, suck block item from behind and place in-front.
        if(world.getBlockState(targetPos).getBlock() == Blocks.AIR){
            // Look for an inventory behind the block.
            Inventory inventory = getInventoryAt(world, behind.getX(), behind.getY(), behind.getZ());
            if (inventory != null) {
                if(!inventory.isEmpty()){
                    // Search through inventory and take the first block that appears.
                    for(int i = 0; i < inventory.size(); i++){
                        Block b = Block.getBlockFromItem(inventory.getStack(i).getItem()) != null ? Block.getBlockFromItem(inventory.getStack(i).getItem()) : null;
                        if(b != null && b != Blocks.AIR && b.canPlaceAt(b.getDefaultState(), world, targetPos)){

                            // If the block has a facing direction set it the same as this placers FACING.
                            BlockState bState = b.getDefaultState();
                            if(bState.contains(Properties.HORIZONTAL_FACING)){
                                Direction d = Direction.fromHorizontal(state.get(FACING).getHorizontal());
                                bState = bState.with(Properties.HORIZONTAL_FACING, d);
                            }
                            else if(bState.contains(Properties.FACING)){
                                bState = bState.with(Properties.FACING, state.get(FACING));
                            }

                            // Place block in world.
                            world.setBlockState(targetPos, bState);
                            b.onPlaced(world, targetPos, bState, null, inventory.getStack(i));

                            // Take one item.
                            inventory.removeStack(i, 1);

                            // Send particles.
                            Vec3d pSpawnPos = new Vec3d(pos.getX(), pos.getY(), pos.getZ());
                            Vec3d facing = new Vec3d(state.get(FACING).getVector().getX(), state.get(FACING).getVector().getY(), state.get(FACING).getVector().getZ());
                            pSpawnPos = pSpawnPos.add(facing.multiply(0.51f));
                            PacketUtil.SendToAllClients(world, PacketIdentifiers.SPAWN_PLACER_PARTICLE, PosAndVelocityPacket.createBuffer(pSpawnPos, facing));

                            // Reset trigger.
                            world.setBlockState(pos, state.with(READY_FOR_TRIGGER, false));

                            System.out.println("Finished placing from an inventory!   Placed block: " + b);
                            return;
                        }
                    }
                }
            }

            else {
                // Look for dropped items to place.
                List<ItemEntity> itemEntityList = world.getEntitiesByType(EntityType.ITEM, new Box(behind), Objects::nonNull); // Get all item entities behind.

                // Try to convert item entities to blocks, if possible place the first one.
                for (ItemEntity ie : itemEntityList) {
                    Block b = Block.getBlockFromItem(ie.getStack().getItem()) != null ? Block.getBlockFromItem(ie.getStack().getItem()) : null;
                    if (b != null) {

                        // If the block has a facing direction set it the same as this placers FACING.
                        BlockState bState = b.getDefaultState();
                        if(bState.contains(Properties.HORIZONTAL_FACING)){
                            Direction d = Direction.fromHorizontal(state.get(FACING).getHorizontal());
                            bState = bState.with(Properties.HORIZONTAL_FACING, d);
                        }
                        else if(bState.contains(Properties.FACING)){
                            bState = bState.with(Properties.FACING, state.get(FACING));
                        }

                        // Place block in world.
                        world.setBlockState(targetPos, bState);
                        b.onPlaced(world, targetPos, bState, null, ie.getStack());

                        // Take one item.
                        if (ie.getStack().getCount() > 1) ie.getStack().setCount(ie.getStack().getCount() - 1);
                        else ie.remove();

                        // Send particles.
                        Vec3d pSpawnPos = new Vec3d(pos.getX(), pos.getY(), pos.getZ());
                        Vec3d facing = new Vec3d(state.get(FACING).getVector().getX(), state.get(FACING).getVector().getY(), state.get(FACING).getVector().getZ());
                        pSpawnPos = pSpawnPos.add(facing.multiply(0.51f));
                        PacketUtil.SendToAllClients(world, PacketIdentifiers.SPAWN_PLACER_PARTICLE, PosAndVelocityPacket.createBuffer(pSpawnPos, facing));

                        // Reset trigger.
                        world.setBlockState(pos, state.with(READY_FOR_TRIGGER, false));

                        System.out.println("Finished placing from a dropped item!");
                        return;
                    }
                }
            }
        }
    }

    /*public boolean objectContainsField(Object object, String fieldName) {
        return Arrays.stream(object.getClass().getFields())
                .anyMatch(f -> f.getName().equals(fieldName));
    }*/

    /*
    public DirectionProperty getFacingProperty(Block block) throws IllegalAccessException {
        System.out.println("Checking for FACING property");
        Class<?> objectClass = block.getClass();
        for (Field field : objectClass.getFields()) {
            if (field.getName().equals("FACING")) {
                System.out.println("FACING found!");
                return (DirectionProperty) field.get(DirectionProperty.class);
            }
        }
        return null;
    }
*/
    /*
    // Used to set the direction a block is placed.
    public class PlacerPlacementContext extends ItemPlacementContext{
        BlockState state;

        public PlacerPlacementContext(World world, BlockState placerState) {
            super(world.pla, null, null, null);
            state = placerState;
        }

        @Override
        public Direction getPlayerLookDirection() {
            System.out.println("derpity do");
            return Direction.fromVector(state.get(FACING).getVector().getX(), state.get(FACING).getVector().getY(), state.get(FACING).getVector().getZ());
        }
    }*/
}
