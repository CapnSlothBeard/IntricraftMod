package com.capnsloth.intricraft.machines;

import com.capnsloth.intricraft.network.PacketIdentifiers;
import com.capnsloth.intricraft.network.PacketUtil;
import com.capnsloth.intricraft.network.PosAndVelocityPacket;
import net.minecraft.block.*;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.predicate.entity.EntityPredicates;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;

public class BreakerBlock extends Block {
    public static final BooleanProperty READY_FOR_TRIGGER = BooleanProperty.of("ready_for_trigger");
    public static final DirectionProperty FACING = Properties.FACING;

    public BreakerBlock(AbstractBlock.Settings settings) {
        super(settings);
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, READY_FOR_TRIGGER);
    }

    public BlockState getPlacementState(ItemPlacementContext ctx) {
        Direction d = ctx.getPlayerLookDirection().getOpposite();
        return getStateManager().getDefaultState().with(FACING, d).with(READY_FOR_TRIGGER, true);
    }

    // Checks for redstone signal. ONLY CALLED ON SERVER SIDE
    public void neighborUpdate(BlockState state, World world, BlockPos pos, Block block, BlockPos fromPos, boolean notify) {
        if (world.isReceivingRedstonePower(pos)) {
            if (state.get(READY_FOR_TRIGGER)) {
                try {
                    breakBlock(state, world, pos);
                } catch (IllegalAccessException e){
                    System.out.println(" Something went wrong breaking block :/");
                    e.printStackTrace();
                }
            }
        } else {
            if (!state.get(READY_FOR_TRIGGER))
                world.setBlockState(pos, state.with(READY_FOR_TRIGGER, true));
        }
    }

    @Nullable
    public static Inventory getInventoryAt(World world, double x, double y, double z) {
        Inventory inventory = null;
        BlockPos blockPos = new BlockPos(x, y, z);
        BlockState blockState = world.getBlockState(blockPos);
        Block block = blockState.getBlock();
        if (block instanceof InventoryProvider) {
            inventory = ((InventoryProvider)block).getInventory(blockState, world, blockPos);
        } else if (block.hasBlockEntity()) {
            BlockEntity blockEntity = world.getBlockEntity(blockPos);
            if (blockEntity instanceof Inventory) {
                inventory = (Inventory)blockEntity;
                if (inventory instanceof ChestBlockEntity && block instanceof ChestBlock) {
                    inventory = ChestBlock.getInventory((ChestBlock)block, blockState, world, blockPos, true);
                }
            }
        }

        if (inventory == null) {
            List<Entity> list = world.getOtherEntities((Entity)null, new Box(x - 0.5D, y - 0.5D, z - 0.5D, x + 0.5D, y + 0.5D, z + 0.5D), EntityPredicates.VALID_INVENTORIES);
            if (!list.isEmpty()) {
                inventory = (Inventory)list.get(world.random.nextInt(list.size()));
            }
        }

        return (Inventory)inventory;
    }


    public void breakBlock(BlockState state, World world, BlockPos pos) throws IllegalAccessException {

        BlockPos breakPos = pos.add(state.get(FACING).getVector());
        BlockPos behindPos = pos.subtract(state.get(FACING).getVector());

        // Store block drop if any.
        List<ItemStack> loot = world.getBlockState(breakPos).getDroppedStacks(null);
        System.out.println("Loot: " + loot);

        // Break block.
        world.breakBlock(breakPos, false);

        // Deposit broken item behind breaker.
        for(ItemStack s : loot) {
            world.spawnEntity(new ItemEntity(world, behindPos.getX(), behindPos.getY(), behindPos.getZ(), s));
        }
        //Inventory inventory = getInventoryAt(world, behind.getX(), behind.getY(), behind.getZ());
    }
}
