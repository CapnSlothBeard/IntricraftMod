package com.capnsloth.intricraft.machines;

import com.capnsloth.intricraft.network.PacketIdentifiers;
import com.capnsloth.intricraft.network.PacketUtil;
import com.capnsloth.intricraft.network.PlaySoundPacket;
import com.capnsloth.intricraft.network.PosAndVelocityPacket;
import net.minecraft.block.Blocks;
import net.minecraft.entity.ItemEntity;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;

public class CrusherWorker{
    public int breakCounter = 0;
    public BlockPos selfPosition;
    public BlockPos[] adjacentPositions = new BlockPos[6];
    private World world;
    public CrusherWorker(World world, BlockPos position){
        System.out.println("New Crusher Worker Created");

        selfPosition = position;
        this.world = world;

        // Set adjacent positions
        adjacentPositions[0] = position.add(1,0,0);
        adjacentPositions[1] = position.add(-1,0,0);
        adjacentPositions[2] = position.add(0,1,0);
        adjacentPositions[3] = position.add(0,-1,0);
        adjacentPositions[4] = position.add(0,0,1);
        adjacentPositions[5] = position.add(0,0,-1);
    }


    public void tick(){
        int crusherBlockCount = 0;
        CrusherBlock.Crushable operatingCrushable = CrusherBlock.Crushables.blockToCrushable(world.getBlockState(selfPosition).getBlock());
        // Do progress for each adjacent crusher which is triggered.
        for (BlockPos p:adjacentPositions) {
            if(world.getBlockState(p).getBlock() instanceof CrusherBlock){
                // Check if crusher block is facing this worker.
                Vec3i a = selfPosition.add(-p.getX(), -p.getY(), -p.getZ());
                Vec3i b = world.getBlockState(p).get(CrusherBlock.FACING).getVector();
                //System.out.println("Comparing facing: " + a + " with " + b + "....");
                if (a.getX() == b.getX() && a.getY() == b.getY() && a.getZ() == b.getZ()) {
                    //System.out.println("match");
                    crusherBlockCount++;
                    // Check if the worker is triggered.
                    //System.out.println("Checking if triggered: " + world.getBlockState(p).get(CrusherBlock.TRIGGERED));
                    if(world.getBlockState(p).get(CrusherBlock.TRIGGERED)) {
                        //System.out.println("Operating on crushable: " + operatingCrushable);
                        if(operatingCrushable != null) {
                            // Do the crush things.
                            System.out.println("crushcrushcrush");
                            breakCounter++;
                            world.setBlockState(p, world.getBlockState(p).with(CrusherBlock.TRIGGERED, false));
                            Vec3d pos = new Vec3d (selfPosition.getX(), selfPosition.getY(), selfPosition.getZ());
                            PacketUtil.SendToAllClients(world, PacketIdentifiers.PLAY_SOUND,
                                    PlaySoundPacket.createBuffer(SoundEvents.BLOCK_GRAVEL_BREAK.getId().toString(),pos , 1f, 0.4f));
                            PacketUtil.SendToAllClients(world, PacketIdentifiers.SPAWN_CRUSHER_PARTICLE, PosAndVelocityPacket.createBuffer(pos, new Vec3d(0,0,0)));
                        }
                        else{
                            breakCounter = 0;
                        }
                    }
                }
            }
        }

        if(operatingCrushable!=null && breakCounter >= operatingCrushable.breakTime){
            System.out.println("Breaking block");
            world.breakBlock(selfPosition, false);
            world.spawnEntity(new ItemEntity(world, selfPosition.getX(), selfPosition.getY(), selfPosition.getZ(), operatingCrushable.itemDrop.getDefaultStack()));
            // If broken by 6 crushers spawn an extra dust.
            if(crusherBlockCount == 6) world.spawnEntity(new ItemEntity(world, selfPosition.getX(), selfPosition.getY(), selfPosition.getZ(), operatingCrushable.itemDrop.getDefaultStack()));
            breakCounter = 0;
        }

        // Remove self if crusher count is 0.
        if(crusherBlockCount == 0){
            System.out.println("Adding self to delete queue");
            CrusherLogic.INSTANCE.workerDeleteQueue.get(world.getRegistryKey().getValue()).add(this.selfPosition);
        }

    }
}
