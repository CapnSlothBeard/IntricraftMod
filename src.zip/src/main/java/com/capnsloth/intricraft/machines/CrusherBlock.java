package com.capnsloth.intricraft.machines;

import com.capnsloth.intricraft.registry.ModItems;
import net.minecraft.block.*;
import net.minecraft.block.piston.PistonBehavior;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.*;
import net.minecraft.util.math.*;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;;
import org.jetbrains.annotations.Nullable;


public class CrusherBlock extends Block {
    public static final BooleanProperty READY_FOR_TRIGGER = BooleanProperty.of("ready_for_trigger");
    public static final BooleanProperty TRIGGERED = BooleanProperty.of("triggered");
    public static final DirectionProperty FACING = Properties.FACING;
    public static final IntProperty ANIMATION_STATE = IntProperty.of("animation_state", 0,3);


    public CrusherBlock(Settings settings) {
        super(settings);
        this.setDefaultState(getStateManager().getDefaultState().with(READY_FOR_TRIGGER, true).with(FACING, Direction.SOUTH).with(TRIGGERED, false));
    }

    @Override
    public PistonBehavior getPistonBehavior(BlockState state) {
        return PistonBehavior.NORMAL;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, READY_FOR_TRIGGER, ANIMATION_STATE, TRIGGERED);
    }

    @Override
    public BlockRenderType getRenderType(BlockState state) {
        return BlockRenderType.MODEL;
    }


    public BlockState getPlacementState(ItemPlacementContext ctx) {
        Direction d = ctx.getPlayerLookDirection();
        return getStateManager().getDefaultState().with(FACING, d).with(TRIGGERED, false).with(READY_FOR_TRIGGER, true).with(ANIMATION_STATE, 0);
    }

    public void initializeCrusherWorker(World world, BlockPos pos, BlockState state){
        if(!world.isClient) {
            BlockPos targetPos = pos.add(state.get(FACING).getVector());
            CrusherLogic.INSTANCE.tryAddWorkerAtLocation(world, targetPos);
        }
    }

    @Override
    public void onStateReplaced(BlockState state, World world, BlockPos pos, BlockState newState, boolean moved) {
        if(moved) { // Only activate if moved by piston or the like.
            System.out.println("Summoning refresher at: " + pos);
            CrusherLogic.INSTANCE.addRefresher(world, pos);
        }
        super.onStateReplaced(state, world, pos, newState, moved);
    }


    @Override
    public void onPlaced(World world, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack itemStack) {
        super.onPlaced(world, pos, state, placer, itemStack);
        initializeCrusherWorker(world, pos, state);
    }

    // Checks for redstone signal. ONLY CALLED ON SERVER SIDE
    public void neighborUpdate(BlockState state, World world, BlockPos pos, Block block, BlockPos fromPos, boolean notify) {
        if (world.isReceivingRedstonePower(pos)) {
            if (state.get(READY_FOR_TRIGGER)) {
                updateAnimationState(state, world, pos);
            }
        } else {
            if (!state.get(READY_FOR_TRIGGER))
                world.setBlockState(pos, state.with(READY_FOR_TRIGGER, true).with(TRIGGERED, false));
        }
    }

    public void updateAnimationState(BlockState state, World world, BlockPos pos){
        int i = state.get(ANIMATION_STATE);
        i++;
        if(i > 3) i=0;
        world.setBlockState(pos, state.with(ANIMATION_STATE, i).with(READY_FOR_TRIGGER, false).with(TRIGGERED, true));
    }

    // Set the bounding box shape for the block.
    @Override
    public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        float iA = (1f/16f)*2f; // "(1f/16f)" Coverts per-pixel units to minecraft units.
        float riA = (1f/16f)*14f;
        Vec3i fV = state.get(FACING).getVector();
        Vec3d shapePos = new Vec3d(
                (fV.getX() < 0) ? iA : 0,
                (fV.getY() < 0) ? iA : 0,
                (fV.getZ() < 0) ? iA : 0
        );
        Vec3d shapeSize = new Vec3d(
                (fV.getX() > 0) ? riA : 1,
                (fV.getY() > 0) ? riA : 1,
                (fV.getZ() > 0) ? riA : 1
        );

        return VoxelShapes.cuboid(shapePos.x, shapePos.y, shapePos.z, shapeSize.x, shapeSize.y, shapeSize.z);
    }


    public static class Crushable{
        public Block blockType;
        public Item itemDrop;
        public int dropQuantity;
        public int breakTime;
        public Crushable(Block blockType, Item dropItem, int dropQuantity, int breakTime){
            this.blockType = blockType; this.itemDrop = dropItem; this.dropQuantity = dropQuantity; this.breakTime = breakTime;
        }

        @Override
        public String toString() {
            return "Crushable{" +
                    "blockType=" + blockType +
                    '}';
        }
    }

    public static class Crushables{
        private static final Crushable[] crushables = new Crushable[]{
                new Crushable(Blocks.IRON_ORE, ModItems.DUST_IRON, 1, 6),
                // new Crushable COAL_ORE = new Crushable(Blocks.COAL_ORE, ModItems.DUST_COAL, 1, 1f)
        };

        public static Crushable blockToCrushable(Block block){
            for (Crushable crushable:crushables) {
                //System.out.println("Comparing: " + crushable + "  to block: " + block);
                if(crushable.blockType == block){
                    //System.out.println("Derp");
                    return crushable;
                }
            }
            return null;
        }
    }

}
