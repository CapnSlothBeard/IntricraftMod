package com.capnsloth.intricraft.machines;


import com.capnsloth.intricraft.network.*;
import com.capnsloth.intricraft.registry.ModItems;
import net.fabricmc.fabric.api.event.server.ServerTickCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.*;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.piston.PistonBehavior;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.Schedule;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.*;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.ItemScatterer;
import net.minecraft.util.Tickable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import org.jetbrains.annotations.Nullable;

import java.util.Random;

public class CrusherBlock extends Block {
    public static final BooleanProperty TRIGGERED = BooleanProperty.of("triggered");
    public static final DirectionProperty FACING = Properties.FACING;
    public static final IntProperty ANIMATION_STATE = IntProperty.of("animation_state", 0,3);
    public boolean isActivated = false;
    public int breakTimer = 0;
    private final int breakTime = 10;
    public boolean readyForNextRedstoneInput = true;


    public CrusherBlock(Settings settings) {
        super(settings);
        this.setDefaultState(this.stateManager.getDefaultState().with(TRIGGERED, false).with(FACING, Direction.SOUTH));
    }

    @Override
    public PistonBehavior getPistonBehavior(BlockState state) {
        return PistonBehavior.NORMAL;
    }

    public void resetBreak(){
        breakTimer = 0;
        //if(!world.isClient)PacketUtil.SendToAllClients(world, PacketIdentifiers.CRUSHER_ACTIVATED, BlockEntityBoolPacket.createBuffer(this, false));
    }
    public void beginActivation(){
        this.isActivated = true;
    }
    public void stopActivation(){
        this.isActivated = false;
        resetBreak();
    }

/*
    @Override
    public void onPlaced(World world, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack itemStack) {
        super.onPlaced(world, pos, state, placer, itemStack);
        this.world = world;
        this.position = pos;
    }


    @Override
    public void onBroken(WorldAccess world, BlockPos pos, BlockState state) {
        super.onBroken(world, pos, state);
    }
*/
    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(new Property[]{FACING, TRIGGERED, ANIMATION_STATE});
    }

    @Override
    public BlockRenderType getRenderType(BlockState state) {
        return BlockRenderType.MODEL;
    }


    public BlockState getPlacementState(ItemPlacementContext ctx) {
        Direction d = ctx.getPlayerLookDirection();
        //System.out.println("Placed crusher.  " + d.toString());
        return (BlockState)this.getDefaultState().with(Properties.FACING, d);
    }

    // Checks for redstone signal. ONLY CALLED ON SERVER SIDE
    public void neighborUpdate(BlockState state, World world, BlockPos pos, Block block, BlockPos fromPos, boolean notify) {
            if (world.isReceivingRedstonePower(pos)) {
                world.setBlockState(pos, getStateManager().getDefaultState().with(TRIGGERED, true).with(FACING, state.get(FACING)).with(ANIMATION_STATE, state.get(ANIMATION_STATE)));
                if (readyForNextRedstoneInput) {
                    doCrush(world, pos, state);
                    readyForNextRedstoneInput = false;
                }
            } else {
                world.setBlockState(pos, getStateManager().getDefaultState().with(TRIGGERED, false).with(FACING, state.get(FACING)).with(ANIMATION_STATE, state.get(ANIMATION_STATE)));
                if (!readyForNextRedstoneInput) readyForNextRedstoneInput = true;
            }
    }


    public void updateAnimationState(BlockState state, World world, BlockPos pos){
        int i = state.get(ANIMATION_STATE);
        i++;
        if(i > 3) i=0;
        //this.getDefaultState().with(ANIMATION_STATE, i);
        world.setBlockState(pos, getStateManager().getDefaultState().with(TRIGGERED, state.get(TRIGGERED)).with(FACING, state.get(FACING)).with(ANIMATION_STATE, i));
        //System.out.println("Updated anim state: " + i);
    }

    // Set the bounding box shape for the block.
    @Override
    public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        float iA = (1f/16f)*2f; // "(1f/16f)" Coverts per-pixel units to minecraft units.
        float riA = (1f/16f)*14f;
        Vec3i fV = state.get(FACING).getVector();
        Vec3d shapePos = new Vec3d(
                (fV.getX() < 0) ? iA : 0,
                (fV.getY() < 0) ? iA : 0,
                (fV.getZ() < 0) ? iA : 0
        );
        Vec3d shapeSize = new Vec3d(
                (fV.getX() > 0) ? riA : 1,
                (fV.getY() > 0) ? riA : 1,
                (fV.getZ() > 0) ? riA : 1
        );
        //System.out.println("FACING: " + fV);
        return VoxelShapes.cuboid(shapePos.x, shapePos.y, shapePos.z, shapeSize.x, shapeSize.y, shapeSize.z);
    }

    public void doCrush(World world, BlockPos pos, BlockState state) {
            CrusherBlock cb = (CrusherBlock) world.getBlockState(pos).getBlock();
            cb.updateAnimationState(world.getBlockState(pos), world, pos);

            BlockPos targetPos = pos.add(state.get(FACING).getVector());
            Block targetBlock = world.getBlockState(targetPos).getBlock();
            //System.out.println("Target Block: " + targetBlock);
            Crushable crushableBlock = Crushables.blockToCrushable(targetBlock);
            if (crushableBlock != null) {
                PacketUtil.SendToAllClients(world, PacketIdentifiers.PLAY_SOUND, PlaySoundPacket.createBuffer(SoundEvents.BLOCK_GRAVEL_BREAK.getId().toString(), new Vec3d(pos.getX(), pos.getY(), pos.getZ()), 1f, 0.4f));
                breakTimer++;
                Vec3d dir = new Vec3d(state.get(FACING).getVector().getX(), state.get(FACING).getVector().getY(), state.get(FACING).getVector().getZ());
                Vec3d particlePos = new Vec3d((double) pos.getX() + (dir.x * 0.7d) + 0.5d, (double) pos.getY() + (dir.y * 0.7d) + 0.5d, (double) pos.getZ() + (dir.z * 0.7d) + 0.5d);
                Vec3d velocity = new Vec3d(0.2f * (1 - dir.x), 0.2f * (1 - dir.y), 0.2f * (1 - dir.z));
                //world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, particlePos.x, particlePos.y, particlePos.z, velocity.x, velocity.y, velocity.z);
                //PacketUtil.SendToAllClients(world, PacketIdentifiers.SPAWN_PARTICLE, SpawnParticlePacket.createBuffer(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, particlePos, velocity));
                if (breakTimer >= (int) (breakTime * crushableBlock.breakTimeMultiplier)) {
                    world.breakBlock(targetPos, false);
                    world.spawnEntity(new ItemEntity(world, targetPos.getX(), targetPos.getY(), targetPos.getZ(), crushableBlock.itemDrop.getDefaultStack()));
                    resetBreak();
                }
            }
    }

    /*public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new CrusherBlockEntity(pos, state);
    }*/

    /*@Nullable
    @Override
    public BlockEntity createBlockEntity(BlockView world) {
        return new CrusherBlockEntity();
    }*/

    public static class Crushable{
        public Block blockType;
        public Item itemDrop;
        public int dropQuantity;
        public float breakTimeMultiplier;
        public Crushable(Block blockType, Item dropItem, int dropQuantity, float breakTimeMultiplier){
            this.blockType = blockType; this.itemDrop = dropItem; this.dropQuantity = dropQuantity; this.breakTimeMultiplier = breakTimeMultiplier;
        }
    }

    public static class Crushables{
        private static final Crushable[] crushables = new Crushable[]{
                new Crushable(Blocks.IRON_ORE, ModItems.DUST_IRON, 1, 0.6f),
                // new Crushable COAL_ORE = new Crushable(Blocks.COAL_ORE, ModItems.DUST_COAL, 1, 1f)
        };

        public static Crushable blockToCrushable(Block block){
            for (Crushable crushable:crushables) {
                //System.out.println("Comparing: " + crushable + "  to block: " + block);
                if(crushable.blockType == block){
                    //System.out.println("Derp");
                    return crushable;
                }
            }
            return null;
        }
    }
}
