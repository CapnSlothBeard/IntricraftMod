package com.capnsloth.intricraft.machines;

import com.capnsloth.intricraft.network.BlockEntityBoolPacket;
import com.capnsloth.intricraft.network.BlockEntityFacingPacket;
import com.capnsloth.intricraft.network.PacketIdentifiers;
import com.capnsloth.intricraft.network.PacketUtil;
import com.capnsloth.intricraft.registry.ModBlocks;
import com.capnsloth.intricraft.registry.ModItems;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.Item;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.Tickable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/*
public class CrusherBlockEntity extends BlockEntity implements Tickable {

    public boolean isActivated = false;
    public Direction facing = Direction.NORTH;
    public int breakTimer = 0;
    private final int breakTime = 90;
    public boolean validCrushable = false;

    public CrusherBlockEntity() {
        super(ModBlocks.CRUSHER_BLOCKENTITY);
    }

    public void beginActivation(Direction facingDirection){
        setFacing(facingDirection);
        this.isActivated = true;
    }
    public void stopActivation(){
        this.isActivated = false;
        resetBreak();
    }

    public void setFacing(Direction facingDirection){
        this.facing = facingDirection;
    }
    public void resetBreak(){
        breakTimer = 0;
        validCrushable = false;
        if(!world.isClient)PacketUtil.SendToAllClients(world, PacketIdentifiers.CRUSHER_ACTIVATED, BlockEntityBoolPacket.createBuffer(this, false));
    }

    @Override
    public CompoundTag toTag(CompoundTag tag) {
        super.toTag(tag);
        tag.putBoolean("isActivated", isActivated);
        return tag;
    }

    @Override
    public void fromTag(BlockState state, CompoundTag tag) {
        super.fromTag(state, tag);
        isActivated = tag.getBoolean("isActivated");
    }

    @Override
    public void tick() {
        if(!world.isClient) {
            if (isActivated) {
                CrusherBlock cb = (CrusherBlock) world.getBlockState(pos).getBlock();
                cb.updateAnimationState(world.getBlockState(pos), world, pos);

                BlockPos targetPos = pos.add(facing.getVector());
                Block targetBlock = world.getBlockState(targetPos).getBlock();
                //System.out.println("Target Block: " + targetBlock);
                Crushable crushableBlock = Crushables.blockToCrushable(targetBlock);
                if (crushableBlock != null) {
                    //System.out.println(crushableBlock.blockType);
                    validCrushable = true;
                    PacketUtil.SendToAllClients(world, PacketIdentifiers.CRUSHER_ACTIVATED, BlockEntityBoolPacket.createBuffer(this, true));
                    PacketUtil.SendToAllClients(world, PacketIdentifiers.BLOCKENTITY_FACING, BlockEntityFacingPacket.createBuffer(this, this.facing.getVector()));
                    breakTimer++;
                    Vec3d dir = new Vec3d(facing.getVector().getX(), facing.getVector().getY(), facing.getVector().getZ());
                    Vec3d particlePos = new Vec3d((double) pos.getX() + (dir.x * 0.7d) + 0.5d, (double) pos.getY() + (dir.y * 0.7d) + 0.5d, (double) pos.getZ() + (dir.z * 0.7d) + 0.5d);
                    Vec3d velocity = new Vec3d(0.2f * (1 - dir.x), 0.2f * (1 - dir.y), 0.2f * (1 - dir.z));
                    //world.addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, particlePos.x, particlePos.y, particlePos.z, velocity.x, velocity.y, velocity.z);
                    //PacketUtil.SendToAllClients(world, PacketIdentifiers.SPAWN_PARTICLE, SpawnParticlePacket.createBuffer(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, particlePos, velocity));
                    if (breakTimer >= (int) (breakTime * crushableBlock.breakTimeMultiplier)) {
                        world.breakBlock(targetPos, false);
                        world.spawnEntity(new ItemEntity(world, targetPos.getX(), targetPos.getY(), targetPos.getZ(), crushableBlock.itemDrop.getDefaultStack()));
                        resetBreak();
                    }
                }
            } else {
                resetBreak();
            }
        }

    }



    private static class Crushable{
        public Block blockType;
        public Item itemDrop;
        public int dropQuantity;
        public float breakTimeMultiplier;
        public Crushable(Block blockType, Item dropItem, int dropQuantity, float breakTimeMultiplier){
            this.blockType = blockType; this.itemDrop = dropItem; this.dropQuantity = dropQuantity; this.breakTimeMultiplier = breakTimeMultiplier;
        }
    }

    private static class Crushables{
        private static final Crushable[] crushables = new Crushable[]{
                new Crushable(Blocks.IRON_ORE, ModItems.DUST_IRON, 1, 1f),
               // new Crushable COAL_ORE = new Crushable(Blocks.COAL_ORE, ModItems.DUST_COAL, 1, 1f)
        };

        private static Crushable blockToCrushable(Block block){
            for (Crushable crushable:crushables) {
                //System.out.println("Comparing: " + crushable + "  to block: " + block);
                if(crushable.blockType == block){
                    //System.out.println("Derp");
                    return crushable;
                }
            }
            return null;
        }
    }
}

 */
