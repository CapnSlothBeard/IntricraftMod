package com.capnsloth.intricraft.machines;

import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;

import java.util.HashMap;

public class ConveyorLogic {
    public static ConveyorLogic INSTANCE;

    private HashMap<BlockPos, HashMap<BlockPos, BlockState>> conveyorData;

    public ConveyorLogic(){
        INSTANCE = this;
        conveyorData = new HashMap<>();
    }

    public HashMap<BlockPos, BlockState> getMap(BlockPos conveyorPos){
        return conveyorData.get(conveyorPos);
    }

    public void putMap(BlockPos conveyorPos, HashMap<BlockPos, BlockState> map){
        conveyorData.put(conveyorPos, map);
    }

    public void removeMap(BlockPos conveyorPos){
        conveyorData.remove(conveyorPos);
    }

}
