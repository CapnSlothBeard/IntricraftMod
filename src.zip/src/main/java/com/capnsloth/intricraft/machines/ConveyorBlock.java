package com.capnsloth.intricraft.machines;


import com.capnsloth.intricraft.network.EntityVectorPacket;
import com.capnsloth.intricraft.network.PacketIdentifiers;
import com.capnsloth.intricraft.network.PacketUtil;
import com.capnsloth.intricraft.registry.ModBlocks;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import net.minecraft.block.*;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.piston.PistonHandler;
import net.minecraft.entity.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.*;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

import java.util.*;

public class ConveyorBlock extends FacingBlock {

    private static final double moveItemVelocity = 0.7d;
    public static final BooleanProperty TRIGGERED = Properties.TRIGGERED;

    public ConveyorBlock(Settings settings) {
        super(settings);
    }


    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, TRIGGERED);
    }
    public BlockState getPlacementState(ItemPlacementContext ctx) {
        Direction d = ctx.getPlayerFacing().getOpposite();
        System.out.println(d);
        return getStateManager().getDefaultState().with(FACING, d).with(TRIGGERED, false);
    }


    // Set the bounding box shape for the block.
    @Override
    public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        float adjustedPos = (1f/16f)*1f; // "(1f/16f)" Coverts per-pixel units to minecraft units.
        float adjustedSize = (1f/16f)*15f;
        Vec3i facingVector = state.get(FACING).getVector();
        Vec3d shapePos = new Vec3d(
                (facingVector.getZ() != 0 || facingVector.getY() > 0) ? adjustedPos : 0,
                0,
                (facingVector.getX() != 0 || facingVector.getY() < 0) ? adjustedPos : 0
        );
        Vec3d shapeSize = new Vec3d(
                (facingVector.getZ() != 0 || facingVector.getY() > 0) ? adjustedSize : 1,
                1,
                (facingVector.getX() != 0 || facingVector.getY() < 0) ? adjustedSize : 1
        );

        return VoxelShapes.cuboid(shapePos.x, shapePos.y, shapePos.z, shapeSize.x, shapeSize.y, shapeSize.z);
    }


    @Override
    public void neighborUpdate(BlockState state, World world, BlockPos pos, Block block, BlockPos fromPos, boolean notify) {
        if (!world.isClient) {
            boolean powered = world.isReceivingRedstonePower(pos);
            if (powered && !(Boolean)state.get(TRIGGERED)) {
                world.setBlockState(pos, state.with(TRIGGERED, true));
                world.addSyncedBlockEvent(pos, this, 0, 0);
            }
            else if(!powered && state.get(TRIGGERED)){
                //System.out.println("Resetting");
                world.setBlockState(pos, state.with(TRIGGERED, false));
            }

        }
    }

    public void activate(BlockState state, World world, BlockPos pos){

        HashMap<BlockPos, BlockState> moveMap = new HashMap<>();

        BlockPos posInfront = new BlockPos(pos.add(state.get(FACING).getVector()));
        BlockPos posBehind = new BlockPos(pos.add(state.get(FACING).getOpposite().getVector()));

        BlockPos above = new BlockPos(posBehind.getX(), posBehind.getY() + 1, posBehind.getZ());
        BlockPos below = new BlockPos(posInfront.getX(), posInfront.getY() - 1, posInfront.getZ());
        BlockPos infront = new BlockPos(posInfront.getX(), posInfront.getY() + 1, posInfront.getZ());
        BlockPos behind = new BlockPos(posBehind.getX(), posBehind.getY() - 1, posBehind.getZ());

        moveMap.putAll(this.tryMove(world, above, state, state.get(FACING), pos, 0));
        moveMap.putAll(this.tryMove(world, below, state, state.get(FACING).getOpposite(), pos,1));
        moveMap.putAll(this.tryMove(world, infront, state, Direction.DOWN, pos,2));
        moveMap.putAll(this.tryMove(world, behind, state, Direction.UP, pos,3));

        ConveyorLogic.INSTANCE.putMap(pos,moveMap);
        world.getBlockTickScheduler().schedule(pos, this, 1);
    }

    protected void moveItems(World world, BlockPos pos, Direction direction){

        List<Entity> playerEntityList = world.getEntitiesByClass(Entity.class, new Box(pos), Objects::nonNull);
        for(Entity p : playerEntityList){
            Vec3d v = Vec3d.of(direction.getVector()).multiply(moveItemVelocity);
            p.setVelocity(v);
            PacketUtil.SendToAllClients(world, PacketIdentifiers.SET_ENTITY_VELOCITY, EntityVectorPacket.createBuffer(p, v));
        }
    }

    private BlockPos selectWorkCorner(BlockPos pos, BlockState state, int data){
        BlockPos posInfront = new BlockPos(pos.add(state.get(FACING).getVector()));
        BlockPos posBehind =new BlockPos(pos.add(state.get(FACING).getOpposite().getVector()));
        switch (data){
            case 0: return new BlockPos(posBehind.getX(), posBehind.getY()+1, posBehind.getZ()); // Above/behind
            case 1: return new BlockPos(posInfront.getX(), posInfront.getY()-1, posInfront.getZ()); // Below/infront
            case 2: return new BlockPos(posInfront.getX(), posInfront.getY()+1, posInfront.getZ()); // Infront/above
            case 3: return new BlockPos(posBehind.getX(), posBehind.getY()-1, posBehind.getZ()); // Behind/below
            default: return null;
        }
    }
    private Direction selectWorkDirection(BlockState state, int data){
        switch (data){
            case 0: return state.get(FACING); // Above/behind
            case 1: return state.get(FACING).getOpposite(); // Below/infront
            case 2: return Direction.DOWN; // Infront/above
            case 3: return Direction.UP; // Behind/below
            default: return null;
        }
    }


    private HashMap<BlockPos, BlockState> tryMove(World world, BlockPos pos, BlockState state, Direction direction, BlockPos conveyorPos, int cornerId) {

        moveItems(world, pos.offset(direction), direction);

        if ((new PistonHandler(world, pos, direction, true)).calculatePush()) {
            return move(world, pos, direction, conveyorPos);
        }
        return new HashMap<>();
    }

    @Override
    public void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        super.scheduledTick(state, world, pos, random);

        // Place block stored in the conveyor logic data map.
        HashMap<BlockPos, BlockState> map = ConveyorLogic.INSTANCE.getMap(pos);
        if(map != null) {
            Iterator mapIter = map.entrySet().iterator();
            BlockPos blockPos;
            while (mapIter.hasNext()) {
                Map.Entry<BlockPos, BlockState> entry = (Map.Entry) mapIter.next();
                blockPos = (BlockPos) entry.getKey();
                BlockState blockState = (BlockState) entry.getValue();
                world.setBlockState(blockPos, blockState);

            }
        }
    }


    public boolean onSyncedBlockEvent(BlockState state, World world, BlockPos pos, int type, int data) {


        if(!world.isClient) activate(state, world, pos);

        world.setBlockState(pos, (BlockState)state.with(TRIGGERED, true), 67);
        world.playSound((PlayerEntity)null, pos, SoundEvents.BLOCK_PISTON_EXTEND, SoundCategory.BLOCKS, 0.5F, world.random.nextFloat() * 0.25F + 0.6F);

        return true;
    }

    private HashMap<BlockPos, BlockState> move(World world, BlockPos pos, Direction dir, BlockPos conveyorPos) {
        //System.out.println("move called");
        BlockPos blockPos = pos.offset(dir);

        PistonHandler pistonHandler = new PistonHandler(world, pos, dir, true);
        if (!pistonHandler.calculatePush()) {
            //System.out.println("Unable to push.");
            return new HashMap<>();
        } else {
            //System.out.println("Pushing");

            Map<BlockPos, BlockState> map = Maps.newHashMap();
            HashMap<BlockPos, BlockState> moveMap = new HashMap<>();
            List<BlockPos> movedBlockPositions = pistonHandler.getMovedBlocks();
            List<BlockPos> destroyBlockPositions = pistonHandler.getBrokenBlocks();
            BlockState[] blockStates = new BlockState[movedBlockPositions.size() + destroyBlockPositions.size()];
            List<BlockState> statesToMove = Lists.newArrayList();

            // Make sure conveyor block is not in the move or break list.
            movedBlockPositions.remove(conveyorPos);
            destroyBlockPositions.remove(conveyorPos);


            // Populate a list with blockstates of blocks moved.

            for(int i = 0; i < movedBlockPositions.size(); ++i) {
                BlockPos bPos = (BlockPos)movedBlockPositions.get(i);
                BlockState blockState = world.getBlockState(bPos);
                statesToMove.add(blockState);
                map.put(bPos, blockState);
            }


            int j = 0;

            // Break block list.
            int l;
            BlockPos workPos;
            BlockState workState;
            for(l = destroyBlockPositions.size() - 1; l >= 0; --l) {
                workPos = (BlockPos)destroyBlockPositions.get(l);
                workState = world.getBlockState(workPos);
                BlockEntity blockEntity = workState.getBlock().hasBlockEntity() ? world.getBlockEntity(workPos) : null;
                dropStacks(workState, world, workPos, blockEntity);
                world.setBlockState(workPos, Blocks.AIR.getDefaultState(), 18);
                //System.out.println("Broke block at " + workPos);
                blockStates[j++] = workState;
            }

            // Move blocks along.
            for(l = movedBlockPositions.size() - 1; l >= 0; --l) {
                workPos = (BlockPos)movedBlockPositions.get(l);
                workState = world.getBlockState(workPos);
                BlockPos newPos = workPos.offset(dir);
                map.remove(newPos);
                moveMap.put(newPos, workState);

                blockStates[j++] = workState;
            }



            // Fill moved spaces with air.
            BlockState airBlock = Blocks.AIR.getDefaultState();
            Iterator<BlockPos> airPosIterator = map.keySet().iterator();
            while(airPosIterator.hasNext()) {
                BlockPos blockPos5 = (BlockPos)airPosIterator.next();
                world.setBlockState(blockPos5, airBlock, 82);
                //System.out.println("Set air block at " + blockPos5);
            }


            // Update neighbours.
            Iterator mapIter = map.entrySet().iterator();
            BlockPos blockPos7;
            while(mapIter.hasNext()) {
                Map.Entry<BlockPos, BlockState> entry = (Map.Entry)mapIter.next();
                blockPos7 = (BlockPos)entry.getKey();
                BlockState blockState7 = (BlockState)entry.getValue();
                blockState7.prepare(world, blockPos7, 2);
                //airBlock.updateNeighbors(world, blockPos7, 2);
                updateNeighborsExceptConveyor(blockPos7, airBlock.getBlock(), world);
                airBlock.prepare(world, blockPos7, 2);
            }

            j = 0;

            int n;
            for(n = destroyBlockPositions.size() - 1; n >= 0; --n) {
                workState = blockStates[j++];
                blockPos7 = (BlockPos)destroyBlockPositions.get(n);
                workState.prepare(world, blockPos7, 2);
                updateNeighborsExceptConveyor(blockPos7, workState.getBlock(), world);
            }

            for(n = movedBlockPositions.size() - 1; n >= 0; --n) {
                updateNeighborsExceptConveyor((BlockPos)movedBlockPositions.get(n), blockStates[j++].getBlock(), world);
            }

            return moveMap;
        }
    }

    public void updateNeighborsExceptConveyor(BlockPos pos, Block sourceBlock, World world) {
        if (world.getBlockState(pos.west()).getBlock() != ModBlocks.CONVEYOR_BLOCK) {
            world.updateNeighbor(pos.west(), sourceBlock, pos);
        }

        if (world.getBlockState(pos.east()).getBlock() != ModBlocks.CONVEYOR_BLOCK) {
            world.updateNeighbor(pos.east(), sourceBlock, pos);
        }

        if (world.getBlockState(pos.down()).getBlock() != ModBlocks.CONVEYOR_BLOCK) {
            world.updateNeighbor(pos.down(), sourceBlock, pos);
        }

        if (world.getBlockState(pos.up()).getBlock() != ModBlocks.CONVEYOR_BLOCK) {
            world.updateNeighbor(pos.up(), sourceBlock, pos);
        }

        if (world.getBlockState(pos.north()).getBlock() != ModBlocks.CONVEYOR_BLOCK) {
            world.updateNeighbor(pos.north(), sourceBlock, pos);
        }

        if (world.getBlockState(pos.south()).getBlock() != ModBlocks.CONVEYOR_BLOCK) {
            world.updateNeighbor(pos.south(), sourceBlock, pos);
        }

    }
}
