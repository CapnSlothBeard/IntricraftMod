package com.capnsloth.intricraft.blockentity.renderers;

import com.capnsloth.intricraft.blockentity.SteamBlockEntity;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.render.block.entity.BlockEntityRenderDispatcher;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

import java.util.HashMap;

public class SteamBlockEntityRenderer<T extends SteamBlockEntity> extends BlockEntityRenderer<T> {
    public SteamBlockEntityRenderer(BlockEntityRenderDispatcher dispatcher) {
        super(dispatcher);
    }

    @Override
    public void render(T entity, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, int overlay) {
        matrices.push();

        float ticksToComplete = (float)T.tickEvery/entity.speed;
        Vec3d newPos;
        // Calculate the smooth offset to make steam move to it's new position. Supporting variables given to client via packet (prevPos) or parallel execution (tickCount).
        if(entity.prevPos != null && !entity.prevPos.equals(new BlockPos(Vec3i.ZERO))){
            Vec3d direction = new Vec3d((entity.getPos().getX() - entity.prevPos.getX()), (entity.getPos().getY() - entity.prevPos.getY()), (entity.getPos().getZ() - entity.prevPos.getZ()));
            newPos = new Vec3d(
                    (direction.x * ((entity.tickCount +1) / ticksToComplete)),
                    (direction.y *  ((entity.tickCount +1) / ticksToComplete)),
                    (direction.z *  ((entity.tickCount +1) / ticksToComplete))
            );

            Vec3d offset = new Vec3d(newPos.x - direction.x, newPos.y - direction.y, newPos.z - direction.z);
            matrices.translate(offset.x, offset.y, offset.z);
        }

        if(entity.prevPos != null){ // This makes flicking of BlockEntity spawning less noticable.
            BlockRenderManager brm = MinecraftClient.getInstance().getBlockRenderManager();
            BlockState state = entity.getCachedState();
            BakedModel bakedModel = brm.getModel(state);
            brm.getModelRenderer().render(matrices.peek(), vertexConsumers.getBuffer(RenderLayers.getEntityBlockLayer(state, false)), state, bakedModel, 1.0f, 1.0f, 1.0f, light, overlay); // f, g and h are colours r,g,b
        }



        matrices.pop();
    }
}
