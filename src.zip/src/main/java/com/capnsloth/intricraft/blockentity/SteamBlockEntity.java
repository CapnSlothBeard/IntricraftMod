package com.capnsloth.intricraft.blockentity;

import com.capnsloth.intricraft.IntricraftMain;
import com.capnsloth.intricraft.blocks.SteamBlock;
import com.capnsloth.intricraft.network.PacketIdentifiers;
import com.capnsloth.intricraft.network.PacketUtil;
import com.capnsloth.intricraft.network.SteamUpdatePacket;
import com.capnsloth.intricraft.registry.ModBlocks;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtHelper;
import net.minecraft.util.Identifier;
import net.minecraft.util.Tickable;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import org.lwjgl.system.CallbackI;

import java.util.*;

public class SteamBlockEntity extends BlockEntity implements Tickable {

    public int speed = 1;
    public boolean pressure = false;
    public static final int tickEvery = 60;
    public int tickCount = 0;
    public Vec3i currentDirection = Vec3i.ZERO;
    protected static final int maxSpeed = 20;
    public BlockPos prevPos;
    protected boolean initialized = false;

    public SteamBlockEntity() {
        super(ModBlocks.STEAM_BLOCK_ENTITY);
    }

    public int getDensity(){return world.getBlockState(pos).get(SteamBlock.STEAM_DENSITY);}

    public Vec3i getCurrentDirection(){return currentDirection; }

    public void setDensity(int value){
        BlockState state = world.getBlockState(pos);
        world.setBlockState(pos, state.with(SteamBlock.STEAM_DENSITY, value), 3);
        world.setBlockEntity(pos, getCopy(pos));
    }
    /*
    public Vec3i getPrevDirection(){
        return prevDirection;
    }*/

    public void addDensity(int amount){
        BlockState state = world.getBlockState(pos);
        int newDensity = state.get(SteamBlock.STEAM_DENSITY);
        if (newDensity < 8) {
            newDensity+= amount;
        } else {
            newDensity = 8;
        }
        world.setBlockState(pos, state.with(SteamBlock.STEAM_DENSITY, newDensity), 3);
        world.setBlockEntity(pos, getCopy(pos));
    }

    public void increaseSpeed(int amount){
        speed = Math.min(speed + amount, maxSpeed);

    }

    public void decreaseSpeed(int amount){
        speed = Math.max(speed - amount, (int)Math.ceil((double)getDensity()/2d));
    }

    @Override
    public void tick() {
        if(!world.isClient()) {

            if (!initialized) {
                //System.out.println("steam initialized");
                PacketUtil.SendToAllClients(world, PacketIdentifiers.STEAM_UPDATE, SteamUpdatePacket.createBuffer(this));
                initialized = true;
            }
        }

            tickCount++;
            if (tickCount >= tickEvery / speed) {
                if(world.isClient) tickCount = tickEvery / speed;

                if(!world.isClient()) {
                    tickCount = 0;
                    // Apply pressure to steam block in path.
                    if (currentDirection != Vec3i.ZERO && world.getBlockState(this.pos.add(currentDirection)).getBlock().is(ModBlocks.STEAM_BLOCK)) {
                        SteamBlockEntity steam = (SteamBlockEntity) world.getBlockEntity(this.pos.add(currentDirection));
                        steam.pressure = true;
                    }

                    decreaseSpeed(1); // Must come before tryMove() due to cloning.

                    calcCurrentDirection();
                    this.pressure = false; // Reset pressure after we've potentially used it.

                    // Perform movement and notify client renderer.
                    if (currentDirection != Vec3i.ZERO){
                        moveOrCombine(this.pos.add(currentDirection));
                    }

                    if (pos.getY() >= world.getHeight() - 1) {
                        //System.out.println("Removed steam at top of world.");
                        world.removeBlock(pos, false);
                        world.removeBlockEntity(pos);
                    }
            }
        }
    }

    protected void calcCurrentDirection(){

        // Check if current path is blocked or there is a free space to move up.
        boolean needNewDir = currentDirection == Vec3i.ZERO || !isTraversable(pos.add(currentDirection)) || world.getBlockState(pos.up()).getBlock().is(Blocks.AIR);

        Random rand = new Random();
        List<Vec3i> possibleDirections = new ArrayList<Vec3i>(Arrays.asList(new Vec3i(1, 0, 0), new Vec3i(-1, 0, 0), new Vec3i(0, 0, 1), new Vec3i(0, 0, -1)));
        // Remove the direction which the steam came from and use it as last resort.
        Vec3i cameFrom = new Vec3i(currentDirection.getX()*-1, currentDirection.getY()*-1, currentDirection.getZ()*-1);
        possibleDirections.remove(cameFrom);
        while(needNewDir) {

            // Upwards movement
            if(isTraversable(pos.up())){
                currentDirection = new Vec3i(0,1,0);
                needNewDir = false;
                //System.out.println("haha, up");
                break;
            }

            // Pick a random direction.
            int i = rand.nextInt(possibleDirections.size());
            // If direction is free, set direction and exit loop, otherwise eleminate possible position.
            if(isTraversable(pos.add(possibleDirections.get(i)))){
                currentDirection = possibleDirections.get(i);
                needNewDir = false;
                //System.out.println("goin sideways");
                break;
            }else{
                possibleDirections.remove(i);
                if(possibleDirections.size() == 0){
                    // Test going back on self, otherwise do nothing and exit loop.
                    if(isTraversable(pos.add(cameFrom))) {
                        currentDirection = cameFrom;
                        needNewDir = false;
                        //System.out.println("back on self");
                    }

                    // If pressurized move down but trigger needNewDir for next time by setting currentDirection to zero.
                    if(pressure && isTraversable(pos.down())) {
                        currentDirection = new Vec3i(0,-1,0);
                        needNewDir = false;
                        //System.out.println("pressure");
                    }

                    break;
                }
            }
        }
    }

    public void moveTo(BlockPos movePos){
        //System.out.println("moving to: " + movePos);
        BlockPos oldPos = pos;
        world.setBlockState(movePos, world.getBlockState(pos), 3);
        SteamBlockEntity newSteam = getCopy(movePos);
        //System.out.println("1: " + newSteam.prevPos);
        world.setBlockEntity(movePos, newSteam);
        world.removeBlock(oldPos, true);
        //world.removeBlockEntity(oldPos);

        //SteamBlockEntity debug = (SteamBlockEntity) world.getBlockEntity(movePos);
        //System.out.println("2: " + debug.prevPos);
    }

    // Will return true if still alive.
    public boolean combineWith(BlockPos combinePos){
        //System.out.println("combining with: " + combinePos);
        boolean survivedCombination = true;

        // Set up function so that the larger steam block is always joined to.
        boolean combiningWithLarger = world.getBlockState(this.pos).get(SteamBlock.STEAM_DENSITY) < world.getBlockState(combinePos).get(SteamBlock.STEAM_DENSITY);
        BlockState target; BlockState me;
        if(combiningWithLarger) {
            target = world.getBlockState(combinePos);
            me = this.getCachedState();
        }else{
            target = this.getCachedState();
            me= world.getBlockState(combinePos);
        }

        SteamBlockEntity targetEntity = (SteamBlockEntity) world.getBlockEntity(combinePos);

        if(!target.getBlock().is(ModBlocks.STEAM_BLOCK) || target.get(SteamBlock.STEAM_DENSITY) == 9) return survivedCombination;

        // Get remainder of density. If positive leave this steam block with that density after combining.
        int totalDensity = me.get(SteamBlock.STEAM_DENSITY) + target.get(SteamBlock.STEAM_DENSITY);
        int densityRemainder = totalDensity - 9;
        if(totalDensity > 9) totalDensity = 9; // Cap density.

        // Add density to target block.
        world.setBlockState(combinePos, target.with(SteamBlock.STEAM_DENSITY, totalDensity), 3);

        if(densityRemainder > 0){
            world.setBlockState(this.pos, me.with(SteamBlock.STEAM_DENSITY, densityRemainder), 3);
        }
        else{
            world.removeBlock(this.pos, false);
            survivedCombination = false;
        }

        if(targetEntity != null) targetEntity.increaseSpeed(4);

        return survivedCombination;
    }

    public void moveOrCombine(BlockPos movePos){
        if(world.getBlockState(movePos).getBlock().is(ModBlocks.STEAM_BLOCK)){
            combineWith(movePos);
        }else if(world.getBlockState(movePos).getBlock().is(Blocks.AIR)){
            moveTo(movePos);
        }
    }

    // Return true if AIR or if both steam block involed are less than max density.
    protected boolean isTraversable(BlockPos position){

        if(world.getBlockState(position).getBlock().is(Blocks.AIR)) return true;

        if(world.getBlockState(position).getBlock().is(ModBlocks.STEAM_BLOCK)){
            return (world.getBlockState(this.pos).get(SteamBlock.STEAM_DENSITY) != 9 && world.getBlockState(position).get(SteamBlock.STEAM_DENSITY) != 9);
        }

        return false;
    }

    private void debugDisplay(){
        BlockState state = world.getBlockState(pos);
        int newDensity = state.get(SteamBlock.STEAM_DENSITY);
        if (newDensity < 8) {
            newDensity++;
        } else {
            newDensity = 0;
        }
        world.setBlockState(pos, state.with(SteamBlock.STEAM_DENSITY, newDensity), 3);
    }

    public SteamBlockEntity getCopy(BlockPos newPos){
        SteamBlockEntity steam = new SteamBlockEntity();
        steam.pos = newPos;
        steam.prevPos = this.pos;
        steam.speed = this.speed;
        steam.tickCount = this.tickCount;
        steam.currentDirection = this.currentDirection;
        steam.pressure = this.pressure;
        return steam;
    }

    public void fromTag(BlockState state, CompoundTag tag) {
        super.fromTag(state, tag);
        this.currentDirection = readVec3iTag(tag.getCompound("currentDirection"));
        this.prevPos = new BlockPos(readVec3dTag(tag.getCompound("prevPos")));
        this.speed = tag.getInt("speed");
        this.tickCount = tag.getInt("tickCount");
        this.pressure = tag.getBoolean("pressure");

        // In case tag was not written for some reason.
        if(this.speed == 0) speed = 1;
    }

    public CompoundTag toTag(CompoundTag tag) {
        super.toTag(tag);
        tag.put("currentDirection", writeVec3iTag(currentDirection));
        tag.put("prevPos", writeVec3iTag(this.prevPos));
        tag.putInt("speed", this.speed);
        tag.putInt("tickCount", this.tickCount);
        tag.putBoolean("pressure", this.pressure);
        return tag;
    }


    private CompoundTag writeVec3iTag(Vec3i vec){
        CompoundTag tag = new CompoundTag();
        tag.putInt("x", vec.getX());
        tag.putInt("y", vec.getY());
        tag.putInt("z", vec.getZ());
        return tag;
    }
    private CompoundTag writeVec3dTag(Vec3d vec){
        CompoundTag tag = new CompoundTag();
        tag.putDouble("x", vec.getX());
        tag.putDouble("y", vec.getY());
        tag.putDouble("z", vec.getZ());
        return tag;
    }

    private Vec3i readVec3iTag(CompoundTag tag){
        return new Vec3i(tag.getInt("x"), tag.getInt("y"), tag.getInt("z"));
    }
    private Vec3d readVec3dTag(CompoundTag tag){
        return new Vec3d(tag.getDouble("x"), tag.getDouble("y"), tag.getDouble("z"));
    }
}
