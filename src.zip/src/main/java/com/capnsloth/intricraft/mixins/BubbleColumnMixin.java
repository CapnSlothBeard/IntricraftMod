package com.capnsloth.intricraft.mixins;

import com.capnsloth.intricraft.blockentity.SteamBlockEntity;
import com.capnsloth.intricraft.blocks.SteamBlock;
import com.capnsloth.intricraft.registry.ModBlocks;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.BubbleColumnBlock;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Random;

@Mixin(BubbleColumnBlock.class)
public class BubbleColumnMixin {

    private static final int intricraft_steamTickrate = 107;

    @Inject(method = "onBlockAdded", at = @At("TAIL"))
    private void intricraft_onBlockAdded(BlockState state, World world, BlockPos pos, BlockState oldState, boolean notify, CallbackInfo ci){
        world.getBlockTickScheduler().schedule(pos, state.getBlock(), intricraft_steamTickrate);
        //System.out.println("tick scheduled");
    }

    @Inject(method = "scheduledTick", at = @At("HEAD"))
    private void intricraft_scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random, CallbackInfo ci){
        BlockState bs = world.getBlockState(pos.up());
        if(bs.getBlock().is(Blocks.AIR)){
            world.setBlockState(pos.up(), ModBlocks.STEAM_BLOCK.getDefaultState(), 2);
            world.getBlockTickScheduler().schedule(pos, world.getBlockState(pos).getBlock(), intricraft_steamTickrate);
        }
        else if(bs.getBlock().is(ModBlocks.STEAM_BLOCK)){
            if(bs.get(SteamBlock.STEAM_DENSITY) < 8){
                //System.out.println("condensing steam from generation");
                world.setBlockState(pos.up(), bs.with(SteamBlock.STEAM_DENSITY, bs.get(SteamBlock.STEAM_DENSITY) + 1), 2);
                world.getBlockTickScheduler().schedule(pos, world.getBlockState(pos).getBlock(), intricraft_steamTickrate);
            }
        }
        else{
            world.getBlockTickScheduler().schedule(pos, world.getBlockState(pos).getBlock(), 20);
        }
    }

}
