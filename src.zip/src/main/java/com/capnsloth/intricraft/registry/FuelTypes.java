package com.capnsloth.intricraft.registry;

import net.minecraft.item.Item;
import net.minecraft.item.Items;

public class FuelTypes {
    public static final Item[] fuelType = new Item[]{
            Items.COAL,
            Items.SLIME_BALL
    };
}
