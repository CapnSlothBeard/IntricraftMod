package com.capnsloth.intricraft.registry;

import com.capnsloth.intricraft.IntricraftMain;
import com.capnsloth.intricraft.structures.FallenDarkOak;
import com.capnsloth.intricraft.structures.Labyrinth;
import com.capnsloth.intricraft.structures.MazeStructure;
import com.google.common.collect.ImmutableMap;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.structure.v1.FabricStructureBuilder;
import net.fabricmc.fabric.mixin.structure.StructuresConfigAccessor;
import net.minecraft.structure.StructurePieceType;
import net.minecraft.structure.pool.StructurePool;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.BuiltinRegistries;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.registry.RegistryKey;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.chunk.StructureConfig;
import net.minecraft.world.gen.chunk.StructuresConfig;
import net.minecraft.world.gen.feature.ConfiguredStructureFeature;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;
import net.minecraft.world.gen.feature.StructureFeature;
import net.minecraft.world.gen.feature.StructurePoolFeatureConfig;

import java.util.function.Supplier;

public class ModStructures {



    public static void RegisterStructures(){
        RegisterFallenDarkOak();
        //RegisterLabyrith();
        RegisterMaze();
    }


    private static void RegisterFallenDarkOak(){
        Registry.register(Registry.STRUCTURE_PIECE, new Identifier(IntricraftMain.modID, "fallen_dark_oak_piece"), FallenDarkOak.PIECE);

        FabricStructureBuilder.create(new Identifier(IntricraftMain.modID, "fallen_dark_oak_structure"), FallenDarkOak.STRUCTURE)
                .step(GenerationStep.Feature.SURFACE_STRUCTURES)
                .defaultConfig(32, 8, 12345)
                .adjustsSurface()
                .register();

        RegistryKey<ConfiguredStructureFeature<?, ?>> configuredStructure = RegistryKey.of(Registry.CONFIGURED_STRUCTURE_FEATURE_WORLDGEN,
                new Identifier(IntricraftMain.modID, "fallen_dark_oak_configured_structure"));
        BuiltinRegistries.add(BuiltinRegistries.CONFIGURED_STRUCTURE_FEATURE, configuredStructure.getValue(), FallenDarkOak.CONFIGURED_STRUCTURE);

        BiomeModifications.addStructure(BiomeSelectors.categories(Biome.Category.FOREST, Biome.Category.TAIGA), configuredStructure);
    }

    private static void RegisterMaze(){
        Registry.register(Registry.STRUCTURE_PIECE, new Identifier(IntricraftMain.modID, "maze_debug"), MazeStructure.PIECE);

        FabricStructureBuilder.create(new Identifier(IntricraftMain.modID, "maze_structure"), MazeStructure.STRUCTURE)
                .step(GenerationStep.Feature.SURFACE_STRUCTURES)
                .defaultConfig(16, 10, 12345)
                .register();

        RegistryKey<ConfiguredStructureFeature<?, ?>> configuredStructure = RegistryKey.of(Registry.CONFIGURED_STRUCTURE_FEATURE_WORLDGEN,
                new Identifier(IntricraftMain.modID, "maze_configured_structure"));
        BuiltinRegistries.add(BuiltinRegistries.CONFIGURED_STRUCTURE_FEATURE, configuredStructure.getValue(), MazeStructure.CONFIGURED_STRUCTURE);

        BiomeModifications.addStructure(BiomeSelectors.all(), configuredStructure);
    }

    private static void RegisterLabyrith(){

        //System.out.println("Registering Labyrinth");

        FabricStructureBuilder.create(new Identifier(IntricraftMain.modID, "labyrinth_structure"), Labyrinth.STRUCTURE)
                .step(GenerationStep.Feature.SURFACE_STRUCTURES)
                .defaultConfig(8, 4, 12345)
                .adjustsSurface()
                .register();


        RegistryKey<ConfiguredStructureFeature<?, ?>> configuredStructureKey = RegistryKey.of(Registry.CONFIGURED_STRUCTURE_FEATURE_WORLDGEN,
                new Identifier(IntricraftMain.modID, "labyrinth_configured_structure"));
        BuiltinRegistries.add(BuiltinRegistries.CONFIGURED_STRUCTURE_FEATURE, configuredStructureKey.getValue(), Labyrinth.CONFIGURED_STRUCTURE);



/*
        StructuresConfigAccessor.setDefaultStructures(
                new ImmutableMap.Builder<StructureFeature<?>, StructureConfig>()
                        .putAll(StructuresConfig.DEFAULT_STRUCTURES)
                        .put(Labyrinth.STRUCTURE, new StructureConfig(32, 8, 10387312))
                        .build()
        );
*/

        BiomeModifications.addStructure(BiomeSelectors.all(), configuredStructureKey);

    }
}
