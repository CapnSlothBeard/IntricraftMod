package com.capnsloth.intricraft.registry;

import com.capnsloth.intricraft.IntricraftMain;
import com.capnsloth.intricraft.armour.JetpackPlasma;
import com.capnsloth.intricraft.armour.JetpackSolidFuel;
import com.capnsloth.intricraft.tools.DemonicAmulet;
import com.capnsloth.intricraft.tools.MiningLaser;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.*;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import org.lwjgl.system.CallbackI;

public class ModItems {
    // Instance Items.
    public static final Item DUST_IRON = new Item(new Item.Settings().group(ItemGroup.MATERIALS));
    public static final MiningLaser MINING_LASER = new MiningLaser(new MiningLaser.Settings().group(ItemGroup.TOOLS).maxCount(1));
    public static final DemonicAmulet DEMONIC_AMULET = new DemonicAmulet(new Item.Settings().group(ItemGroup.TOOLS).maxCount(1));

    // Instance BlockItems.
    public static final BlockItem CRUSHER_BLOCK = new BlockItem(ModBlocks.CRUSHER_BLOCK, new Item.Settings().group(ItemGroup.REDSTONE));

    // Instance ArmorItems.
    public static final JetpackSolidFuel JETPACK_SOLID_FUEL_MAT = new JetpackSolidFuel();
    public static final JetpackPlasma JETPACK_PLASMA_MAT = new JetpackPlasma();
    public static final Item JETPACK_SOLID_FUEL = new ArmorItem(JETPACK_SOLID_FUEL_MAT, EquipmentSlot.CHEST, new Item.Settings().group(ItemGroup.TRANSPORTATION));
    public static final Item JETPACK_PLASMA = new ArmorItem(JETPACK_PLASMA_MAT, EquipmentSlot.CHEST, new Item.Settings().group(ItemGroup.TRANSPORTATION));

    // Register Items and BlockItems.
    public static void RegisterItems(){
        Registry.register(Registry.ITEM, new Identifier(IntricraftMain.modID, "dust_iron"), DUST_IRON);
        Registry.register(Registry.ITEM, new Identifier(IntricraftMain.modID, "jetpack_solid_fuel"), JETPACK_SOLID_FUEL);
        Registry.register(Registry.ITEM, new Identifier(IntricraftMain.modID, "jetpack_plasma"), JETPACK_PLASMA);
        Registry.register(Registry.ITEM, new Identifier(IntricraftMain.modID, "crusher_block"), CRUSHER_BLOCK);
        Registry.register(Registry.ITEM, new Identifier(IntricraftMain.modID, "mining_laser"), MINING_LASER);
        Registry.register(Registry.ITEM, new Identifier(IntricraftMain.modID, "demonic_amulet"), DEMONIC_AMULET);
    }
}
