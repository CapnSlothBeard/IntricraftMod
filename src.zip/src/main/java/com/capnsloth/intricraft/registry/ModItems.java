package com.capnsloth.intricraft.registry;

import com.capnsloth.intricraft.IntricraftMain;
import com.capnsloth.intricraft.armour.JetpackPlasma;
import com.capnsloth.intricraft.armour.JetpackSolidFuel;
import com.capnsloth.intricraft.items.FastMinecartItem;
import com.capnsloth.intricraft.items.tools.DemonicAmulet;
import com.capnsloth.intricraft.items.tools.MiningLaser;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.*;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class ModItems {
    // Instance Items.
    public static final Item DUST_IRON = new Item(new Item.Settings().group(ItemGroup.MATERIALS));
    public static final MiningLaser MINING_LASER = new MiningLaser(new MiningLaser.Settings().group(ItemGroup.TOOLS).maxCount(1));
    public static final DemonicAmulet DEMONIC_AMULET = new DemonicAmulet(new Item.Settings().group(ItemGroup.TOOLS).maxCount(1));
    public static final FastMinecartItem FAST_MINECART = new FastMinecartItem(new Item.Settings().group(ItemGroup.TRANSPORTATION).maxCount(16));
    public static final BucketItem TEST_FLUID_BUCKET = new BucketItem(ModBlocks.TEST_FLUID_STILL, new Item.Settings().recipeRemainder(Items.BUCKET).maxCount(1));

    // Instance BlockItems.
    public static final BlockItem CRUSHER_BLOCK = new BlockItem(ModBlocks.CRUSHER_BLOCK, new Item.Settings().group(ItemGroup.REDSTONE));
    public static final BlockItem PLACER_BLOCK = new BlockItem(ModBlocks.PLACER_BLOCK, new Item.Settings().group(ItemGroup.REDSTONE));
    public static final BlockItem BREAKER_BLOCK = new BlockItem(ModBlocks.BREAKER_BLOCK, new Item.Settings().group(ItemGroup.REDSTONE));
    public static final BlockItem CONVEYOR_BLOCK = new BlockItem(ModBlocks.CONVEYOR_BLOCK, new Item.Settings().group(ItemGroup.REDSTONE));
    public static final BlockItem HARD_STONE_BLOCK = new BlockItem(ModBlocks.HARD_STONE_BLOCK, new Item.Settings().group(ItemGroup.BUILDING_BLOCKS));
    public static final BlockItem STEAM_BLOCK = new BlockItem(ModBlocks.STEAM_BLOCK, new Item.Settings().group(ItemGroup.REDSTONE));

    // Instance ArmorItems.
    public static final JetpackSolidFuel JETPACK_SOLID_FUEL_MAT = new JetpackSolidFuel();
    public static final JetpackPlasma JETPACK_PLASMA_MAT = new JetpackPlasma();
    public static final Item JETPACK_SOLID_FUEL = new ArmorItem(JETPACK_SOLID_FUEL_MAT, EquipmentSlot.CHEST, new Item.Settings().group(ItemGroup.TRANSPORTATION));
    public static final Item JETPACK_PLASMA = new ArmorItem(JETPACK_PLASMA_MAT, EquipmentSlot.CHEST, new Item.Settings().group(ItemGroup.TRANSPORTATION));

    // Register Items and BlockItems.
    public static void RegisterItems(){
        Registry.register(Registry.ITEM, new Identifier(IntricraftMain.modID, "dust_iron"), DUST_IRON);
        Registry.register(Registry.ITEM, new Identifier(IntricraftMain.modID, "jetpack_solid_fuel"), JETPACK_SOLID_FUEL);
        Registry.register(Registry.ITEM, new Identifier(IntricraftMain.modID, "jetpack_plasma"), JETPACK_PLASMA);
        Registry.register(Registry.ITEM, new Identifier(IntricraftMain.modID, "crusher_block"), CRUSHER_BLOCK);
        Registry.register(Registry.ITEM, new Identifier(IntricraftMain.modID, "placer_block"), PLACER_BLOCK);
        Registry.register(Registry.ITEM, new Identifier(IntricraftMain.modID, "breaker_block"), BREAKER_BLOCK);
        Registry.register(Registry.ITEM, new Identifier(IntricraftMain.modID, "conveyor"), CONVEYOR_BLOCK);
        Registry.register(Registry.ITEM, new Identifier(IntricraftMain.modID, "hard_stone_block"), HARD_STONE_BLOCK);
        Registry.register(Registry.ITEM, new Identifier(IntricraftMain.modID, "mining_laser"), MINING_LASER);
        Registry.register(Registry.ITEM, new Identifier(IntricraftMain.modID, "demonic_amulet"), DEMONIC_AMULET);
        Registry.register(Registry.ITEM, new Identifier(IntricraftMain.modID, "fast_minecart"), FAST_MINECART);
        Registry.register(Registry.ITEM, new Identifier(IntricraftMain.modID, "test_fluid_bucket"), TEST_FLUID_BUCKET);
        Registry.register(Registry.ITEM, new Identifier(IntricraftMain.modID, "steam_block"), STEAM_BLOCK);
    }
}
