package com.capnsloth.intricraft.registry;

import com.capnsloth.intricraft.IntricraftMain;
import com.capnsloth.intricraft.entities.mobs.*;
import com.capnsloth.intricraft.entities.mobs.models.ChibiDemonModel;
import com.capnsloth.intricraft.entities.mobs.models.HuskWormModel;
import com.capnsloth.intricraft.entities.mobs.models.HuskWormSegmentModel;
import com.capnsloth.intricraft.entities.mobs.models.SlothEntityModel;
import com.capnsloth.intricraft.entities.projectiles.MiningLaserProjectile;
import com.capnsloth.intricraft.entities.renderers.*;
import com.capnsloth.intricraft.entities.vehicles.FastMinecart;
import net.fabricmc.fabric.api.client.rendereregistry.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class ModEntities {

    public static final EntityType<MiningLaserProjectile> MINING_LASER_PROJECTILE_ENTITY_TYPE = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(IntricraftMain.modID, "mining_laser_projectile"),
            FabricEntityTypeBuilder.<MiningLaserProjectile>create(SpawnGroup.MISC, MiningLaserProjectile::new)
                    .dimensions(EntityDimensions.fixed(0.2F, 0.2F)) // dimensions in Minecraft units of the projectile
                    .trackRangeBlocks(4).trackedUpdateRate(10) // necessary for all thrown projectiles (as it prevents it from breaking, lol)
                    .build()
    );

    public static final EntityType<SlothEntity> SLOTH = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(IntricraftMain.modID, "sloth"),
            FabricEntityTypeBuilder.<SlothEntity>create(SpawnGroup.CREATURE, SlothEntity::new)
                    .dimensions(EntityDimensions.fixed(0.8F, 0.8F)) // dimensions in Minecraft units
                    .build()
    );

    public static final EntityType<ChibiDemon> CHIBI_DEMON = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(IntricraftMain.modID, "chibi_demon"),
            FabricEntityTypeBuilder.<ChibiDemon>create(SpawnGroup.CREATURE, ChibiDemon::new)
                    .dimensions(EntityDimensions.fixed(0.3F, 0.3F)) // dimensions in Minecraft units
                    .build()
    );

    public static final EntityType<HuskWormLarvae> HUSK_LARVAE = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(IntricraftMain.modID, "husk_larvae"),
            FabricEntityTypeBuilder.<HuskWormLarvae>create(SpawnGroup.CREATURE, HuskWormLarvae::new)
                    .dimensions(EntityDimensions.fixed(0.5F, 0.3F)) // dimensions in Minecraft units
                    .build()
    );

    public static final EntityType<HuskWormSegment> HUSK_WORM_SEGMENT = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(IntricraftMain.modID, "husk_worm_segment"),
            FabricEntityTypeBuilder.<HuskWormSegment>create(SpawnGroup.CREATURE, HuskWormSegment::new)
                    .dimensions(EntityDimensions.changing(1F, 1F)) // dimensions in Minecraft units
                    .build()
    );

    public static final EntityType<HuskWorm> HUSK_WORM = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(IntricraftMain.modID, "husk_worm"),
            FabricEntityTypeBuilder.<HuskWorm>create(SpawnGroup.CREATURE, HuskWorm::new)
                    .dimensions(EntityDimensions.changing(1F, 1F)) // dimensions in Minecraft units
                    .build()
    );

    public static final EntityType<FastMinecart> FAST_MINECART = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(IntricraftMain.modID, "fast_minecart"),
            FabricEntityTypeBuilder.<FastMinecart>create(SpawnGroup.MISC, FastMinecart::new)
                .dimensions(EntityDimensions.fixed(1F, 0.7F)) // dimensions in Minecraft units
                .build()
    );

    public static void RegisterEntityRenderers(){
        // Render Layers.


        // Entity Renderers.
        EntityRendererRegistry.INSTANCE.register(ModEntities.MINING_LASER_PROJECTILE_ENTITY_TYPE, (renderDispatcher, context) -> new MiningLaserProjectileRenderer(renderDispatcher));
        EntityRendererRegistry.INSTANCE.register(ModEntities.SLOTH, (renderDispatcher, context) -> new SlothRenderer(renderDispatcher, new SlothEntityModel(), 0.5f));
        EntityRendererRegistry.INSTANCE.register(ModEntities.CHIBI_DEMON, (renderDispatcher, context) -> new ChibiDemonRenderer(renderDispatcher, new ChibiDemonModel(), 0.2f));
        EntityRendererRegistry.INSTANCE.register(ModEntities.FAST_MINECART, (renderDispatcher, context) -> new FastMinecartRenderer(renderDispatcher));
        EntityRendererRegistry.INSTANCE.register(ModEntities.HUSK_LARVAE, (renderDispatcher, context) -> new HuskWormLarvaeRenderer(renderDispatcher));
        EntityRendererRegistry.INSTANCE.register(ModEntities.HUSK_WORM_SEGMENT, (renderDispatcher, context) -> new HuskWormSegmentRenderer(renderDispatcher, new HuskWormSegmentModel(), 1f));
        EntityRendererRegistry.INSTANCE.register(ModEntities.HUSK_WORM, (renderDispatcher, context) -> new HuskWormRenderer(renderDispatcher, new HuskWormModel(), 1f));
    }

    public static void RegisterAttributes() {
        FabricDefaultAttributeRegistry.register(SLOTH, SlothEntity.createSlothAttributes());
        FabricDefaultAttributeRegistry.register(CHIBI_DEMON, ChibiDemon.createMobAttributes());
        FabricDefaultAttributeRegistry.register(HUSK_LARVAE, HuskWormLarvae.createMobAttributes());
        FabricDefaultAttributeRegistry.register(HUSK_WORM_SEGMENT, HuskWormSegment.createMobAttributes());
        FabricDefaultAttributeRegistry.register(HUSK_WORM, HuskWorm.createMobAttributes());
    }
}
