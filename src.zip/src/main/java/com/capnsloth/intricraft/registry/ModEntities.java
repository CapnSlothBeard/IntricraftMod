package com.capnsloth.intricraft.registry;

import com.capnsloth.intricraft.IntricraftMain;
import com.capnsloth.intricraft.entities.mobs.ChibiDemon;
import com.capnsloth.intricraft.entities.mobs.SlothEntity;
import com.capnsloth.intricraft.entities.projectiles.MiningLaserProjectile;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class ModEntities {

    public static final EntityType<MiningLaserProjectile> MINING_LASER_PROJECTILE_ENTITY_TYPE = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(IntricraftMain.modID, "mining_laser_projectile"),
            FabricEntityTypeBuilder.<MiningLaserProjectile>create(SpawnGroup.MISC, MiningLaserProjectile::new)
                    .dimensions(EntityDimensions.fixed(0.2F, 0.2F)) // dimensions in Minecraft units of the projectile
                    .trackRangeBlocks(4).trackedUpdateRate(10) // necessary for all thrown projectiles (as it prevents it from breaking, lol)
                    .build()
    );

    public static final EntityType<SlothEntity> SLOTH = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(IntricraftMain.modID, "sloth"),
            FabricEntityTypeBuilder.<SlothEntity>create(SpawnGroup.CREATURE, SlothEntity::new)
                    .dimensions(EntityDimensions.fixed(0.8F, 0.8F)) // dimensions in Minecraft units
                    .build()
    );

    public static final EntityType<ChibiDemon> CHIBI_DEMON = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(IntricraftMain.modID, "chibi_demon"),
            FabricEntityTypeBuilder.<ChibiDemon>create(SpawnGroup.CREATURE, ChibiDemon::new)
                    .dimensions(EntityDimensions.fixed(0.3F, 0.3F)) // dimensions in Minecraft units
                    .build()
    );

    /*public static final EntityType<MiningLaserProjectile> MINING_LASER_PROJECTILE_ENTITY_TYPE = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(IntricraftMain.modID, "mining_laser_projectile"),
            FabricEntityTypeBuilder.<MiningLaserProjectile>create(SpawnGroup.MISC, MiningLaserProjectile::new)
                    .dimensions(EntityDimensions.fixed(0.25F, 0.25F)) // dimensions in Minecraft units of the projectile
                    .build() // VERY IMPORTANT DONT DELETE FOR THE LOVE OF GOD PSLSSSSSS
    );*/

    public static void RegisterAttributes() {
        //FabricDefaultAttributeRegistry.register(MINING_LASER_PROJECTILE_ENTITY_TYPE, );
        FabricDefaultAttributeRegistry.register(SLOTH, SlothEntity.createSlothAttributes());
        FabricDefaultAttributeRegistry.register(CHIBI_DEMON, ChibiDemon.createMobAttributes());
    }
}
