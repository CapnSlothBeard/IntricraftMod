package com.capnsloth.intricraft.registry;

import com.capnsloth.intricraft.SimpleFluidRenderHandler;
import com.capnsloth.intricraft.blockentity.SteamBlockEntity;
import com.capnsloth.intricraft.blockentity.renderers.SteamBlockEntityRenderer;
import com.capnsloth.intricraft.blocks.SteamBlock;
import com.capnsloth.intricraft.blocks.TestFluid;
import com.capnsloth.intricraft.blocks.TestFluidBlock;
import com.capnsloth.intricraft.machines.BreakerBlock;
import com.capnsloth.intricraft.machines.ConveyorBlock;
import com.capnsloth.intricraft.machines.CrusherBlock;
import com.capnsloth.intricraft.IntricraftMain;
import com.capnsloth.intricraft.machines.PlacerBlock;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendereregistry.v1.BlockEntityRendererRegistry;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.tool.attribute.v1.FabricToolTags;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.Material;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class ModBlocks {

    // Instance Blocks and set the settings.
    public static final CrusherBlock CRUSHER_BLOCK = new CrusherBlock(FabricBlockSettings
            .of(Material.STONE)
            .breakByTool(FabricToolTags.PICKAXES)
            .breakByHand(true)
            .strength(1, 5)
            .collidable(true)
            .sounds(BlockSoundGroup.STONE)
    );
    public static final PlacerBlock PLACER_BLOCK = new PlacerBlock(FabricBlockSettings
            .of(Material.STONE)
            .breakByTool(FabricToolTags.PICKAXES)
            .breakByHand(true)
            .strength(1, 5)
            .collidable(true)
            .sounds(BlockSoundGroup.STONE)
    );
    public static final BreakerBlock BREAKER_BLOCK = new BreakerBlock(FabricBlockSettings
            .of(Material.STONE)
            .breakByTool(FabricToolTags.PICKAXES)
            .breakByHand(true)
            .strength(1, 5)
            .collidable(true)
            .sounds(BlockSoundGroup.STONE)
    );
    public static final ConveyorBlock CONVEYOR_BLOCK = new ConveyorBlock(FabricBlockSettings
            .of(Material.STONE)
            .breakByTool(FabricToolTags.PICKAXES)
            .breakByHand(true)
            .strength(1, 5)
            .collidable(true)
            .sounds(BlockSoundGroup.STONE)
    );

    public static final Block HARD_STONE_BLOCK = new Block(FabricBlockSettings
        .of(Material.BARRIER)
            .strength(-1,3600000) // Same as bedrock
        .collidable(true)
        .sounds(BlockSoundGroup.STONE)
    );

    public static final TestFluid TEST_FLUID_STILL = new TestFluid.Still();
    public static final TestFluid TEST_FLOWING_FLOWING = new TestFluid.Flowing();

    public static final TestFluidBlock TEST_FLUID_BLOCK = new TestFluidBlock(TEST_FLUID_STILL, FabricBlockSettings.copy(Blocks.WATER));

    public static final SteamBlock STEAM_BLOCK = new SteamBlock(FabricBlockSettings.of(Material.WATER).strength(0,0).nonOpaque());
    public static BlockEntityType<SteamBlockEntity> STEAM_BLOCK_ENTITY = BlockEntityType.Builder.create(SteamBlockEntity::new, STEAM_BLOCK).build(null);

    // Instance Block Entities.
    //public static BlockEntityType<CrusherBlockEntity> CRUSHER_BLOCKENTITY;


    // Register Blocks
    public static void RegisterBlocks(){
        Registry.register(Registry.BLOCK, new Identifier(IntricraftMain.modID, "crusher_block"), CRUSHER_BLOCK);
        Registry.register(Registry.BLOCK, new Identifier(IntricraftMain.modID, "placer_block"), PLACER_BLOCK);
        Registry.register(Registry.BLOCK, new Identifier(IntricraftMain.modID, "breaker_block"), BREAKER_BLOCK);
        Registry.register(Registry.BLOCK, new Identifier(IntricraftMain.modID, "conveyor"), CONVEYOR_BLOCK);
        Registry.register(Registry.BLOCK, new Identifier(IntricraftMain.modID, "hard_stone_block"), HARD_STONE_BLOCK);
        Registry.register(Registry.FLUID, new Identifier(IntricraftMain.modID, "test_fluid_still"), TEST_FLUID_STILL);
        Registry.register(Registry.FLUID, new Identifier(IntricraftMain.modID, "test_fluid_flowing"), TEST_FLOWING_FLOWING);
        Registry.register(Registry.BLOCK, new Identifier(IntricraftMain.modID, "test_fluid_block"), TEST_FLUID_BLOCK);
        Registry.register(Registry.BLOCK, new Identifier(IntricraftMain.modID, "steam_block"), STEAM_BLOCK);
    }

    public static void RegisterBlockEntities(){
        Registry.register(Registry.BLOCK_ENTITY_TYPE, new Identifier(IntricraftMain.modID, "steam_blockentity"), STEAM_BLOCK_ENTITY);

    }

    public static void RegisterBlockEntityRenderers(){
        //BlockEntityRendererRegistry.INSTANCE.register(CRUSHER_BLOCKENTITY, CrusherBlockRenderer::new);
        BlockEntityRendererRegistry.INSTANCE.register(STEAM_BLOCK_ENTITY, SteamBlockEntityRenderer<SteamBlockEntity>::new);
    }

    public static void RegisterFluidRenderers(){
        //FluidRenderHandlerRegistry.INSTANCE.register(STEAM, new SimpleFluidRenderHandler("steam", STEAM_STILL, STEAM_FLOWING, 0x4CC248));
        new SimpleFluidRenderHandler("test_fluid", new Identifier("minecraft", "block/water_still"), new Identifier("minecraft", "block/water_flow"),
                TEST_FLUID_STILL, TEST_FLOWING_FLOWING, 0xe1e8e8).Register();
    }

    public static void RegisterBlockRenderers(){
        BlockRenderLayerMap.INSTANCE.putBlock(STEAM_BLOCK, RenderLayer.getTranslucent());
    }


}
