package com.capnsloth.intricraft.registry;

//import com.capnsloth.intricraft.entities.renderers.CrusherBlockRenderer;
import com.capnsloth.intricraft.machines.CrusherBlock;
import com.capnsloth.intricraft.IntricraftMain;
//import com.capnsloth.intricraft.machines.CrusherBlockEntity;
import net.fabricmc.fabric.api.client.rendereregistry.v1.BlockEntityRendererRegistry;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.fabricmc.fabric.api.tool.attribute.v1.FabricToolTags;
import net.minecraft.block.Material;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class ModBlocks {

    // Instance Blocks and set the settings.
    public static final CrusherBlock CRUSHER_BLOCK = new CrusherBlock(FabricBlockSettings
            .of(Material.PISTON)
            .breakByTool(FabricToolTags.PICKAXES)
            .breakByHand(true)
            .strength(1, 5)
            .collidable(true)
            .sounds(BlockSoundGroup.STONE)
    );

    // Instance Block Entities.
    //public static BlockEntityType<CrusherBlockEntity> CRUSHER_BLOCKENTITY;


    // Register Blocks
    public static void RegisterBlocks(){
        Registry.register(Registry.BLOCK, new Identifier(IntricraftMain.modID, "crusher_block"), CRUSHER_BLOCK);
    }

    public static void RegisterBlockEntities(){
        //CRUSHER_BLOCKENTITY = Registry.register(Registry.BLOCK_ENTITY_TYPE, IntricraftMain.modID+"crusher_block_entity", BlockEntityType.Builder.create(CrusherBlockEntity::new, CRUSHER_BLOCK).build(null));
    }

    public static void RegisterBlockEntityRenderers(){
        //BlockEntityRendererRegistry.INSTANCE.register(CRUSHER_BLOCKENTITY, CrusherBlockRenderer::new);
    }
}
