package com.capnsloth.intricraft.entities.mobs;

import com.capnsloth.intricraft.entities.goals.SimpleSeekGoal;
import com.capnsloth.intricraft.registry.ModEntities;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.*;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.TargetPredicate;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.crash.CrashException;
import net.minecraft.util.crash.CrashReport;
import net.minecraft.util.crash.CrashReportSection;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.system.CallbackI;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class HuskWorm extends MobEntity {

    protected int segmentCount = 14;
    public float scale = 3.35f;
    public float wiggleSpeed = 0.25f;
    public float wiggleAmount = 2f;
    private int findSegmentsDelay = 5;
    protected Vec3d targetPos;
    protected double gravityForce = 0.6d;
    protected double yeetSpeed = 0.3d;
    protected boolean destructionMode = true;
    protected LivingEntity targetEntity;


    @Environment(EnvType.SERVER)
    protected HuskWormSegment[] segments;

    public HuskWorm(EntityType<? extends MobEntity> entityType, World world) {
        super(entityType, world);
        //segments = createSegments(6);
    }

    protected HuskWormSegment[] createSegments(){
        HuskWormSegment[] segments = new HuskWormSegment[segmentCount];
        for(int i = 0; i<segmentCount; i++){

            // Set up segment.
            segments[i]  = new HuskWormSegment(ModEntities.HUSK_WORM_SEGMENT, world, this, i);
            Vec3d pos = this.getPos();
            segments[i].updatePosition(pos.x,
                    pos.y + ((getScaleFactor() - segments[i].getScaleFactor())*0.5f),
                    pos.z - (i*segments[i].getScaleFactor()) + (getScaleFactor()) );
            segments[i].setNoGravity(true);

            // Spawn in world.
            world.spawnEntity(segments[i]);
            //if(!world.isClient) PacketUtil.SendToAllClients(world, PacketIdentifiers.SPAWN_MOB, EntitySpawnPacket.createBuffer(this));

            System.out.println("Spawned Worm Segment:  " + segments[i].getPos());
        }
        return segments;
    }

    @Override
    public float getScaleFactor() {
        return scale;
    }

    @Override
    public void tick() {
        super.tick();

        if(!world.isClient) {
            if (findSegmentsDelay > 0) findSegmentsDelay--; // Delay added to allow segments to spawn in.
            else if (segments == null && findSegmentsDelay == 0) { // Pair with nearby child segments.
                segments = new HuskWormSegment[segmentCount]; // Ensure that array is initialized.
                assimilateNearbySegments();
                findSegmentsDelay = -1;
            } else {
                PlayerEntity nearestPlayer = world.getClosestPlayer(this, 320);
                if(nearestPlayer != null) targetPos = nearestPlayer.getPos();

                rotateTowards(targetPos);
                updateSegmentPositions();
            }
        }

        // Apply gravity.
        if(!isOnGround() && !isInsideWall()){
            updatePosition(getX(), getY()-gravityForce, getZ());
        }
        //updatePosition(getX(), getY(), getZ() + 0.5f);

    }

    protected void updateSegmentPositions(){
        attachSegmentToHuskWorm(0, this); // Special case for first segment.
        for(int i = 1; i < segments.length; i++){
            attachSegments(i, i-1);
        }
    }

    protected void attachSegments(int segmentIndex, int targetSegmentIndex){
        Vec3d startPos = segments[segmentIndex].getPos();
        Vec3d dir = segments[targetSegmentIndex].getPos().add(startPos.negate()).normalize();
        Vec3d closestSurfacePoint = segments[targetSegmentIndex].getPos().add(dir.multiply(segments[targetSegmentIndex].getScaleFactor()).negate());
        segments[segmentIndex].updateSegmentPosition(closestSurfacePoint);
        Vec2f rot = getRotatationTowards(closestSurfacePoint);
        segments[segmentIndex].updateSegmentRotation(rot);
    }

    protected void attachSegmentToHuskWorm(int segmentIndex, HuskWorm target){
        Vec3d startPos = segments[segmentIndex].getPos();
        Vec3d dir = target.getPos().add(startPos.negate()).normalize();
        Vec3d closestSurfacePoint = target.getPos().add(dir.multiply(target.getScaleFactor()).negate());
        segments[segmentIndex].updateSegmentPosition(closestSurfacePoint);
        Vec2f rot = getRotatationTowards(closestSurfacePoint);
        segments[segmentIndex].updateSegmentRotation(rot);
    }


    @Override
    public Box getBoundingBox() {
        return super.getBoundingBox();
    }

    @Nullable
    @Override
    public EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason spawnReason, @Nullable EntityData entityData, @Nullable CompoundTag entityTag) {
        EntityData data = super.initialize(world, difficulty, spawnReason, entityData, entityTag);
        if(!world.isClient()) segments = createSegments();
        setNoGravity(true);

        //double s = getScaleFactor()*6f;
        //setBoundingBox(new Box(getX()-s, getY()-s, getZ()-s, getX()+s, getY()+s, getZ()+s));
        System.out.println("HuskWorm initialize called");
        return data;
    }

    @Override
    protected void initGoals() {
        List<Class<? extends LivingEntity>> excludeTargets = new ArrayList<>();
        excludeTargets.add(HuskWormSegment.class);
        excludeTargets.add(HuskWorm.class);

        //goalSelector.add(1, new HuskWormBurrowGoal(this, 0.8f));
        goalSelector.add(3, new HuskWormSeekGoal(this, LivingEntity.class, excludeTargets, 0.8f));
        //goalSelector.add(6, new HuskWormWanderGoal(this, 16, 0.5f));

        //targetSelector.add(1, new LookAtEntityGoal(this, LivingEntity.class, 124));
    }

    @Override
    public void pushAwayFrom(Entity entity) {} // Do nothing

    @Override
    protected void checkBlockCollision() {
        Box box = this.getBoundingBox();
        box.expand(getScaleFactor());
        BlockPos blockPos = new BlockPos(box.minX + 0.001D, box.minY + 0.001D, box.minZ + 0.001D);
        BlockPos blockPos2 = new BlockPos(box.maxX - 0.001D, box.maxY - 0.001D, box.maxZ - 0.001D);
        BlockPos.Mutable mutable = new BlockPos.Mutable();
        if (this.world.isRegionLoaded(blockPos, blockPos2)) {
            for(int i = blockPos.getX(); i <= blockPos2.getX(); ++i) {
                for(int j = blockPos.getY(); j <= blockPos2.getY(); ++j) {
                    for(int k = blockPos.getZ(); k <= blockPos2.getZ(); ++k) {
                        mutable.set(i, j, k);
                        BlockState blockState = this.world.getBlockState(mutable);
                        try {
                            blockState.onEntityCollision(this.world, mutable, this);
                            this.onBlockCollision(blockState, new BlockPos(i,j,k));
                        } catch (Throwable var12) {
                            CrashReport crashReport = CrashReport.create(var12, "Colliding entity with block");
                            CrashReportSection crashReportSection = crashReport.addElement("Block being collided with");
                            CrashReportSection.addBlockInfo(crashReportSection, mutable, blockState);
                            throw new CrashException(crashReport);
                        }
                    }
                }
            }
        }
    }


    protected void onBlockCollision(BlockState state, BlockPos collisionPos) {
        super.onBlockCollision(state);

        if(destructionMode) {
            int size = (int) Math.ceil(getScaleFactor() * 0.5d);
            for (int x = -size; x <= size; x++) {
                for (int y = -size; y <= size; y++) {
                    for (int z = -size; z <= size; z++) {
                        BlockPos bp = collisionPos.add(x, 0, z);
                        BlockState bs = world.getBlockState(bp);
                        if (yeetableBlock(bs.getBlock())) {
                            // Yeet blocks
                            FallingBlockEntity fallingBlockEntity = new FallingBlockEntity(world, getX() + x + 0.5D, getY() + y, getZ() + z + 0.5D, bs);
                            Vec3d dir = new Vec3d((bp.getX()) - getX(), bp.getY() - getY(), (bp.getZ()) - getZ()).normalize();
                            fallingBlockEntity.addVelocity(yeetSpeed * dir.x, yeetSpeed * 3d, yeetSpeed * dir.z);
                            world.spawnEntity(fallingBlockEntity);
                        }
                    }
                }
            }
        }
    }

    public static boolean yeetableBlock(Block block){
        if (block.is(Blocks.SAND)) return true;
        if (block.is(Blocks.DIRT)) return true;
        if (block.is(Blocks.COARSE_DIRT)) return true;
        if(block.is(Blocks.GRASS_BLOCK)) return true;
        if(block.is(Blocks.GRASS_PATH)) return true;
        if(block.is(Blocks.GRAVEL)) return true;
        if(block.is(Blocks.SNOW_BLOCK)) return true;
        if(block.is(Blocks.ICE)) return true;
        return false;
    }


    @Override
    public boolean isInvulnerableTo(DamageSource damageSource) {
        if(damageSource == DamageSource.IN_WALL) return true;
        return super.isInvulnerableTo(damageSource);
    }


    @Override
    public void onDeath(DamageSource source) {
        // Kill segments
        if(!world.isClient && !this.removed && !this.dead){
            for(HuskWormSegment s : segments){
                s.kill();
            }
        }

        super.onDeath(source);
    }

    @Override
    public void writeCustomDataToTag(CompoundTag tag) {
        super.writeCustomDataToTag(tag);
    }

    @Override
    public void readCustomDataFromTag(CompoundTag tag) {
        super.readCustomDataFromTag(tag);
    }

    public void addSegment(HuskWormSegment segment, int index){
        segments[index] = segment;
    }

    public void assimilateNearbySegments(){
        int searchRange = (int)((segmentCount+2) * HuskWormSegment.scale);
        List<HuskWormSegment> segments = world.getEntitiesIncludingUngeneratedChunks(HuskWormSegment.class,
                new Box(getX() - searchRange, getY() - searchRange, getZ() - searchRange, getX() + searchRange, getY() + searchRange, getZ() + searchRange)
        );
        System.out.println("Looking for segments");
        for(HuskWormSegment s : segments){
            System.out.println("s found: " +s);
            s.setParentWorm(this);
        }
    }

    protected Vec2f getRotatationTowards(Vec3d pos) {
            double angleY = 0, angleX = 0;
            angleY = Math.atan2(getX() - pos.getX(), pos.getZ() - getZ());
            angleX = pos.getY() - getY();
            angleX = -angleX / (pos.distanceTo(getPos()));

        return new Vec2f((float) Math.toDegrees(angleY), (float) Math.toDegrees(angleX));
    }

    protected void rotateTowards(Vec3d pos) {
        double angleY = 0, angleX = 0;
        if (pos != null) {
            angleY = Math.atan2(getX() - pos.getX(), pos.getZ() - getZ());
            //angleX = Math.atan2(getZ() - pos.getZ(), pos.getY() - getY());
            angleX = pos.getY() - getY();
            angleX = -angleX / (pos.distanceTo(getPos()));

            setRotation((float) Math.toDegrees(angleY), (float) Math.toDegrees(angleX));

        }
    }
}


class HuskWormSeekGoal extends Goal {

    protected HuskWorm self;
    protected Vec3d targetPos;
    //protected LivingEntity target;
    protected float speed;
    protected Class<? extends LivingEntity> targetClass;
    protected List<Class<? extends LivingEntity>> exclude;

    public HuskWormSeekGoal(HuskWorm self, Vec3d targetPos, float speed) {
        this.self = self;
        this.targetPos = targetPos;
        this.speed = speed;
    }

    public HuskWormSeekGoal(HuskWorm self, Class<? extends LivingEntity> targetClass, float speed) {
        this.self = self;
        this.targetClass = targetClass;
        this.speed = speed;
    }

    public HuskWormSeekGoal(HuskWorm self, Class<? extends LivingEntity> targetClass, List<Class<? extends LivingEntity>> exclude, float speed) {
        this.self = self;
        this.targetClass = targetClass;
        this.speed = speed;
        this.exclude = exclude;
    }

    @Override
    public boolean canStart() {
        if(exclude != null) self.targetEntity = getClosestLivingEntityExlcuding(self.getPos(), 64, exclude, self.world);
        else{
            self.targetEntity = self.world.getClosestEntity(targetClass, TargetPredicate.DEFAULT,self ,self.getX(), self.getY(), self.getZ(),
                    new Box(self.getX() - 64,self.getY() - 64, self.getZ() - 64, self.getX() + 64, self.getY() + 64,self.getZ() + 64));
        }
        System.out.println("HuskWorm targeting: " + self.targetEntity);
        targetPos = self.targetEntity.getPos();
        if(self.targetEntity != null) System.out.println("Goal: Seek");
        return self.targetEntity != null;
    }

    @Override
    public boolean shouldContinue() {
        if(targetPos == null) return false;
        return self.getPos().distanceTo(targetPos) > 1;
    }

    @Override
    public void tick() {

        if(self.targetEntity != null) targetPos = self.targetEntity.getPos();

        if(targetPos != null) {
            Vec3d newPos = self.getPos();
            Vec3d directionToTargetPos = targetPos.subtract(self.getPos());
            directionToTargetPos = directionToTargetPos.normalize();
            directionToTargetPos = directionToTargetPos.multiply(speed);
            newPos = newPos.add(directionToTargetPos);
            // Reduce vertical movement if in the air.
            if(!self.isOnGround() && !self.isInsideWall()) newPos = new Vec3d(newPos.x, self.getY(), newPos.z);

            self.updatePosition(newPos.x, newPos.y, newPos.z);
        }
    }

    protected LivingEntity getClosestLivingEntityExlcuding(Vec3d originPos, int range, List<Class<? extends LivingEntity>> exclude, World world){
        List<LivingEntity> entities = world.getEntitiesByClass(targetClass,
                new Box(self.getX() - range,self.getY() - range, self.getZ() - range, self.getX() + range, self.getY() + range,self.getZ() + range),
                null
        );

        for(int i = 0; i < exclude.size(); i++) {
            int finalI = i;
            entities.removeIf(e -> exclude.get(finalI) == e.getClass() );
        }

        LivingEntity closestEntity = null;
        double closestDist = range+1;
        for(LivingEntity e : entities){
            double dist = e.getPos().distanceTo(originPos);
            if(dist < closestDist){
                closestDist = dist;
                closestEntity = e;
            }
        }
        return closestEntity;
    }
}

class HuskWormWanderGoal extends Goal{

    protected HuskWorm self;
    protected double speed = 1d;
    protected Vec3d targetPos;

    public HuskWormWanderGoal(HuskWorm self, double  wanderDistance, double speed){
        this.self = self;
        this.speed = speed;
        Vec3d facing = new Vec3d(self.getHorizontalFacing().getVector().getX(), self.getHorizontalFacing().getVector().getY(), self.getHorizontalFacing().getVector().getZ());
        facing = facing.add(Math.random() - 0.5d, 0, Math.random() - 0.5d);
        this.targetPos = self.getPos().add(facing.multiply(wanderDistance));
    }

    @Override
    public boolean canStart() {
        System.out.println("Goal: Wander");
        return true;
    }

    @Override
    public boolean shouldContinue() {
        // Continue until reached targetPos (ignoring Y coordinate).
        Vec3d v0 = new Vec3d(self.getX(), 0, self.getZ());
        Vec3d v1 = new Vec3d(targetPos.x, 0, targetPos.z);
        return v0.distanceTo(v1) > 1;
    }

    @Override
    public void tick() {
        super.tick();

        Vec3d newPos = self.getPos();
        Vec3d directionToTargetPos = targetPos.subtract(self.getPos());
        directionToTargetPos = directionToTargetPos.normalize();
        directionToTargetPos = directionToTargetPos.multiply(speed);
        newPos = newPos.add(directionToTargetPos);

        // Reduce vertical movement if in the air.
        if(!self.isOnGround() && !self.isInsideWall()) newPos = new Vec3d(newPos.x, self.getY(), newPos.z);

        self.updatePosition(newPos.x, newPos.y, newPos.z);

    }
}

class HuskWormBurrowGoal extends Goal{

    protected HuskWorm self;
    protected int phase = 0;
    protected Vec3d moveToPos;
    protected double speed;

    public HuskWormBurrowGoal(HuskWorm self, double speed)
    {
        this.self = self;
        this.speed = speed;
    }

    @Override
    public boolean canStart() {
        if(self.targetEntity != null){
            if(Math.random() <= 0.3333){
                System.out.println("Goal: Burrow");
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean shouldContinue() {
        if(phase == 4) return false;
        if(self.targetEntity == null) return false;
        return true;
    }

    @Override
    public void tick() {
        super.tick();
        if(phase == 0){ // Initialize
            moveToPos = self.getPos().subtract((Math.random()-0.5d)*16, 25, (Math.random()-0.5d)*16);
            phase = 1;
        }
        else if(phase == 1) { // Burrow
            moveTo(moveToPos);

            if(self.getPos().distanceTo(moveToPos) < 1) phase = 2;
            else if(self.getY() < 6) phase = 2;
        }
        else if(phase == 2){ // Attack
            if(self.targetEntity != null) {
                moveToPos = self.targetEntity.getPos();
                moveTo(moveToPos);
            }
            else phase = 3;

            if(self.getPos().distanceTo(moveToPos) < 1){
                Vec3d dir = self.targetEntity.getPos().subtract(self.getPos()).normalize();
                moveToPos = self.getPos().add(moveToPos.multiply(16)); // Move to point 16 blocks past target.
                phase = 3;
            }
        }
        else if(phase == 3){ // Continue through target.
            moveTo(moveToPos);
            if(self.getPos().distanceTo(moveToPos) < 1) phase = 4; // end phase
        }
    }

    protected void moveTo(Vec3d pos){
        Vec3d newPos = self.getPos();
        Vec3d directionToTargetPos = pos.subtract(self.getPos());
        directionToTargetPos = directionToTargetPos.normalize();
        directionToTargetPos = directionToTargetPos.multiply(speed);
        newPos = newPos.add(directionToTargetPos);

        self.updatePosition(newPos.x, newPos.y, newPos.z);
    }
}

