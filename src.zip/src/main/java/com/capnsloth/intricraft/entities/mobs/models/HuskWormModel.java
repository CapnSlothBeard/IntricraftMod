package com.capnsloth.intricraft.entities.mobs.models;

import com.capnsloth.intricraft.entities.mobs.HuskWorm;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;

public class HuskWormModel extends EntityModel<HuskWorm> {
        private final ModelPart main;
        private final ModelPart mandibles;
        private final ModelPart tl;
        private final ModelPart cube_r1;
        private final ModelPart tr;
        private final ModelPart cube_r2;
        private final ModelPart bl;
        private final ModelPart cube_r3;
        private final ModelPart br;
        private final ModelPart cube_r4;

        public float scale = 2;

        public HuskWormModel() {
        textureWidth = 64;
        textureHeight = 48;
        main = new ModelPart(this);
        main.setPivot(0.0F, 24.0F, 0.0F);
        main.setTextureOffset(0, 0).addCuboid(-8.0F, -16.0F, -8.0F, 16.0F, 16.0F, 16.0F, 0.0F, false);

        mandibles = new ModelPart(this);
        mandibles.setPivot(0.0F, 24.0F, 0.0F);


        tl = new ModelPart(this);
        tl.setPivot(-6.6217F, -13.5F, -7.9193F);
        mandibles.addChild(tl);
        setRotationAngle(tl, 0.1772F, -0.1719F, -0.0306F);


        cube_r1 = new ModelPart(this);
        cube_r1.setPivot(0.0571F, 0.0F, 0.5825F);
        tl.addChild(cube_r1);
        setRotationAngle(cube_r1, 0.0F, 0.0F, 0.0F);
        cube_r1.setTextureOffset(0, 33).addCuboid(-1.0571F, -1.5237F, -11.7989F, 2.0F, 3.0F, 12.0F, 0.0F, false);

        tr = new ModelPart(this);
        tr.setPivot(6.3783F, -13.5F, -7.9193F);
        mandibles.addChild(tr);
        setRotationAngle(tr, 0.1731F, 0.1289F, -0.0229F);


        cube_r2 = new ModelPart(this);
        cube_r2.setPivot(0.0571F, 0.0F, 0.5825F);
        tr.addChild(cube_r2);
        setRotationAngle(cube_r2, 0.0F, 0.0F, 0.0F);
        cube_r2.setTextureOffset(0, 33).addCuboid(-1.0571F, -1.5237F, -11.7989F, 2.0F, 3.0F, 12.0F, 0.0F, false);

        bl = new ModelPart(this);
        bl.setPivot(-6.6217F, -2.5F, -7.9193F);
        mandibles.addChild(bl);
        setRotationAngle(bl, -0.1772F, -0.1719F, 0.0306F);


        cube_r3 = new ModelPart(this);
        cube_r3.setPivot(0.0571F, 0.0F, 0.5825F);
        bl.addChild(cube_r3);
        setRotationAngle(cube_r3, 0.0F, 0.0F, 0.0F);
        cube_r3.setTextureOffset(0, 33).addCuboid(-1.0571F, -1.5237F, -11.7989F, 2.0F, 3.0F, 12.0F, 0.0F, false);

        br = new ModelPart(this);
        br.setPivot(6.3783F, -2.5F, -7.9193F);
        mandibles.addChild(br);
        setRotationAngle(br, -0.176F, 0.1289F, -0.0229F);


        cube_r4 = new ModelPart(this);
        cube_r4.setPivot(0.0571F, 0.0F, 0.5825F);
        br.addChild(cube_r4);
        setRotationAngle(cube_r4, 0.0F, 0.0F, 0.0F);
        cube_r4.setTextureOffset(0, 33).addCuboid(-1.0571F, -1.5237F, -11.7989F, 2.0F, 3.0F, 12.0F, 0.0F, false);
        }

        @Override
        public void setAngles(HuskWorm entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        }


        @Override
        public void render(MatrixStack matrixStack, VertexConsumer	buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha){
                //matrixStack.push();
                //matrixStack.scale(scale, scale, scale);
                //matrixStack.translate(0,-0.5d,0);
                //System.out.println("light: " + packedLight);
                if(packedLight < 13000000) packedLight = 13000000; // Prevent model from rendering completely black when in ground.
                main.render(matrixStack, buffer, packedLight, packedOverlay);
                mandibles.render(matrixStack, buffer, packedLight, packedOverlay);
                //matrixStack.pop();
        }

        public void setRotationAngle(ModelPart bone, float x, float y, float z) {
                bone.pitch = x;
                bone.yaw = y;
                bone.roll = z;
        }


}
