package com.capnsloth.intricraft.entities.renderers;
/*
import com.capnsloth.intricraft.machines.CrusherBlockEntity;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderDispatcher;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class CrusherBlockRenderer extends BlockEntityRenderer {
    public CrusherBlockRenderer(BlockEntityRenderDispatcher dispatcher) {
        super(dispatcher);
    }

    @Override
    public void render(BlockEntity entity, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, int overlay) {
        CrusherBlockEntity cbe = (CrusherBlockEntity) entity;
        if(cbe.validCrushable){
            if(cbe.getWorld().getTime() % 5 == 0) { // Do stuff only ever 5 ticks.
                spawnCrushParticleEfect(cbe);
                MinecraftClient.getInstance().world.playSound(cbe.getPos(), SoundEvents.BLOCK_GRAVEL_BREAK, SoundCategory.BLOCKS, 0.7f, 0.4f, true);
            }
        }
    }

    private void spawnCrushParticleEfect(CrusherBlockEntity cbe){
        Vec3d dir = new Vec3d(cbe.facing.getVector().getX(), cbe.facing.getVector().getY(), cbe.facing.getVector().getZ());
        Vec3d particlePos = new Vec3d((double)cbe.getPos().getX() + (dir.x*0.65d) +0.5d, (double)cbe.getPos().getY() + (dir.y*0.65d) +0.5d, (double)cbe.getPos().getZ() + (dir.z*0.65d)+0.5d);


        for(int i =0; i<=7; i++) {
            MinecraftClient.getInstance().world.addParticle(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.STONE.getDefaultState()), particlePos.x, particlePos.y, particlePos.z, 0, 0, 0);
        }
        /*
        Vec3d velocity = new Vec3d((MathHelper.abs((float)dir.x)-1f)*-1f, (MathHelper.abs((float)dir.y)-1f)*-1f, (MathHelper.abs((float)dir.z)-1f)*-1f); // Get axis that the crusher is not facing.
        for(int x = (int)-(velocity.x); x <= (int)(velocity.x); x++){
            for(int y = (int)-(velocity.y); y <= (int)(velocity.y); y++){
                for(int z = (int)-(velocity.z); z <= (int)(velocity.z); z++){
                    MinecraftClient.getInstance().world.addParticle(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.STONE.getDefaultState()), particlePos.x, particlePos.y, particlePos.z, x*0.25f, y*0.25f, z*0.25f);
                }
            }
        }*/
/*
        //MinecraftClient.getInstance().world.addParticle(ParticleTypes.FIREWORK, particlePos.x, particlePos.y, particlePos.z, velocity.x, velocity.y, velocity.z);
    }
}
*/