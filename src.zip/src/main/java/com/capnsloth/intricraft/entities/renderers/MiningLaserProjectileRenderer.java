package com.capnsloth.intricraft.entities.renderers;

import com.capnsloth.intricraft.IntricraftClient;
import com.capnsloth.intricraft.IntricraftMain;
import com.capnsloth.intricraft.entities.projectiles.MiningLaserProjectile;
import com.capnsloth.intricraft.entities.projectiles.models.MiningLaserProjectileModel;
import net.fabricmc.fabric.api.client.rendereregistry.v1.EntityRendererRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.ProjectileEntityRenderer;
import net.minecraft.client.render.model.json.ModelTransformation;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.Vector3f;
import net.minecraft.entity.Entity;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

public class MiningLaserProjectileRenderer extends EntityRenderer<MiningLaserProjectile> {

    public Identifier textureID = new Identifier(IntricraftMain.modID, "textures/entities/mining_laser_projectile.png");
    public MiningLaserProjectileModel model = new MiningLaserProjectileModel();

    public MiningLaserProjectileRenderer(EntityRenderDispatcher renderDispatcher) {
        super(renderDispatcher);

    }

    @Override
    public Identifier getTexture(MiningLaserProjectile entity) {
        return textureID;
    }

    @Override
    public void render(MiningLaserProjectile entity, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
        /*MinecraftClient.getInstance().getItemRenderer().renderItem(
                Items.REDSTONE_BLOCK.getDefaultStack(), ModelTransformation.Mode.FIXED, light, OverlayTexture.DEFAULT_UV, matrices, vertexConsumers
        );*/
        //matrices.multiply(Vector3f.POSITIVE_Y.getDegreesQuaternion(MathHelper.lerp(tickDelta, entity.prevYaw, yaw) - 90.0F));
        matrices.multiply(Vector3f.POSITIVE_Y.getDegreesQuaternion(yaw));
        matrices.multiply(Vector3f.POSITIVE_X.getDegreesQuaternion(-entity.pitch));
        model.render(matrices, vertexConsumers.getBuffer(RenderLayer.getEntitySolid(textureID)), light, 0, 1, 1, 1, 1);
        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }
}
