package com.capnsloth.intricraft.entities.mobs;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.control.MoveControl;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.FireballEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import java.util.Random;

public class ChibiDemon extends TameableEntity {

    private static final TrackedData<Boolean> SHOOTING = DataTracker.registerData(ChibiDemon.class, TrackedDataHandlerRegistry.BOOLEAN);
    private int fireballExplosionStrength = 1;

    public ChibiDemon(EntityType<? extends TameableEntity> entityType, World world) {
        super(entityType, world);
        //this.moveControl = new ChibiDemonMoveControl(this);
    }

    public ChibiDemon(EntityType<? extends TameableEntity> entityType, World world, PlayerEntity owner) {
        super(entityType, world);
        this.setOwner(owner);
        //this.moveControl = new ChibiDemonMoveControl(this);
    }

    @Nullable
    @Override
    public PassiveEntity createChild(ServerWorld world, PassiveEntity entity) {
        return null;
    }

    protected void initDataTracker() {
        super.initDataTracker();
        this.dataTracker.startTracking(SHOOTING, false);
    }

    protected void initGoals() {
        /*this.goalSelector.add(1, new SwimGoal(this));
        this.goalSelector.add(2, new SitGoal(this));
        this.goalSelector.add(4, new PounceAtTargetGoal(this, 0.4F));
        this.goalSelector.add(5, new MeleeAttackGoal(this, 1.0D, true));
        this.goalSelector.add(6, new FollowOwnerGoal(this, 1.0D, 10.0F, 2.0F, false));
        this.goalSelector.add(7, new AnimalMateGoal(this, 1.0D));
        this.goalSelector.add(8, new WanderAroundFarGoal(this, 1.0D));
        this.goalSelector.add(10, new LookAtEntityGoal(this, PlayerEntity.class, 8.0F));
        this.goalSelector.add(10, new LookAroundGoal(this));
        this.targetSelector.add(1, new TrackOwnerAttackerGoal(this));
        this.targetSelector.add(2, new AttackWithOwnerGoal(this));
        this.targetSelector.add(3, (new RevengeGoal(this, new Class[0])).setGroupRevenge(new Class[0]));
        this.targetSelector.add(8, new UniversalAngerGoal(this, true));*/
        //this.goalSelector.add(2, new ProjectileAttackGoal(this, 0.3f, 1, 50, 30f));
        this.goalSelector.add(1, new ShootFireballGoal(this));
        this.goalSelector.add(2, new LookAtTargetGoal(this));
        this.goalSelector.add(10, new LookAroundGoal(this));
        //this.goalSelector.add(3, new FollowOwnerGoal(this, 0.6f, 1.5f, 4f, true));
        //this.goalSelector.add(4, new WanderAroundGoal(this, 0.3f, 1));
        this.targetSelector.add(2, new TrackOwnerAttackerGoal(this));
        this.targetSelector.add(1, new AttackWithOwnerGoal(this));
        this.targetSelector.add(3, new LookAtOwnerGoal(this, 40));
        //this.targetSelector.add(8, new UniversalAngerGoal(this, true));


    }

    @Override
    public void tick() {
        super.tick();

        if(!world.isClient) {
            /* Movement */
            if (getTarget() != null) {
                hoverAboveTarget(getTarget(), 2d, 1f, 0.3d);
                seekTarget(getTarget(), 0.5d, 7d);
            } else if (getOwner() != null) {
                LivingEntity oe = getOwner();
                hoverAboveTarget(oe, 1.4d, 0.25f, 0.3d);
                seekTarget(oe, 0.45d, 2d);

                /* Teleport if owner is too far. */
                if (distanceTo(oe) > 10d) {
                    Vec3d v = oe.getPos();
                    teleport(v.x, v.y, v.z);
                    //refreshPositionAfterTeleport(v);
                }
            }
        }

    }

    public void hoverAboveTarget(Entity target, double height, double leniency, double speed){
        double hoverPos = target.getPos().y + height;
        double dist = MathHelper.sqrt((squaredDistanceTo(target.getPos().x, hoverPos, target.getPos().z)));
        speed = speed - (speed / ( dist + 1));
        if(getPos().y < hoverPos - leniency){
            Vec3d vel = getVelocity();
            setVelocity(vel.x, speed, vel.z);
        }
        else if(getPos().y > hoverPos + leniency){
            Vec3d vel = getVelocity();
            setVelocity(vel.x, -speed, vel.z);
        }
        else{
            Vec3d vel = getVelocity();
            setVelocity(vel.x, 0, vel.z);
        }
    }

    public void seekTarget(Entity target, double speed, double minDistance){
        speed = speed - (speed / ( (distanceTo(target) - minDistance) + 1));
        if(distanceTo(target) > minDistance){
            Vec3d dir = (target.getPos().add(this.getPos().multiply(-1d))).normalize();
            dir = dir.multiply(speed);
            Vec3d vel = getVelocity();
            this.setVelocity(dir.x, vel.y, dir.z);
        }
    }

    /*@Override
    public void attack(LivingEntity target, float pullProgress) {
        if(!world.isClient) {
            pullProgress += 0.1f;
            if (pullProgress > 1f) pullProgress = 1f;

            // Fire
            if (pullProgress == 1f) {
                System.out.println("Fire!");
                Vec3d targetDirection = this.getPos().add(target.getPos().multiply(-1d));
                System.out.println("Target Direction: " + targetDirection);
                targetDirection.normalize();
                System.out.println("Normalized Target Direction: " + targetDirection);
                world.spawnEntity(new FireballEntity(world, this, targetDirection.x, targetDirection.y, targetDirection.z));
                pullProgress = 0f;
            }
        }
    }*/

    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_VEX_AMBIENT;
    }

    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_GHAST_DEATH;
    }

    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_VEX_HURT;
    }

    @Environment(EnvType.CLIENT)
    public boolean isShooting() {
        return (Boolean)this.dataTracker.get(SHOOTING);
    }

    public void setShooting(boolean shooting) {
        this.dataTracker.set(SHOOTING, shooting);
    }

    public int getFireballExplosionStrength() {
        return this.fireballExplosionStrength;
    }

    @Override
    public boolean handleFallDamage(float fallDistance, float damageMultiplier) {
        return false;
    }

    @Override
    public void setNoGravity(boolean noGravity) {
        super.setNoGravity(true);
    }



    @Override
    public boolean hasNoGravity() {
        super.hasNoGravity();
        return true;
    }

    /*class ChibiDemonMoveControl extends MoveControl {
        public ChibiDemonMoveControl(ChibiDemon owner) {
            super(owner);
        }

        public void tick() {
            if (this.state == State.MOVE_TO) {
                Vec3d vec3d = new Vec3d(this.targetX - ChibiDemon.this.getX(), this.targetY - ChibiDemon.this.getY(), this.targetZ - ChibiDemon.this.getZ());
                double d = vec3d.length();
                if (d < ChibiDemon.this.getBoundingBox().getAverageSideLength()) {
                    this.state = State.WAIT;
                    ChibiDemon.this.setVelocity(ChibiDemon.this.getVelocity().multiply(0.5D));
                } else {
                    ChibiDemon.this.setVelocity(ChibiDemon.this.getVelocity().add(vec3d.multiply(this.speed)));
                    }
                }

            }
    }*/

    static class ShootFireballGoal extends Goal {
        private final ChibiDemon chibiDemon;
        public int cooldown;

        public ShootFireballGoal(ChibiDemon chibiDemon) {
            this.chibiDemon = chibiDemon;
        }

        public boolean canStart() {
            return this.chibiDemon.getTarget() != null;
        }

        public void start() {
            this.cooldown = 0;
        }

        public void stop() {
            this.chibiDemon.setShooting(false);
        }

        public void tick() {
            LivingEntity target = this.chibiDemon.getTarget();
            double d = 64.0D;
            if (target.squaredDistanceTo(this.chibiDemon) < 4096.0D && this.chibiDemon.canSee(target)) {
                World world = this.chibiDemon.world;
                ++this.cooldown;
                /*
                if (this.cooldown == 10 && !this.chibiDemon.isSilent()) {
                    world.syncWorldEvent((PlayerEntity)null, 1015, this.chibiDemon.getBlockPos(), 0);
                }*/

                if (this.cooldown == 15) {
                    double e = 4.0D;
                    Vec3d vec3d = this.chibiDemon.getRotationVec(1.0F);
                    /*
                    if (!this.chibiDemon.isSilent()) {
                        world.syncWorldEvent((PlayerEntity)null, 1016, this.chibiDemon.getBlockPos(), 0);
                    }*/

                    float dist = chibiDemon.distanceTo(target);
                    Vec3d dir = target.getPos().add(chibiDemon.getPos().multiply(-1f)).normalize();
                    //Vec3d vel = new Vec3d(dir.x, dir.y, dir.z);
                    //vel.multiply(6f);
                    FireballEntity fireballEntity = new FireballEntity(world, this.chibiDemon, dir.x, dir.y, dir.z);
                    fireballEntity.explosionPower = this.chibiDemon.getFireballExplosionStrength();
                    fireballEntity.updatePosition(this.chibiDemon.getX(), this.chibiDemon.getY() + 0.1d, fireballEntity.getZ());
                    world.spawnEntity(fireballEntity);

                    world.playSound(null, chibiDemon.getX(), chibiDemon.getY(), chibiDemon.getZ(), SoundEvents.ENTITY_GHAST_SCREAM, SoundCategory.NEUTRAL, 0.6F, 1.4f);
                    world.playSound(null, chibiDemon.getX(), chibiDemon.getY(), chibiDemon.getZ(), SoundEvents.ITEM_FIRECHARGE_USE, SoundCategory.NEUTRAL, 0.35f, 1f);
                    this.cooldown = -40;
                }
            } else if (this.cooldown > 0) {
                --this.cooldown;
            }

            this.chibiDemon.setShooting(this.cooldown > 10);
        }
    }

    static class LookAtTargetGoal extends Goal {
        private final ChibiDemon chibiDemon;

        public LookAtTargetGoal(ChibiDemon chibiDemon) {
            this.chibiDemon = chibiDemon;
            this.setControls(EnumSet.of(Control.LOOK));
        }

        public boolean canStart() {
            return this.chibiDemon.getTarget() != null;
        }

        public void tick() {
            if (this.chibiDemon.getTarget() != null) {

                LivingEntity livingEntity = this.chibiDemon.getTarget();
                double d = 64.0D;
                if (livingEntity.squaredDistanceTo(this.chibiDemon) < 4096.0D) {
                    double e = livingEntity.getX() - this.chibiDemon.getX();
                    double f = livingEntity.getZ() - this.chibiDemon.getZ();
                    this.chibiDemon.yaw = -((float)MathHelper.atan2(e, f)) * 57.295776F;
                    this.chibiDemon.bodyYaw = this.chibiDemon.yaw;
                }
            }

        }
    }

    static class LookAtOwnerGoal extends Goal {
        private final ChibiDemon chibiDemon;
        private final int chance;
        private int runTicks = 0;

        public LookAtOwnerGoal(ChibiDemon chibiDemon, int percentChance) {
            this.chibiDemon = chibiDemon;
            this.chance = percentChance;
            this.setControls(EnumSet.of(Control.LOOK));
        }

        @Override
        public boolean canStart() {
            int rand = new Random().nextInt(100);
            return this.chibiDemon.getOwner() != null && this.chibiDemon.getTarget() == null && rand <= chance;
        }

        @Override
        public boolean shouldContinue() {
            if(runTicks >= 10) { // Prevent rapid state changing.
                runTicks = 0;
                return canStart();
            }
            return true;
        }

        public void tick() {
            runTicks++;
            if (this.chibiDemon.getOwner() != null) {

                LivingEntity owner = this.chibiDemon.getOwner();
                double d = 64.0D;
                if (chibiDemon.squaredDistanceTo(owner) < 4096.0D) {
                    double e = owner.getX() - this.chibiDemon.getX();
                    double f = owner.getZ() - this.chibiDemon.getZ();
                    this.chibiDemon.yaw = -((float)MathHelper.atan2(e, f)) * 57.295776F;
                    this.chibiDemon.bodyYaw = this.chibiDemon.yaw;
                }
            }

        }
    }

    /*
    static class HoverAboveOwnerGoal extends Goal{
        private final ChibiDemon chibiDemon;
        private final double height;
        private final double leniency;
        private final double speed;

        public HoverAboveOwnerGoal(ChibiDemon chibiDemon, double height, double leniency, double speed){
            this.chibiDemon = chibiDemon;
            this.height = height;
            this.leniency = leniency;
            this.speed = speed;
        }

        @Override
        public boolean canStart() {
            return chibiDemon.getOwner() != null;
        }

        public void tick() {
            if(chibiDemon.getOwner() != null) {
                double hoverPos = chibiDemon.getOwner().getPos().y + height;
                if(chibiDemon.getPos().y < hoverPos - leniency){
                    chibiDemon.addVelocity(0, speed, 0);
                }
                else if(chibiDemon.getPos().y > hoverPos + leniency){
                    chibiDemon.addVelocity(0, -speed, 0);
                }
            }
        }
    }*/
}

