package com.capnsloth.intricraft.entities.renderers;

import com.capnsloth.intricraft.IntricraftMain;
import com.capnsloth.intricraft.entities.models.FastMinecartModel;
import com.capnsloth.intricraft.entities.vehicles.FastMinecart;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.MinecartEntityRenderer;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.Vector3f;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;


@Environment(EnvType.CLIENT)
public class FastMinecartRenderer extends EntityRenderer<FastMinecart> {
    private static final Identifier TEXTURE = new Identifier(IntricraftMain.modID, "textures/entities/fast_minecart.png");
    protected final EntityModel<FastMinecart> cartModel = new FastMinecartModel();

    public FastMinecartRenderer(EntityRenderDispatcher entityRenderDispatcher) {
        super(entityRenderDispatcher);
    }

    @Override
    public Identifier getTexture(FastMinecart cart) {
        return TEXTURE;
    }

    @Override
    public void render(FastMinecart entity, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
        if (this.hasLabel(entity)) {
            this.renderLabelIfPresent(entity, entity.getDisplayName(), matrices, vertexConsumers, light);
        }

        matrices.push();
        long l = (long)entity.getEntityId() * 493286711L;
        l = l * l * 4392167121L + l * 98761L;
        float h = (((float)(l >> 16 & 7L) + 0.5F) / 8.0F - 0.5F) * 0.004F;
        float j = (((float)(l >> 20 & 7L) + 0.5F) / 8.0F - 0.5F) * 0.004F;
        float k = (((float)(l >> 24 & 7L) + 0.5F) / 8.0F - 0.5F) * 0.004F;
        matrices.translate((double)h, (double)j, (double)k);
        double d = MathHelper.lerp((double)tickDelta, entity.lastRenderX, entity.getX());
        double e = MathHelper.lerp((double)tickDelta, entity.lastRenderY, entity.getY());
        double m = MathHelper.lerp((double)tickDelta, entity.lastRenderZ, entity.getZ());
        double n = 0.30000001192092896D;
        Vec3d vec3d = entity.snapPositionToRail(d, e, m);
        float o = MathHelper.lerp(tickDelta, entity.prevPitch, entity.pitch);
        if (vec3d != null) {
            Vec3d vec3d2 = entity.snapPositionToRailWithOffset(d, e, m, 0.30000001192092896D);
            Vec3d vec3d3 = entity.snapPositionToRailWithOffset(d, e, m, -0.30000001192092896D);
            if (vec3d2 == null) {
                vec3d2 = vec3d;
            }

            if (vec3d3 == null) {
                vec3d3 = vec3d;
            }

            matrices.translate(vec3d.x - d, (vec3d2.y + vec3d3.y) / 2.0D - e, vec3d.z - m);
            Vec3d vec3d4 = vec3d3.add(-vec3d2.x, -vec3d2.y, -vec3d2.z);
            if (vec3d4.length() != 0.0D) {
                vec3d4 = vec3d4.normalize();
                yaw = (float)(Math.atan2(vec3d4.z, vec3d4.x) * 180.0D / 3.141592653589793D);
                o = (float)(Math.atan(vec3d4.y) * 73.0D);
            }
        }

        matrices.translate(0.0D, 0.375D, 0.0D);
        matrices.multiply(Vector3f.POSITIVE_Y.getDegreesQuaternion(180.0F - yaw));
        matrices.multiply(Vector3f.POSITIVE_Z.getDegreesQuaternion(-o));
        float p = (float)entity.getDamageWobbleTicks() - tickDelta;
        float q = entity.getDamageWobbleStrength() - tickDelta;
        if (q < 0.0F) {
            q = 0.0F;
        }

        if (p > 0.0F) {
            matrices.multiply(Vector3f.POSITIVE_X.getDegreesQuaternion(MathHelper.sin(p) * p * q / 10.0F * (float)entity.getDamageWobbleSide()));
        }


        matrices.scale(-1.0F, -1.0F, 1.0F);
        this.cartModel.setAngles(entity, 0.0F, 0.0F, -0.1F, 0.0F, 0.0F);
        VertexConsumer vertexConsumer = vertexConsumers.getBuffer(this.cartModel.getLayer(this.getTexture(entity)));
        this.cartModel.render(matrices, vertexConsumer, light, OverlayTexture.DEFAULT_UV, 1.0F, 1.0F, 1.0F, 1.0F);
        matrices.pop();
        //System.out.println("Rendering from FastMinecartRenderer");
        //cartModel.render(matrices, vertexConsumers.getBuffer(RenderLayer.getEntitySolid(TEXTURE)), light, 0,1F, 1F, 1F, 1F);
    }
}
