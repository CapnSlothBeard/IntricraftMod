package com.capnsloth.intricraft.entities.mobs.models;

import com.capnsloth.intricraft.entities.mobs.SlothEntity;
import com.google.common.collect.ImmutableList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.AnimalModel;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.WolfEntity;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class SlothEntityModel extends EntityModel<SlothEntity> {

    //private final ModelPart root;
    private final ModelPart body;
    private final ModelPart tail;
    private final ModelPart head;
    private final ModelPart head_tuft;
    private final ModelPart head_tuft2_r1;
    private final ModelPart head_tuft1_r1;
    private final ModelPart legs;
    private final ModelPart leg_fr;
    private final ModelPart leg_fl;
    private final ModelPart leg_br;
    private final ModelPart leg_bl;

    private SlothEntity selfEntity;

    public SlothEntityModel(){
        textureWidth = 64;
        textureHeight = 64;

        //root = new ModelPart(this);
        //root.setPivot(0.0F, 24.0F, 0.0F);


        body = new ModelPart(this);
        body.setPivot(0.0F, -4.0F, -2.0F);
        //root.addChild(body);
        body.setTextureOffset(0, 0).addCuboid(-3.0F, -5.0F, -3.0F, 6.0F, 4.0F, 11.0F, 0.0F, false);
        body.setTextureOffset(19, 18).addCuboid(-2.0F, -1.0F, 0.0F, 4.0F, 1.0F, 7.0F, 0.0F, false);
        body.setTextureOffset(14, 26).addCuboid(-3.0F, -5.0F, -4.0F, 6.0F, 4.0F, 1.0F, 0.0F, false);


        tail = new ModelPart(this);
        tail.setPivot(0.0f,0.0f,0.0f);
        body.addChild(tail);
        tail.setTextureOffset(0, 25).addCuboid(-3.0F, -5.0F, 8.0F, 6.0F, 4.0F, 1.0F, 0.0F, false);
        tail.setTextureOffset(0, 8).addCuboid(-2.0F, -4.0F, 9.0F, 4.0F, 2.0F, 1.0F, 0.0F, false);
        tail.setTextureOffset(21, 15).addCuboid(-1.0F, -4.0F, 10.0F, 2.0F, 2.0F, 1.0F, 0.0F, false);

        head = new ModelPart(this);
        head.setPivot(0.0F, -8.0F, -7.0F);
        //root.addChild(head);
        head.setTextureOffset(0, 15).addCuboid(-4.0F, -4.0F, -4.0F, 8.0F, 5.0F, 5.0F, 0.0F, false);
        //head.setTextureOffset(23, 0).addCuboid(-2.0F, -2.0F, -1.0F, 4.0F, 2.0F, 5.0F, 0.0F, false);

        head_tuft = new ModelPart(this);
        head_tuft.setPivot(0.0F, -6.0F, -1.0F);
        head.addChild(head_tuft);
        setRotationAngle(head_tuft, -0.0873F, -0.2182F, 0.0F);
        head_tuft.setTextureOffset(0, 15).addCuboid(-1.0F, 1.0F, -1.0F, 1.0F, 1.0F, 1.0F, 0.0F, false);

        head_tuft2_r1 = new ModelPart(this);
        head_tuft2_r1.setPivot(-3.0F, -2.0F, 0.0F);
        head_tuft.addChild(head_tuft2_r1);
        setRotationAngle(head_tuft2_r1, 0.0F, 0.0F, 0.1745F);
        head_tuft2_r1.setTextureOffset(6, 0).addCuboid(3.0F, 2.0F, 0.0F, 1.0F, 1.0F, 1.0F, 0.0F, false);

        head_tuft1_r1 = new ModelPart(this);
        head_tuft1_r1.setPivot(-1.0F, 0.0F, 0.0F);
        head_tuft.addChild(head_tuft1_r1);
        setRotationAngle(head_tuft1_r1, 0.3054F, 0.0F, 0.0F);
        head_tuft1_r1.setTextureOffset(0, 18).addCuboid(-1.0F, 0.0F, -2.0F, 1.0F, 1.0F, 1.0F, 0.0F, false);

        legs = new ModelPart(this);
        legs.setPivot(-4.0F, -6.0F, -4.0F);
        //root.addChild(legs);


        leg_fr = new ModelPart(this);
        leg_fr.setPivot(0.0F, 0.0F, 0.0F);
        legs.addChild(leg_fr);
        leg_fr.setTextureOffset(8, 30).addCuboid(-1.0F, -1.0F, -1.0F, 2.0F, 7.0F, 2.0F, 0.0F, false);

        leg_fl = new ModelPart(this);
        leg_fl.setPivot(8.0F, 0.0F, 0.0F);
        legs.addChild(leg_fl);
        leg_fl.setTextureOffset(0, 30).addCuboid(-1.0F, -1.0F, -1.0F, 2.0F, 7.0F, 2.0F, 0.0F, false);

        leg_bl = new ModelPart(this);
        leg_bl.setPivot(8.0F, 0.0F, 10.0F);
        legs.addChild(leg_bl);
        leg_bl.setTextureOffset(28, 26).addCuboid(-1.0F, -1.0F, -1.0F, 2.0F, 7.0F, 2.0F, 0.0F, false);

        leg_br = new ModelPart(this);
        leg_br.setPivot(0.0F, 0.0F, 10.0F);
        legs.addChild(leg_br);
        leg_br.setTextureOffset(0, 0).addCuboid(-1.0F, -1.0F, -1.0F, 2.0F, 7.0F, 2.0F, 0.0F, false);
    }

    @Override
    public void setAngles(SlothEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        this.head.yaw = headYaw * 0.015F;
        this.head.pitch = headPitch* 0.015F;
        this.leg_fr.pitch = MathHelper.cos(limbAngle * 0.6662F) * 4F * limbDistance;
        this.leg_bl.pitch = MathHelper.cos(limbAngle * 0.6662F) * 4F * limbDistance;
        this.leg_fl.pitch = MathHelper.cos(limbAngle * 0.6662F + 3.1415927F) * 4F * limbDistance;
        this.leg_br.pitch = MathHelper.cos(limbAngle * 0.6662F + 3.1415927F) * 4F * limbDistance;
    }


    protected Iterable<ModelPart> getHeadParts() {
        return ImmutableList.of(this.head);
    }


    protected Iterable<ModelPart> getBodyParts() {
        return ImmutableList.of(this.body, this.legs);
    }



    @Override
    public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay, float red, float green, float blue, float alpha) {
        //root.render(matrices, vertices, light, overlay, red, green, blue, alpha);
        matrices.translate(0,(1.0d/16d) * 24d,0); // Fix strange floating mob issue. y = (mcUnit / pixelsPerUnit) * distanceToMoveInPixels
        if(selfEntity != null && selfEntity.isSitting()){
            //matrices.translate(0,(1.0d/16d) * -6d,0);
        }
        if (this.child) { // Scale for baby proportions
            matrices.push();
            float g;
            g = 1.0F / 1.3f;
            matrices.scale(g, g, g);

            matrices.translate(0.0D, (double)(1f / 16.0F) * 4f, (double)(1f / 16.0F)*2f); // Adjust baby head position.
            this.getHeadParts().forEach((modelPart) -> {
                modelPart.render(matrices, vertices, light, overlay, red, green, blue, alpha);
            });
            matrices.pop();
            matrices.push();
            g = 1.0F / 1.8f;
            matrices.scale(g, g, g);
            this.getBodyParts().forEach((modelPart) -> {
                modelPart.render(matrices, vertices, light, overlay, red, green, blue, alpha);
            });
            matrices.pop();
        } else { // Normal render.
            this.getHeadParts().forEach((modelPart) -> {
                modelPart.render(matrices, vertices, light, overlay, red, green, blue, alpha);
            });
            this.getBodyParts().forEach((modelPart) -> {
                modelPart.render(matrices, vertices, light, overlay, red, green, blue, alpha);
            });
        }
    }

    @Override
    public void animateModel(SlothEntity entity, float limbAngle, float limbDistance, float tickDelta) {
        if(selfEntity==null) selfEntity = entity;
        if(entity.isSitting()) {
            // NOTE TO SELF: Pitch, Yaw and Roll values in Radians
            float r = 6.28f; // La revolution.
            body.setPivot(0,-10f,-2f);
            body.pitch = (r/4f)*-1f;
            legs.setPivot(-4f,-13.5f,1f);
            legs.pitch = (r/4f)*-1f;
            tail.setPivot(0.0f,3.0f,12.0f);
            tail.pitch = (r/4f);
            head.setPivot(0.0F, -14.0F, 1.0F);
        }else{
            body.setPivot(0.0F, -4.0F, -2.0F);
            body.pitch = 0f;
            legs.setPivot(-4.0F, -6.0F, -4.0F);
            legs.pitch = 0f;
            tail.setPivot(0.0f,0.0f,0.0f);
            tail.pitch = 0;
            head.setPivot(0.0F, -8.0F, -7.0F);
        }
        super.animateModel(entity, limbAngle, limbDistance, tickDelta);
    }


    public void setRotationAngle(ModelPart modelPart, float x, float y, float z) {
        modelPart.pitch = x;
        modelPart.yaw = y;
        modelPart.roll = z;
    }
}
