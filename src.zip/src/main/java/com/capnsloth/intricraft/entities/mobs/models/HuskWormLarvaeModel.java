package com.capnsloth.intricraft.entities.mobs.models;

import com.capnsloth.intricraft.entities.mobs.HuskWormLarvae;
import com.capnsloth.intricraft.entities.mobs.SlothEntity;
import net.minecraft.client.render.entity.model.SilverfishEntityModel;
import net.minecraft.entity.Entity;

public class HuskWormLarvaeModel extends SilverfishEntityModel<HuskWormLarvae> {
}
