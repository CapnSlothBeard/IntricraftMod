package com.capnsloth.intricraft.entities.mobs.models;

import com.capnsloth.intricraft.entities.mobs.ChibiDemon;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;

public class ChibiDemonModel extends EntityModel<ChibiDemon> {

    private final ModelPart head;
    private final ModelPart brow2_r1;
    private final ModelPart brow_r1;
    private final ModelPart horn_l_r1;
    private final ModelPart horn_r_r1;
    private final ModelPart body;
    private final ModelPart legs;
    private final ModelPart arms;
    private final ModelPart arm_l_r1;
    private final ModelPart arm_r_r1;
    private final ModelPart wings;
    private final ModelPart wing_r;
    private final ModelPart wing_l;

    private float t = 0f;

    public ChibiDemonModel(){
        textureWidth = 32;
        textureHeight = 32;

        head = new ModelPart(this);
        head.setPivot(0.0F, 15.2F, -0.98F);
        head.setTextureOffset(0, 1).addCuboid(-3.0F, -1.2F, -1.02F, 6.0F, 6.0F, 5.0F, 0.0F, false);

        brow2_r1 = new ModelPart(this);
        brow2_r1.setPivot(-1.0F, 0.8F, -0.72F);
        head.addChild(brow2_r1);
        setRotationAngle(brow2_r1, 0.0F, 0.0F, 0.3491F);
        brow2_r1.setTextureOffset(0, 4).addCuboid(-1.2F, -0.5F, -0.5F, 2.0F, 1.0F, 0.0F, 0.0F, false);

        brow_r1 = new ModelPart(this);
        brow_r1.setPivot(1.0F, 0.5F, -0.72F);
        head.addChild(brow_r1);
        setRotationAngle(brow_r1, 0.0F, 0.0F, -0.3491F);
        brow_r1.setTextureOffset(0, 4).addCuboid(-0.8F, -0.2F, -0.5F, 2.0F, 1.0F, 0.0F, 0.0F, false);

        horn_l_r1 = new ModelPart(this);
        horn_l_r1.setPivot(-1.5F, -1.2F, 0.48F);
        head.addChild(horn_l_r1);
        setRotationAngle(horn_l_r1, -0.1745F, 0.2618F, -0.4363F);
        horn_l_r1.setTextureOffset(0, 12).addCuboid(-0.5F, -2.0F, -0.5F, 1.0F, 3.0F, 1.0F, 0.0F, false);

        horn_r_r1 = new ModelPart(this);
        horn_r_r1.setPivot(1.5F, -1.2F, 0.48F);
        head.addChild(horn_r_r1);
        setRotationAngle(horn_r_r1, -0.1745F, -0.2618F, 0.4363F);
        horn_r_r1.setTextureOffset(0, 12).addCuboid(-0.5F, -2.0F, -0.5F, 1.0F, 3.0F, 1.0F, 0.0F, true);

        body = new ModelPart(this);
        body.setPivot(0.0F, 24.0F, 0.0F);
        body.setTextureOffset(16, 12).addCuboid(-2.0F, -4.0F, -1.0F, 4.0F, 3.0F, 4.0F, 0.0F, false);

        legs = new ModelPart(this);
        legs.setPivot(0.0F, -6.0F, 0.5F);
        body.addChild(legs);
        legs.setTextureOffset(0, 3).addCuboid(1.0F, 5.0F, -0.5F, 1.0F, 1.0F, 1.0F, 0.0F, false);
        legs.setTextureOffset(0, 3).addCuboid(-2.0F, 5.0F, -0.5F, 1.0F, 1.0F, 1.0F, 0.0F, false);

        arms = new ModelPart(this);
        arms.setPivot(-0.5F, -8.5F, 0.0F);
        body.addChild(arms);


        arm_l_r1 = new ModelPart(this);
        arm_l_r1.setPivot(-1.5F, 5.0F, 0.5F);
        arms.addChild(arm_l_r1);
        setRotationAngle(arm_l_r1, 0.0F, 0.0F, -1.0472F);
        arm_l_r1.setTextureOffset(17, 4).addCuboid(-2.0F, -0.5F, -0.5F, 2.0F, 1.0F, 1.0F, 0.0F, false);

        arm_r_r1 = new ModelPart(this);
        arm_r_r1.setPivot(2.5F, 5.0F, 0.5F);
        arms.addChild(arm_r_r1);
        setRotationAngle(arm_r_r1, 0.0F, 0.0F, 1.0472F);
        arm_r_r1.setTextureOffset(17, 1).addCuboid(0.0F, -0.5F, -0.5F, 2.0F, 1.0F, 1.0F, 0.0F, false);

        wings = new ModelPart(this);
        wings.setPivot(0.0F, 18.0F, 3.0F);


        wing_r = new ModelPart(this);
        wing_r.setPivot(1.0F, -3.5F, 0.5F);
        wings.addChild(wing_r);
        setRotationAngle(wing_r, 0.0F, -0.3491F, 0.0F);
        wing_r.setTextureOffset(0, 18).addCuboid(0.0F, 1.5F, -0.5F, 7.0F, 4.0F, 1.0F, 0.0F, false);
        wing_r.setTextureOffset(1, 22).addCuboid(0.0F, 5.5F, -0.5F, 5.0F, 2.0F, 1.0F, 0.0F, false);

        wing_l = new ModelPart(this);
        wing_l.setPivot(-1.0F, -3.5F, 0.5F);
        wings.addChild(wing_l);
        setRotationAngle(wing_l, 0.0F, 0.3491F, 0.0F);
        wing_l.setTextureOffset(0, 18).addCuboid(-7.0F, 1.5F, -0.5F, 7.0F, 4.0F, 1.0F, 0.0F, false);
        wing_l.setTextureOffset(1, 22).addCuboid(-5.0F, 5.5F, -0.5F, 5.0F, 2.0F, 1.0F, 0.0F, false);
    }

    @Override
    public void setAngles(ChibiDemon entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {

    }


    @Override
    public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay, float red, float green, float blue, float alpha) {
        matrices.translate(0, (1d / 16d)* 10.5d,0); // Make the model line up with the hitbox. (1/16 converts to pixel size)
        matrices.scale(0.6f, 0.6f, 0.6f);

        head.render(matrices, vertices, light, overlay, red, green, blue, alpha);
        body.render(matrices, vertices, light, overlay, red, green, blue, alpha);
        wings.render(matrices, vertices, light, overlay, red, green, blue, alpha);
    }

    public void setRotationAngle(ModelPart modelPart, float x, float y, float z) {
        modelPart.pitch = x;
        modelPart.yaw = y;
        modelPart.roll = z;
    }


    @Override
    public void animateModel(ChibiDemon entity, float limbAngle, float limbDistance, float tickDelta) {
        super.animateModel(entity, limbAngle, limbDistance, tickDelta);
        //float l = MathHelper.lerp(tickDelta, -2f, 2f);
        float moveDist = 0.3f;
        float speed = 0.17f;
        float offset = 0.8f;
        arm_l_r1.roll = (MathHelper.sin((float)MinecraftClient.getInstance().world.getTime() * speed) * moveDist) - offset;
        arm_r_r1.roll = (MathHelper.cos((float)MinecraftClient.getInstance().world.getTime() * speed) * moveDist) + offset;

        moveDist = 1f;
        wing_l.yaw = (((MathHelper.cos(t) * moveDist) *-1f) + offset);
        wing_r.yaw = ((MathHelper.cos(t) * moveDist) - offset);
        t += 0.6f;

    }
}

