package com.capnsloth.intricraft.entities.mobs.models;

import com.capnsloth.intricraft.entities.mobs.HuskWormSegment;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;

public class HuskWormSegmentModel extends EntityModel<HuskWormSegment> {
    private final ModelPart main;
    public float scale = 1.5f;

    public HuskWormSegmentModel() {
        textureWidth = 64;
        textureHeight = 32;
        main = new ModelPart(this);
        main.setPivot(0.0F, 24.0F, 0.0F);
        main.setTextureOffset(0, 0).addCuboid(-8.0F, -16.0F, -8.0F, 16.0F, 16.0F, 16.0F, 0.0F, false);
        }

    @Override
    public void setAngles(HuskWormSegment entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
    }

    @Override
    public void render(MatrixStack matrixStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha){
        //matrixStack.push();
        //matrixStack.scale(scale, scale, scale);
        if(packedLight < 13000000) packedLight = 13000000; // Prevent model from rendering completely black when in ground.
        main.render(matrixStack, buffer, packedLight, packedOverlay);
        //matrixStack.pop();
    }

    public void setRotationAngle(ModelPart bone, float x, float y, float z) {
        bone.pitch = x;
        bone.yaw = y;
        bone.roll = z;
    }

}
