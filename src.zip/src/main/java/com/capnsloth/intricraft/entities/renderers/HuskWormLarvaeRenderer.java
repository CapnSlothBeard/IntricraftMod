package com.capnsloth.intricraft.entities.renderers;

import com.capnsloth.intricraft.IntricraftMain;
import com.capnsloth.intricraft.entities.mobs.HuskWormLarvae;
import com.capnsloth.intricraft.entities.mobs.models.HuskWormLarvaeModel;
import com.capnsloth.intricraft.entities.mobs.models.SlothEntityModel;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

public class HuskWormLarvaeRenderer extends MobEntityRenderer<HuskWormLarvae, HuskWormLarvaeModel> {
    private static final Identifier TEXTURE = new Identifier(IntricraftMain.modID, "textures/entities/husk_larvae.png");

    public HuskWormLarvaeRenderer(EntityRenderDispatcher entityRenderDispatcher) {
        super(entityRenderDispatcher, new HuskWormLarvaeModel(), 0.3F);
    }

    public HuskWormLarvaeRenderer(EntityRenderDispatcher dispatcher, HuskWormLarvaeModel entityModel, float shadowSize){
        super(dispatcher, entityModel, shadowSize);

    }

    protected float getLyingAngle(HuskWormLarvae huskWormLarvae) {
        return 180.0F;
    }

    public Identifier getTexture(HuskWormLarvae huskWormLarvae) {
        return TEXTURE;
    }
}
