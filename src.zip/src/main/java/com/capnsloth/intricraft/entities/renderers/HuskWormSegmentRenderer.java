package com.capnsloth.intricraft.entities.renderers;

import com.capnsloth.intricraft.IntricraftMain;
import com.capnsloth.intricraft.entities.mobs.HuskWormSegment;
import com.capnsloth.intricraft.entities.mobs.models.HuskWormSegmentModel;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.Vector3f;
import net.minecraft.util.Identifier;

public class HuskWormSegmentRenderer extends MobEntityRenderer<HuskWormSegment, HuskWormSegmentModel> {

    public final Identifier textureID = new Identifier(IntricraftMain.modID, "textures/entities/husk_worm_body.png");
    public final HuskWormSegmentModel model;

    public HuskWormSegmentRenderer(EntityRenderDispatcher dispatcher, HuskWormSegmentModel entityModel, float shadowSize) {
        super(dispatcher, entityModel, shadowSize);
        this.model = entityModel;
    }

    @Override
    public Identifier getTexture(HuskWormSegment entity) {
        return textureID;
    }


    @Override
    public void render(HuskWormSegment mobEntity, float yaw, float tickDelta, MatrixStack matrixStack, VertexConsumerProvider vertexConsumerProvider, int light) {
        matrixStack.push();
        matrixStack.scale(mobEntity.getScaleFactor(), mobEntity.getScaleFactor(), mobEntity.getScaleFactor());
        //matrixStack.multiply(Vector3f.POSITIVE_Y.getDegreesQuaternion(mobEntity.yaw)); SEEMS TO BE A PROBLEM WITH ENTITY YAW
        //matrixStack.multiply(Vector3f.POSITIVE_X.getDegreesQuaternion(mobEntity.pitch));
        super.render(mobEntity, mobEntity.yaw, tickDelta, matrixStack, vertexConsumerProvider, light);
        matrixStack.pop();
    }


}
