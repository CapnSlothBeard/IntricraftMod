package com.capnsloth.intricraft.entities.mobs;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.datafixer.fix.EntityIdFix;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.crash.CrashException;
import net.minecraft.util.crash.CrashReport;
import net.minecraft.util.crash.CrashReportSection;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.List;
import java.util.UUID;

public class HuskWormSegment extends MobEntity {
    public HuskWorm parentWorm;
    public static float scale = 3.3f;
    public int segmentIndex = 0;
    protected String parentWormUuid;
    public Vec3d posLastTick;
    protected double yeetSpeed = 0.3d;

    public HuskWormSegment(EntityType<HuskWormSegment> type, World world, HuskWorm parentWorm, int segmentIndex) {
        super(type, world);
        this.parentWorm = parentWorm;
        this.segmentIndex = segmentIndex;
    }

    public HuskWormSegment(EntityType<HuskWormSegment> huskWormSegmentEntityType, World world) {
        super(huskWormSegmentEntityType, world);
    }

    @Override
    public boolean damage(DamageSource source, float amount) {

        if(isInvulnerableTo(source)){
            return false;
        }
        if(parentWorm!=null) parentWorm.damage(source, amount);
        animateDamage();
        return true;
    }

    @Override
    public void kill() {
        applyDamage(DamageSource.OUT_OF_WORLD, 999999f);
    }

    @Override
    public void tick() {
        super.tick();
        /*if(parentWorm != null){
            //System.out.println("Y: " + parentWorm.prevYaw + "  P: " + parentWorm.prevPitch);
            setRotation(parentWorm.yaw, parentWorm.pitch);
        }

         */
    }


    public void updateSegmentPosition(Vec3d pos){
        updatePosition(pos.x, pos.y, pos.z);
        posLastTick = getPos();
    }

    public void updateSegmentRotation(Vec2f rot){
        setRotation(rot.x, rot.y);
    }


    @Override
    public void writeCustomDataToTag(CompoundTag tag) {
        super.writeCustomDataToTag(tag);
        if(parentWorm !=null) tag.putString("parentWorm", parentWorm.getUuidAsString());
        tag.putFloat("scale", scale);
        tag.putInt("segmentIndex", segmentIndex);
    }

    @Override
    public void readCustomDataFromTag(CompoundTag tag) {
        super.readCustomDataFromTag(tag);
        //parentWorm = (HuskWorm) world.getPlayerByUuid(UUID.fromString(tag.getString("parentWorm")));
        scale = tag.getFloat("scale");
        parentWormUuid = tag.getString("parentWorm");
        segmentIndex = tag.getInt("segmentIndex");
    }


    @Override
    public void pushAwayFrom(Entity entity) {} // Do nothing

    @Override
    public float getScaleFactor() {
        return scale;
    }

    @Override
    public boolean isInvulnerableTo(DamageSource damageSource) {
        if(damageSource == DamageSource.IN_WALL) return true;
        return super.isInvulnerableTo(damageSource);
    }

    public void setParentWorm(HuskWorm worm){
        System.out.println("comparing: " + worm.getUuidAsString() + "   to: " + parentWormUuid);
        if(worm.getUuidAsString().equals(parentWormUuid)) {
            parentWorm = worm;
            parentWorm.addSegment(this, segmentIndex);
        }
    }

}
