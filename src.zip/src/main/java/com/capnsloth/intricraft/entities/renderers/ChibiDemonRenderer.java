package com.capnsloth.intricraft.entities.renderers;

import com.capnsloth.intricraft.IntricraftMain;
import com.capnsloth.intricraft.entities.mobs.ChibiDemon;
import com.capnsloth.intricraft.entities.mobs.SlothEntity;
import com.capnsloth.intricraft.entities.mobs.models.ChibiDemonModel;
import com.capnsloth.intricraft.entities.mobs.models.SlothEntityModel;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

public class ChibiDemonRenderer extends MobEntityRenderer<ChibiDemon, ChibiDemonModel> {
    public final Identifier textureID = new Identifier(IntricraftMain.modID, "textures/entities/chibi_demon.png");
    public final ChibiDemonModel model;

    public ChibiDemonRenderer(EntityRenderDispatcher dispatcher, ChibiDemonModel entityModel, float shadowSize) {
        super(dispatcher, entityModel, shadowSize);
        this.model = entityModel;
    }

    @Override
    public Identifier getTexture(ChibiDemon entity) {
        return textureID;
    }

}
