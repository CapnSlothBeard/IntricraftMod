package com.capnsloth.intricraft.entities.renderers;

import com.capnsloth.intricraft.IntricraftMain;
import com.capnsloth.intricraft.entities.mobs.HuskWorm;
import com.capnsloth.intricraft.entities.mobs.HuskWormSegment;
import com.capnsloth.intricraft.entities.mobs.models.HuskWormModel;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.Vector3f;
import net.minecraft.util.Identifier;

public class HuskWormRenderer extends MobEntityRenderer<HuskWorm, HuskWormModel> {
    public final Identifier textureID = new Identifier(IntricraftMain.modID, "textures/entities/husk_worm_head.png");
    public final HuskWormModel model;

    public HuskWormRenderer(EntityRenderDispatcher dispatcher, HuskWormModel entityModel, float shadowSize) {
        super(dispatcher, entityModel, shadowSize);
        this.model = entityModel;
    }

    @Override
    public Identifier getTexture(HuskWorm entity) {
        return textureID;
    }


    @Override
    public void render(HuskWorm mobEntity, float f, float g, MatrixStack matrixStack, VertexConsumerProvider vertexConsumerProvider, int i) {
        matrixStack.push();
        matrixStack.scale(mobEntity.getScaleFactor(), mobEntity.getScaleFactor(), mobEntity.getScaleFactor());
        //matrixStack.multiply(Vector3f.NEGATIVE_Y.getDegreesQuaternion(mobEntity.prevYaw));
        //super.render(mobEntity, (float)(mobEntity.yaw * (Math.PI/180)), g, matrixStack, vertexConsumerProvider, i);
        super.render(mobEntity, mobEntity.yaw, g, matrixStack, vertexConsumerProvider, i);
        matrixStack.pop();
    }


}
