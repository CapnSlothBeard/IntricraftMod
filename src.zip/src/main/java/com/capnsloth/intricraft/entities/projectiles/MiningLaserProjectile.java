package com.capnsloth.intricraft.entities.projectiles;

import com.capnsloth.intricraft.network.EntitySpawnPacket;
import com.capnsloth.intricraft.network.SpawnLaserPacket;
import com.capnsloth.intricraft.registry.ModEntities;
import com.capnsloth.intricraft.network.PacketIdentifiers;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.thrown.ThrownEntity;
import net.minecraft.network.Packet;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class MiningLaserProjectile extends ThrownEntity {

    private int lifeTime = 0;
    private int maxLifetime = 100;
    public float prevYaw = 0;
    public int penetration = 1;
    private int peneCount = 0;
    //public float pitch = 0;

    public MiningLaserProjectile(EntityType<? extends ThrownEntity> entityType, World world){
        super(entityType, world);
        //System.out.println("Constructed Projectile method 1");
    }
    public MiningLaserProjectile(World world, LivingEntity owner) {
        super(ModEntities.MINING_LASER_PROJECTILE_ENTITY_TYPE, owner, world);
        //System.out.println("Constructed Projectile method 2");
    }

    @Environment(EnvType.CLIENT)
    public MiningLaserProjectile(World world, double x, double y, double z) {
        super(ModEntities.MINING_LASER_PROJECTILE_ENTITY_TYPE, x, y, z, world);
        //System.out.println("Constructed Projectile method 3");
    }

    @Override
    public void initDataTracker() {
    }

    @Override
    public Packet createSpawnPacket() {
        //System.out.println("Creating mining laser spawn packet.");
        return SpawnLaserPacket.create(this, PacketIdentifiers.SPAWN_LASER_PROJECTILE, penetration);
    }

    protected void onCollision(HitResult hitResult) { // called on collision with a block
        //System.out.println("Laser Collided");
        super.onCollision(hitResult);
        if (!this.world.isClient) { // checks if the world is client
            this.world.sendEntityStatus(this, (byte)3); // particle?
            Vec3d pos = hitResult.getPos();
            pos = pos.add(pos.add(this.getPos().multiply(-1)).multiply(0.01)); // Get the position slightly in front the projectiles path
            BlockPos bPos = new BlockPos(pos);
            BlockState b = world.getBlockState(bPos);
            if(b.getHardness(world, bPos) >= 0) {
                this.world.breakBlock(bPos, true);
                peneCount++;
                if(peneCount >= penetration) {
                    this.remove(); // kills the projectile
                }
            }
        }

    }

    @Override
    public void tick() {
        super.tick();
        // Delete if the laser has existed for too long.
        if(lifeTime > maxLifetime){
            this.remove();
        }
        lifeTime++;
    }

    @Override
    protected float getGravity() {
        return 0.0F;
    }
}
