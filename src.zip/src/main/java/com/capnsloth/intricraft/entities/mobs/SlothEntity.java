package com.capnsloth.intricraft.entities.mobs;

import com.capnsloth.intricraft.network.EntityBoolPacket;
import com.capnsloth.intricraft.network.EntityStringPacket;
import com.capnsloth.intricraft.registry.ModEntities;
import com.capnsloth.intricraft.network.PacketIdentifiers;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.BlockState;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.ServerConfigHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.Optional;
import java.util.UUID;

public class SlothEntity extends TameableEntity {

    //public enum BehaviourState {Idle, Following, Sitting, Nibbling, Riding};
    //public BehaviourState bs = BehaviourState.Idle;
    //public boolean sitting;

    public SlothEntity(EntityType<? extends TameableEntity> entityType, World world) { super(entityType, world); }

    protected void initGoals() {
        /*this.goalSelector.add(1, new SwimGoal(this));
        this.goalSelector.add(2, new SitGoal(this));
        this.goalSelector.add(4, new PounceAtTargetGoal(this, 0.4F));
        this.goalSelector.add(5, new MeleeAttackGoal(this, 1.0D, true));
        this.goalSelector.add(6, new FollowOwnerGoal(this, 1.0D, 10.0F, 2.0F, false));
        this.goalSelector.add(7, new AnimalMateGoal(this, 1.0D));
        this.goalSelector.add(8, new WanderAroundFarGoal(this, 1.0D));
        this.goalSelector.add(10, new LookAtEntityGoal(this, PlayerEntity.class, 8.0F));
        this.goalSelector.add(10, new LookAroundGoal(this));
        this.targetSelector.add(1, new TrackOwnerAttackerGoal(this));
        this.targetSelector.add(2, new AttackWithOwnerGoal(this));
        this.targetSelector.add(3, (new RevengeGoal(this, new Class[0])).setGroupRevenge(new Class[0]));
        this.targetSelector.add(8, new UniversalAngerGoal(this, true));*/
        this.goalSelector.add(1, new SwimGoal(this));
        this.goalSelector.add(2, new SitGoal(this));
        this.goalSelector.add(3, new FollowOwnerGoal(this, 0.35f, 0.3f, 15f, true));
        this.goalSelector.add(4, new AnimalMateGoal(this, 1.0D));
        this.goalSelector.add(5, new WanderAroundGoal(this, 0.3f, 1));
        this.targetSelector.add(1, new LookAtEntityGoal(this, PlayerEntity.class, 30, 0.2f));
    }

    public static DefaultAttributeContainer.Builder createSlothAttributes(){
        return MobEntity.createMobAttributes().add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.30000001192092896D).add(EntityAttributes.GENERIC_MAX_HEALTH, 16.0D).add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 1.0D);
    }

    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.ENTITY_WOLF_STEP, 0.2F, 0.7F);
    }

    /*public void animateModel(SlothEntity slothEntity, float f, float g, float h) {
        System.out.println("Called animateModel");
        if(slothEntity.isInSittingPose()){
            System.out.println("Doing sitting pose");
        }
    }*/

    public boolean isBreedingItem(ItemStack stack) {
        Item item = stack.getItem();
        Item[] breedingItems = new Item[]{Items.ACACIA_LEAVES, Items.BIRCH_LEAVES, Items.OAK_LEAVES, Items.DARK_OAK_LEAVES, Items.JUNGLE_LEAVES, Items.SPRUCE_LEAVES};
        for (Item i:breedingItems) {
            if(item == i) return true;
        }
        return false;
    }

    @Override
    public SlothEntity createChild(ServerWorld serverWorld, PassiveEntity passiveEntity) {
        SlothEntity babySloth = (SlothEntity) ModEntities.SLOTH.create(serverWorld);
        UUID uUID = this.getOwnerUuid();
        if (uUID != null) {
            babySloth.setOwnerUuid(uUID);
            babySloth.setTamed(true);
        }

        return babySloth;
    }

    public ActionResult interactMob(PlayerEntity player, Hand hand) {

        ItemStack itemStack = player.getStackInHand(hand);
        if (this.world.isClient) {
            boolean bl = this.isOwner(player) || this.isTamed() || isBreedingItem(itemStack) && !this.isTamed();
            return bl ? ActionResult.CONSUME : ActionResult.PASS;
        }else {
            if (this.isBaby()) {
                this.eat(player, itemStack);
                this.growUp((int) ((float) (-this.getBreedingAge() / 20) * 0.1F), true);
                return ActionResult.success(this.world.isClient);
            }

            if (this.isTamed()) {
                //Healing
                if (this.isBreedingItem(itemStack) && this.getHealth() < this.getMaxHealth()) {
                    if (!player.abilities.creativeMode) {
                        itemStack.decrement(1);
                    }
                    this.heal(5f);
                    return ActionResult.SUCCESS;
                }

                // Sitting.
                if (getOwnerUuid().toString().equals(player.getUuid().toString())) {
                    this.moddedSetSitting(!this.isSitting());
                    //System.out.println("Toggled sitting  " + this.isSitting());
                    this.jumping = false;
                    this.navigation.stop();
                    this.setTarget((LivingEntity) null);
                    return ActionResult.SUCCESS;
                }

                // Taming
            } else if (isBreedingItem(itemStack)) {
                if (!player.abilities.creativeMode) {
                    itemStack.decrement(1);
                }

                if (this.random.nextInt(3) == 0) {
                    this.setOwner(player);
                    this.navigation.stop();
                    this.setTarget((LivingEntity) null);
                    this.moddedSetSitting(true);
                    this.world.sendEntityStatus(this, (byte) 7); // Does particles.
                } else {
                    this.world.sendEntityStatus(this, (byte) 6); // Does particles along with handleStatus function.
                }


                return ActionResult.SUCCESS;
            }

            return ActionResult.PASS;
            //return super.interactMob(player, hand);
        }
        }


    // Allow access to private variable TameableEntity.sitting through the classes methods without causing recursion from client side syncing.
    public void moddedSetSitting(boolean sitting){
        if(!this.world.isClient) {
            this.setSitting(sitting); // Set sitting on server-side.
            // Send sitting command to client.
            this.world.getPlayers().forEach(
                    player -> ServerPlayNetworking.send((ServerPlayerEntity) player, PacketIdentifiers.SET_SITTING, EntityBoolPacket.createBuffer(this, this.isSitting()))
            );
        }
    }
    public void moddedSetSitting(boolean sitting, PlayerEntity player){
        if(!this.world.isClient) {
            this.setSitting(sitting); // Set sitting on server-side.
            // Send sitting command to client.
            ServerPlayNetworking.send((ServerPlayerEntity) player, PacketIdentifiers.SET_SITTING, EntityBoolPacket.createBuffer(this, this.isSitting()));
        }
    }


    // This is run on the server when a player starts tracking entity data, which I guess is mostly when they join the game.
    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        if(!this.world.isClient) {
            moddedSetSitting(isSitting(), player);
            //this.dataTracker.set(OWNER_UUID, Optional.ofNullable(this.getOwnerUuid()));
        }
        setOwnerUuid(getOwnerUuid());

    }
}
