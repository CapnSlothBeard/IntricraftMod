package com.capnsloth.intricraft.entities.renderers;

import com.capnsloth.intricraft.IntricraftMain;
import com.capnsloth.intricraft.entities.mobs.SlothEntity;
import com.capnsloth.intricraft.entities.mobs.models.SlothEntityModel;
import com.capnsloth.intricraft.entities.projectiles.MiningLaserProjectile;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.Vector3f;
import net.minecraft.util.Identifier;

public class SlothRenderer extends MobEntityRenderer<SlothEntity, SlothEntityModel> {

    public final Identifier textureID = new Identifier(IntricraftMain.modID, "textures/entities/sloth.png");
    public final SlothEntityModel model;

    public SlothRenderer(EntityRenderDispatcher dispatcher, SlothEntityModel entityModel, float shadowSize) {
        super(dispatcher, entityModel, shadowSize);
        this.model = entityModel;
    }

    @Override
    public Identifier getTexture(SlothEntity entity) {
        return textureID;
    }

    /*@Override
    public void render(SlothEntity entity, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
        model.render(matrices, vertexConsumers.getBuffer(RenderLayer.getEntitySolid(textureID)), light, 1, 1, 1, 1, 1);
        //super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }*/
}
