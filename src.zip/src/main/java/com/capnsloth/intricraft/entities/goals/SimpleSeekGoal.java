package com.capnsloth.intricraft.entities.goals;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.TargetPredicate;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.List;

public class SimpleSeekGoal extends Goal {

    protected LivingEntity self;
    protected Vec3d targetPos;
    protected Entity target;
    protected float speed;
    protected Class<? extends LivingEntity> targetClass;
    protected List<Class<? extends LivingEntity>> exclude;

    public SimpleSeekGoal(LivingEntity self, Vec3d targetPos, float speed){
        this.self = self;
        this.targetPos = targetPos;
        this.speed = speed;
    }

    public SimpleSeekGoal(LivingEntity self,Class<? extends LivingEntity> targetClass ,float speed){
        this.self = self;
        this.targetClass = targetClass;
        this.speed = speed;
    }

    public SimpleSeekGoal(LivingEntity self, Class<? extends LivingEntity> targetClass, List<Class<? extends LivingEntity>> exclude, float speed){
        this.self = self;
        this.targetClass = targetClass;
        this.speed = speed;
        this.exclude = exclude;
    }

    @Override
    public boolean canStart() {

        if(exclude != null) target = getClosestLivingEntityExlcuding(self.getPos(), 64, exclude, self.world);
        else{
            target = self.world.getClosestEntity(targetClass, TargetPredicate.DEFAULT,self ,self.getX(), self.getY(), self.getZ(),
                    new Box(self.getX() - 64,self.getY() - 64, self.getZ() - 64, self.getX() + 64, self.getY() + 64,self.getZ() + 64));
        }
        System.out.println("HuskWorm targeting: " + target);
        targetPos = target.getPos();
        return target != null;
    }

    @Override
    public boolean shouldContinue() {
        if(targetPos == null) return false;
        return self.getPos().distanceTo(targetPos) > 1;
    }

    @Override
    public void tick() {

        if(target != null) targetPos = target.getPos();

        if(targetPos != null) {
            Vec3d newPos = self.getPos();
            Vec3d directionToTargetPos = targetPos.subtract(self.getPos());
            directionToTargetPos = directionToTargetPos.normalize();
            directionToTargetPos = directionToTargetPos.multiply(speed);
            newPos = newPos.add(directionToTargetPos);

            self.updatePosition(newPos.x, newPos.y, newPos.z);

            //System.out.println("Moved entity in dir: " + directionToTargetPos);
        }
    }

    protected LivingEntity getClosestLivingEntityExlcuding(Vec3d originPos, int range, List<Class<? extends LivingEntity>> exclude, World world){
        List<LivingEntity> entities = world.getEntitiesByClass(targetClass,
                new Box(self.getX() - range,self.getY() - range, self.getZ() - range, self.getX() + range, self.getY() + range,self.getZ() + range),
                null
        );

        for(int i = 0; i < exclude.size(); i++) {
            int finalI = i;
            entities.removeIf(e -> exclude.get(finalI) == e.getClass() );
        }

        LivingEntity closestEntity = null;
        double closestDist = range+1;
        for(LivingEntity e : entities){
            double dist = e.getPos().distanceTo(originPos);
            if(dist < closestDist){
                closestDist = dist;
                closestEntity = e;
            }
        }
        return closestEntity;
    }
}

