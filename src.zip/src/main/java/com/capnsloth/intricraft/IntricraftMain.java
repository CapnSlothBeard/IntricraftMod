package com.capnsloth.intricraft;

import com.capnsloth.intricraft.machines.CrusherBlock;
import com.capnsloth.intricraft.machines.CrusherLogic;
import com.capnsloth.intricraft.network.PacketIdentifiers;
import com.capnsloth.intricraft.registry.*;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.server.ServerStartCallback;
import net.fabricmc.fabric.api.event.server.ServerStopCallback;
import net.fabricmc.fabric.api.event.server.ServerTickCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Session;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.dedicated.MinecraftDedicatedServer;
import net.minecraft.util.WorldSavePath;
import net.minecraft.world.WorldSaveHandler;
import net.minecraft.world.level.storage.LevelStorage;
import net.minecraft.world.level.storage.SessionLock;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.*;

public class IntricraftMain implements ModInitializer {
    public static final String modID = "intricraft";

    // Logic workers.
    private CrusherLogic crusherLogic;

    @Override
    public void onInitialize() {
        // Run Registry Functions
        ModItems.RegisterItems();
        ModBlocks.RegisterBlocks();
        ModBlocks.RegisterBlockEntities();
        ModEntities.RegisterAttributes();

        RegisterNetworkListeners();

        // DO ON SERVER START.
        ServerStartCallback.EVENT.register(server -> {
            crusherLogic = new CrusherLogic(server);
            try{
                crusherLogic.loadWorkers(server);
            }catch (IOException e){
                System.out.println("ERROR LOADING CRUSHER DATA");
                e.printStackTrace();
            }
        });

        // DO EACH SERVER TICK.
        ServerTickCallback.EVENT.register(server -> {
            crusherLogic.serverTick();
        });

        // DO ON SERVER STOP.
        ServerStopCallback.EVENT.register(server -> {
            try {
                crusherLogic.saveWorkers(server);
            } catch (IOException e) {
                System.out.println("ERROR SAVING CRUSHER DATA");
                e.printStackTrace();
            }
            crusherLogic = null;
        });

    }

    // Registers server-side listeners
    private void RegisterNetworkListeners(){

        ServerPlayNetworking.registerGlobalReceiver(PacketIdentifiers.JETPACK_CONSUME_FUEL, (server, player, handler, buf, sender) -> {
            player.inventory.removeStack(player.inventory.getSlotWithStack(FuelTypes.fuelType[buf.readInt()].getDefaultStack()), 1);
        });
    }

}

