package com.capnsloth.intricraft;

import com.capnsloth.intricraft.network.PacketIdentifiers;
import com.capnsloth.intricraft.registry.*;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.server.ServerStartCallback;
import net.fabricmc.fabric.api.event.server.ServerStopCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

public class IntricraftMain implements ModInitializer {
    public static final String modID = "intricraft";

    @Override
    public void onInitialize() {
        // Run Registry Functions
        ModItems.RegisterItems();
        ModBlocks.RegisterBlocks();
        ModBlocks.RegisterBlockEntities();
        ModEntities.RegisterAttributes();

        RegisterNetworkListeners();


    }

    // Registers server-side listeners
    private void RegisterNetworkListeners(){

        ServerPlayNetworking.registerGlobalReceiver(PacketIdentifiers.JETPACK_CONSUME_FUEL, (server, player, handler, buf, sender) -> {
            player.inventory.removeStack(player.inventory.getSlotWithStack(FuelTypes.fuelType[buf.readInt()].getDefaultStack()), 1);
        });
    }

}

