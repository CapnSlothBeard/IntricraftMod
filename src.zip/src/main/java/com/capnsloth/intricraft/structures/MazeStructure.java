package com.capnsloth.intricraft.structures;

import com.capnsloth.intricraft.IntricraftMain;
import com.capnsloth.intricraft.registry.ModBlocks;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.structure.*;
import net.minecraft.structure.processor.BlockIgnoreStructureProcessor;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.*;
import net.minecraft.util.registry.DynamicRegistryManager;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.gen.StructureAccessor;
import net.minecraft.world.gen.chunk.ChunkGenerator;
import net.minecraft.world.gen.feature.ConfiguredStructureFeature;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;
import net.minecraft.world.gen.feature.StructureFeature;

import java.util.*;

public class MazeStructure extends StructureFeature<DefaultFeatureConfig> {

    public static final StructurePieceType PIECE = Generator.Piece::new;
    public static final StructureFeature<DefaultFeatureConfig> STRUCTURE = new MazeStructure(DefaultFeatureConfig.CODEC);
    public static final ConfiguredStructureFeature<?, ?> CONFIGURED_STRUCTURE = STRUCTURE.configure(DefaultFeatureConfig.DEFAULT);
    public static final int maxSteps = 1;
    public static final int cellCount = 10; // Cell count per axis.
    public static final int cellSize = 5;
    public static final int wallThickness = 3;

    public MazeStructure(Codec<DefaultFeatureConfig> codec) {
        super(codec);
    }

    @Override
    public StructureStartFactory<DefaultFeatureConfig> getStructureStartFactory() {
        return Start::new;
    }

    protected static class Start extends StructureStart<DefaultFeatureConfig> {
        public Start(StructureFeature<DefaultFeatureConfig> feature, int chunkX, int chunkZ, BlockBox box, int references, long seed) {
            super(feature, chunkX, chunkZ, box, references, seed);
        }

        @Override
        // Called when the world attempts to spawn in a new structure, and is the gap between your feature and generator.
        public void init(DynamicRegistryManager registryManager, ChunkGenerator chunkGenerator, StructureManager manager, int chunkX, int chunkZ, Biome biome, DefaultFeatureConfig config) {
            int x = chunkX * 16;
            int z = chunkZ * 16;
            //int y = chunkGenerator.getHeight(x, z, Heightmap.Type.WORLD_SURFACE_WG);
            int y = 110;
            BlockPos pos = new BlockPos(x, y, z);
            //BlockRotation rotation = BlockRotation.random(this.random);
            BlockRotation rotation = BlockRotation.NONE;
            Generator.addPieces(manager, pos, rotation, this.children, maxSteps);
            //this.setBoundingBoxFromChildren();
            this.boundingBox = new BlockBox(x, y, z,
                    x+ (cellCount*(cellSize+wallThickness)),
                    y+ (cellCount*(cellSize+wallThickness)),
                    z+ (cellCount*(cellSize+wallThickness)));

            System.out.println("Generated maze at: " + pos);
        }
    }

    protected static class Generator {
        // Parts
        private static final Identifier MAZE_DEBUG_ID = new Identifier(IntricraftMain.modID,"maze_debug");

        public static void addPieces(StructureManager manager, BlockPos pos, BlockRotation rotation, List<StructurePiece> pieces, int maxSteps) {

            pieces.add(new Generator.Piece(manager, pos, MAZE_DEBUG_ID, rotation));
        }

        protected static class Piece extends SimpleStructurePiece {

            private final BlockRotation rotation;
            private final Identifier template;
            private StructureManager structureManager;

            public Piece(StructureManager structureManager, CompoundTag compoundTag) {
                super(PIECE, compoundTag);
                this.template = new Identifier(compoundTag.getString("Template"));
                this.rotation = BlockRotation.valueOf(compoundTag.getString("Rot"));
                this.structureManager = structureManager;
                this.initializeStructureData(structureManager);
            }

            public Piece(StructureManager structureManager, BlockPos pos, Identifier template, BlockRotation rotation) {
                super(PIECE, 0);
                this.pos = pos;
                this.rotation = rotation;
                this.template = template;
                this.structureManager = structureManager;
                this.initializeStructureData(structureManager);
            }

            @Override
            protected void setStructureData(Structure structure, BlockPos pos, StructurePlacementData placementData) {
                this.structure = structure;
                this.setOrientation(Direction.NORTH);
                this.pos = pos;
                this.placementData = placementData;
                this.boundingBox = structure.calculateBoundingBox(placementData, pos);
            }


            @Override
            public boolean generate(StructureWorldAccess structureWorldAccess, StructureAccessor structureAccessor, ChunkGenerator chunkGenerator, Random random, BlockBox boundingBox, ChunkPos chunkPos, BlockPos blockPos) {

                int debugCount = 0;

                BlockBox bb = new BlockBox(0, 0, 0,
                        cellCount*(cellSize+wallThickness),
                        cellCount*(cellSize+wallThickness),
                        cellCount*(cellSize+wallThickness));
                this.placementData.setBoundingBox(bb);
                this.boundingBox = this.structure.calculateBoundingBox(this.placementData, blockPos);


                // Set up maze grid -------------------------------------------------------------------------------
                BlockPos[][] cells = new BlockPos[cellCount][cellCount];
                for(int x = -wallThickness; x < (cellCount*(cellSize+wallThickness)); x+= (cellSize+wallThickness)){
                    for(int z = -wallThickness; z < (cellCount*(cellSize+wallThickness)); z+= (cellSize+wallThickness)){


                        for(int i = 0; i<=(cellSize+wallThickness); i++ ){
                            for(int j = 0; j<=(cellSize+wallThickness); j++ ){

                                // Draw black concrete if floor, gray if wall.   <-- Debug
                                BlockPos bp = new BlockPos(blockPos.getX() + x + i, blockPos.getY(), blockPos.getZ() + z + j);
                                if(i >= wallThickness && j >= wallThickness) {
                                    structureWorldAccess.setBlockState(bp, Blocks.BLACK_CONCRETE.getDefaultState(), 2);
                                }else{
                                    structureWorldAccess.setBlockState(bp, Blocks.GRAY_CONCRETE.getDefaultState(), 2);
                                }

                                /*
                                bp = new BlockPos(blockPos.getX() + x+i, blockPos.getY()+j, blockPos.getZ() + z);
                                structureWorldAccess.setBlockState(bp, Blocks.GRAY_WOOL.getDefaultState(), 2);


                                bp = new BlockPos(blockPos.getX() + x, blockPos.getY()+j, blockPos.getZ() + z +i);
                                structureWorldAccess.setBlockState(bp, Blocks.GRAY_WOOL.getDefaultState(), 2);

                                 */


                            }
                        }


                        debugCount++;
                    }
                }

                // Build exterior walls.
                int mazeSize = (cellSize+wallThickness)*cellCount;
                BlockPos xStart = blockPos;
                xStart = xStart.add(-wallThickness, 0, -wallThickness);
                BlockPos xEnd = xStart.add(mazeSize+wallThickness-1, cellSize, wallThickness-1);
                fillBox(structureWorldAccess, xStart.getX(), xStart.getY(), xStart.getZ(), xEnd.getX(), xEnd.getY(), xEnd.getZ(), ModBlocks.HARD_STONE_BLOCK.getDefaultState());
                xStart = xStart.add(0,0, mazeSize);
                xEnd = xEnd.add(0,0, mazeSize);
                fillBox(structureWorldAccess, xStart.getX(), xStart.getY(), xStart.getZ(), xEnd.getX(), xEnd.getY(), xEnd.getZ(), ModBlocks.HARD_STONE_BLOCK.getDefaultState());

                BlockPos zStart = blockPos;
                zStart = zStart.add(-wallThickness,0, -wallThickness);
                BlockPos zEnd = zStart.add(wallThickness-1, cellSize, mazeSize+wallThickness-1);
                fillBox(structureWorldAccess, zStart.getX(), zStart.getY(), zStart.getZ(), zEnd.getX(), zEnd.getY(), zEnd.getZ(), ModBlocks.HARD_STONE_BLOCK.getDefaultState());
                zStart = zStart.add(mazeSize,0, 0);
                zEnd = zEnd.add(mazeSize,0, 0);
                fillBox(structureWorldAccess, zStart.getX(), zStart.getY(), zStart.getZ(), zEnd.getX(), zEnd.getY(), zEnd.getZ(), ModBlocks.HARD_STONE_BLOCK.getDefaultState());


                // Populate cell positions.
                for(int cellX = 0; cellX < cellCount; cellX++ ){
                    for(int cellZ = 0; cellZ < cellCount; cellZ++ ){
                        BlockPos bp = new BlockPos(blockPos.getX() + (cellX*((cellSize+wallThickness))), blockPos.getY(), blockPos.getZ() + (cellZ*((cellSize+wallThickness))));
                        structureWorldAccess.setBlockState(bp, Blocks.GOLD_BLOCK.getDefaultState(), 2);
                        cells[cellX][cellZ] = bp;
                        debugCount++;
                    }
                }
                //================================================================================================

                // Generate maze path. -------------------------------------------------------------------------
                boolean[][] visitedCells = new boolean[cellCount][cellCount];
                Stack<Pair<Integer, Integer>> stack = new Stack<>(); // Stack used to track path history.
                stack.push(Pair.of(0,0)); // Add first cell to stack.

                // Mark start point
                BlockPos startPoint = cells[stack.peek().getFirst()][stack.peek().getSecond()];
                structureWorldAccess.setBlockState(startPoint, Blocks.GREEN_WOOL.getDefaultState(), 3);

                BlockPos furthestPoint = startPoint;
                int largestStackSize = 0;

                int visitedCount = 0;
                while(visitedCount < cellCount*cellCount){

                    // Chose an unvisted location to move to.
                    List<Pair<Integer, Integer>> neighbours = getDirectionOfUnvisitedNeighbours(stack.peek(), visitedCells);

                    // Back track stack.
                    while(neighbours.size() == 0 && !stack.empty()){
                        stack.pop();
                        neighbours = getDirectionOfUnvisitedNeighbours(stack.peek(), visitedCells);
                    }

                    //System.out.println("Removing Wall");
                    Pair<Integer, Integer> neighbour = neighbours.get(random.nextInt(neighbours.size()));
                    Pair<Integer, Integer> newPos = Pair.of(stack.peek().getFirst() + neighbour.getFirst(), stack.peek().getSecond() + neighbour.getSecond());
                    visitedCells[newPos.getFirst()][newPos.getSecond()] = true;

                    // Place walls

                    //neighbours.remove(neighbour);

                    for(Pair<Integer, Integer> p : neighbours){

                        /*
                        List<Pair<Integer, Integer>> exclude = new ArrayList<>();
                        exclude.add(neighbour);
                        buildCellWalls(neighbours, exclude, cells[stack.peek().getFirst()][stack.peek().getSecond()],ModBlocks.HARD_STONE_BLOCK.getDefaultState(), structureWorldAccess);

                         */

                        // Determine start pos as either: top left, top right, or bottom left.
                        // Drawing wall is always done either: top to bottom or left to right

                        BlockState wallState = ModBlocks.HARD_STONE_BLOCK.getDefaultState();

                        BlockPos startPos = cells[stack.peek().getFirst()][stack.peek().getSecond()];
                        startPos = new BlockPos(
                                p.getFirst() <= 0 ? startPos.getX() - wallThickness : startPos.getX() + cellSize,
                                blockPos.getY() + 1,
                                p.getSecond() <= 0 ? startPos.getZ() - wallThickness : startPos.getZ() + cellSize
                        );


                        // Set wall length.
                        BlockPos endPos = startPos.add(
                                p.getFirst() == 0 ? cellSize + wallThickness : wallThickness - 1, // If x dir of neighbour is 0 we want to draw a wall horizontally.
                                cellSize - 1,
                                p.getSecond() == 0 ? cellSize + wallThickness : wallThickness - 1
                        );



                        // Set wall thickness
                        //endPos = endPos.add((wallThickness-1)*p.getFirst(), 0, (wallThickness-1)*p.getSecond());



                        // If neighbour direction is the chosen path remove a wall instead of placing one.
                        if(p.getFirst().equals(neighbour.getFirst()) && p.getSecond().equals(neighbour.getSecond())) {
                            //wallState = Blocks.GLASS.getDefaultState();
                            wallState = Blocks.AIR.getDefaultState();
                            // Shrink wall so that it doesn't cut adjacent walls.
                            int xS = (int)Math.abs(Math.signum(p.getSecond()));
                            int zS = (int)Math.abs(Math.signum(p.getFirst()));
                            startPos = startPos.add(wallThickness*xS,0, wallThickness*zS);
                            endPos = endPos.add(-1*xS, 0, -1*zS);
                        }



                        // Or maybe don't draw the wall, you know what ever's goin'.
                        if(new Random().nextInt(8) != 1) {
                            fillBox(structureWorldAccess,
                                    startPos.getX(), startPos.getY(), startPos.getZ(), endPos.getX(), endPos.getY(), endPos.getZ(),
                                    wallState
                            );
                        }



                        //DEBUG
                        //structureWorldAccess.setBlockState(startPos, Blocks.LIME_WOOL.getDefaultState(),2);
                        //structureWorldAccess.setBlockState(endPos, Blocks.PINK_WOOL.getDefaultState(),2);



                    }



                    // Draw path line.
                    BlockPos bp = cells[stack.peek().getFirst()][stack.peek().getSecond()];
                    bp = bp.add((cellSize/2), 0, (cellSize/2));
                    for(int i = 0; i<(cellSize+wallThickness); i++) {
                        bp = bp.add(neighbour.getFirst(), 0, neighbour.getSecond());
                        structureWorldAccess.setBlockState(bp, Blocks.WHITE_WOOL.getDefaultState(), 3);
                        debugCount++;
                    }
                    structureWorldAccess.setBlockState(bp, Blocks.EMERALD_BLOCK.getDefaultState(), 3);

                    stack.push(newPos); // Move in neighbours direction and add it to the stack.
                    visitedCount++;

                    // Check furthest point.
                    if(stack.size() > largestStackSize){
                        furthestPoint = cells[stack.peek().getFirst()][stack.peek().getSecond()];
                        largestStackSize = stack.size();
                    }

                }

                // Mark end point
                BlockPos endPoint = cells[stack.peek().getFirst()][stack.peek().getSecond()];
                structureWorldAccess.setBlockState(endPoint, Blocks.RED_WOOL.getDefaultState(), 3);
                debugCount++;

                // Mark furthest point.
                structureWorldAccess.setBlockState(furthestPoint, Blocks.BLUE_WOOL.getDefaultState(), 3);
                debugCount++;

                //===============================================================================================

                System.out.println("Placed " + debugCount + " blocks in maze generation.");

                return true;
            }


            public void fillBox(StructureWorldAccess structureWorldAccess, int minX, int minY, int minZ, int maxX, int maxY, int maxZ, BlockState blockState) {
                for(int y = minY; y <= maxY; ++y) {
                    for(int x = minX; x <= maxX; ++x) {
                        for(int z = minZ; z <= maxZ; ++z) {
                            structureWorldAccess.setBlockState(new BlockPos(x,y,z), blockState, 2);
                        }
                    }
                }

            }


            private List<Pair<Integer, Integer>> getDirectionOfUnvisitedNeighbours(Pair<Integer, Integer> pos, boolean[][] visitedCells){
                List<Pair<Integer, Integer>> neighbours = new ArrayList<>();

                // North
                if(pos.getSecond() > 0 ){
                    if(!visitedCells[pos.getFirst()][pos.getSecond()-1]){ // If cell has not been vistited.
                        neighbours.add(Pair.of(0,-1)); // add direction.
                    }
                }
                // South
                if(pos.getSecond() < cellCount-1 ){
                    if(!visitedCells[pos.getFirst()][pos.getSecond()+1]){ // If cell has not been vistited.
                        neighbours.add(Pair.of(0,1));
                    }
                }
                // East
                if(pos.getFirst() < cellCount-1 ){
                    if(!visitedCells[pos.getFirst()+1][pos.getSecond()]){ // If cell has not been vistited.
                        neighbours.add(Pair.of(1,0));
                    }
                }
                // West
                if(pos.getFirst() > 0){
                    if(!visitedCells[pos.getFirst()-1][pos.getSecond()]){ // If cell has not been vistited.
                        neighbours.add(Pair.of(-1,0));
                    }
                }

                return neighbours;
            }


            private void generateBox(StructureWorldAccess world, Box box, BlockState blockState){
                for(double x = box.minX; x < box.maxX; x++){
                    for(double y = box.minY; y < box.maxY; y++){
                        for(double z = box.minZ; z < box.maxZ; z++){
                            System.out.println("derp: " + x + ","+y+","+z);
                            world.setBlockState(new BlockPos(x,y,x), blockState, 3);
                        }
                    }
                }
            }


            private void initializeStructureData(StructureManager structureManager) {
                Structure structure = structureManager.getStructureOrBlank(this.template);
                StructurePlacementData placementData = (new StructurePlacementData())
                        .setRotation(this.rotation)
                        .setMirror(BlockMirror.NONE)
                        .addProcessor(BlockIgnoreStructureProcessor.IGNORE_STRUCTURE_BLOCKS);
                this.setStructureData(structure, this.pos, placementData);
            }

            protected void toNbt(CompoundTag tag) {
                super.toNbt(tag);
                tag.putString("Template", this.template.toString());
                tag.putString("Rot", this.rotation.name());
            }

            @Override
            protected void handleMetadata(String metadata, BlockPos pos, ServerWorldAccess serverWorldAccess, Random random, BlockBox boundingBox) {

            }


        }

    }
}
