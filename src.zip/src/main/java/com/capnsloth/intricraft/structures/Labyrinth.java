package com.capnsloth.intricraft.structures;

import com.google.common.collect.ImmutableList;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import net.minecraft.structure.pool.*;
import net.minecraft.structure.processor.StructureProcessorLists;
import net.minecraft.util.Identifier;
import net.minecraft.world.gen.feature.*;


public class Labyrinth extends JigsawFeature {

    public static final StructureFeature<StructurePoolFeatureConfig> STRUCTURE;
    public static final ConfiguredStructureFeature<?, ?> CONFIGURED_STRUCTURE;

    public static final StructurePool ENTRANCE_POOL;
    public static final StructurePool GENERAL_POOL;

    static {

        System.out.println("Labyrinth Static called");

        ENTRANCE_POOL = StructurePools.register(new StructurePool(
                new Identifier("intricraft:labyrinth"),
                new Identifier("empty"), // "@Draylar if you know what this one does";  yeah, I got no clue either man...
                ImmutableList.of(
                        Pair.of(StructurePoolElement.method_30435("intricraft:labyrinth_entrance", StructureProcessorLists.EMPTY), 1)
                ),
                StructurePool.Projection.RIGID
        ));

        GENERAL_POOL = StructurePools.register(new StructurePool(
                new Identifier("intricraft:labyrinth/general"),
                new Identifier("empty"),
                ImmutableList.of(
                        Pair.of(StructurePoolElement.method_30435("intricraft:labyrinth_hall_large", StructureProcessorLists.EMPTY), 3),
                        Pair.of(StructurePoolElement.method_30435("intricraft:labyrinth_hall_large_turn", StructureProcessorLists.EMPTY), 4),
                        Pair.of(StructurePoolElement.method_30435("intricraft:labyrinth_hall_small", StructureProcessorLists.EMPTY), 2),
                        Pair.of(StructurePoolElement.method_30435("intricraft:labyrinth_hall_small_turn", StructureProcessorLists.EMPTY), 1),
                        Pair.of(StructurePoolElement.method_30435("intricraft:labyrinth_hall_small_threeway", StructureProcessorLists.EMPTY), 1)
                ),
                StructurePool.Projection.RIGID
        ));

        STRUCTURE = new Labyrinth(StructurePoolFeatureConfig.CODEC);
        CONFIGURED_STRUCTURE = STRUCTURE.configure(new StructurePoolFeatureConfig(() -> ENTRANCE_POOL, 7));



    }


    public Labyrinth(Codec<StructurePoolFeatureConfig> codec) {
        super(codec, 64, false, true);
        System.out.println("Labyrinth constructor called");
    }

}



